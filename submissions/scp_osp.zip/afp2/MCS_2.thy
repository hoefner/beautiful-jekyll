
(*
Title:   RG Verification of the MCS Lock -- the Concrete Version
Author(s):     Robert Colvin, Scott Heiner, Peter Hoefner, Roger Su
Year:          2026
License:       BSD 2-Clause
Maintainer(s): Robert Colvin <r.colvin@uq.edu.au>
               Peter Hoefner <peter@hoefner-online.de>
               Roger Su <roger.c.su@proton.me>
*)

(* To load this file in the Isabelle IDE, run the following command
in the parent directory (above "afp2"):
  isabelle jedit -d . -R RG_MCS_CLH
*)

section \<open>MCS: Concrete Version\<close>

theory MCS_2

imports
  "RGLocks.Concurrent_Queue_Contract"
  "RGLocks.RG_Syntax_Extensions"
  Pointers

begin

(*------------------------------------------------------------------*)
type_synonym thread_id = nat

consts NumThreads :: nat

record node =
  wait :: bool
  next_node :: pointer

record mcs2_state = "node heap" +
  tail  :: pointer
  prev  :: "thread_id \<Rightarrow> pointer"
  succ  :: "thread_id \<Rightarrow> pointer"
  myptr :: "thread_id \<Rightarrow> pointer"
  aux_queue :: "thread_id list"
  aux_cas_result :: "thread_id \<Rightarrow> bool"

abbreviation mynode :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> node" where
  "mynode s i \<equiv> heap s (myptr s i)"

definition mcs2_init :: "mcs2_state set" where
  "mcs2_init \<equiv> \<lbrace> \<acute>aux_queue = [] \<and> \<acute>tail = Null \<and> \<acute>prev = (\<lambda>_.Null) \<and> 
  \<acute>myptr = (\<lambda> i. Ptr i) \<rbrace>"

abbreviation pred_sat :: "mcs2_state \<Rightarrow> thread_id
  \<Rightarrow> (thread_id \<Rightarrow> bool) \<Rightarrow> bool" where
  "pred_sat s i F \<equiv> \<forall> h. sublist [h,i] (aux_queue s) \<longrightarrow> F h"

abbreviation next_of_pred_is_none :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "next_of_pred_is_none s i \<equiv> pred_sat s i (\<lambda> h.
    next_node (heap s (myptr s h)) = Null)"

abbreviation next_of_pred_not_none :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "next_of_pred_not_none s i \<equiv> pred_sat s i (\<lambda> h.
    next_node (heap s (myptr s h)) \<noteq> Null)"

(*==================================================================*)
subsection \<open>Invariant\<close>

(*------------------------------------------------------------------*)
subsubsection \<open>Inherited from Intermediate MCS\<close>

definition mcs2_inv_prev :: "mcs2_state set" where
  "mcs2_inv_prev \<equiv> \<lbrace> \<forall> i. i \<in> set \<acute>aux_queue \<longrightarrow>
      (\<acute>prev i = Null \<longrightarrow> at_head i \<acute>aux_queue)
    \<and> (\<acute>prev i \<noteq> Null \<longrightarrow> wait (\<acute>mynode i) = (\<not> at_head i \<acute>aux_queue))
    \<and> \<acute>pred_sat i (\<lambda> h. \<acute>prev i = \<acute>myptr h) \<rbrace>"

definition mcs2_inv_last :: "mcs2_state set" where
  "mcs2_inv_last \<equiv> \<lbrace> \<acute>aux_queue \<noteq> [] \<longrightarrow>
    next_node (\<acute>mynode (last \<acute>aux_queue)) = Null \<rbrace>"

definition mcs2_inv_queue :: "mcs2_state set" where
  "mcs2_inv_queue \<equiv> \<lbrace> distinct \<acute>aux_queue
    \<and> set \<acute>aux_queue \<subseteq> {..< NumThreads} \<rbrace>"

(*------------------------------------------------------------------*)
subsubsection \<open>New Clauses for the Present Version\<close>

definition mcs2_inv_tail :: "mcs2_state set" where
  "mcs2_inv_tail \<equiv> \<lbrace> \<acute>tail = (if \<acute>aux_queue \<noteq> []
    then \<acute>myptr (last \<acute>aux_queue)
    else Null) \<rbrace>"

definition mcs2_inv_next :: "mcs2_state set" where
  "mcs2_inv_next \<equiv> \<lbrace> \<forall> i. i \<in> set \<acute>aux_queue \<longrightarrow>
      next_node (\<acute>mynode i) = Null
    \<or> (\<exists> j. next_node (\<acute>mynode i) = \<acute>myptr j \<and> sublist [i,j] \<acute>aux_queue) \<rbrace>"

definition mcs2_inv_ptr :: "mcs2_state set" where
  "mcs2_inv_ptr \<equiv> \<lbrace> inj \<acute>myptr \<and> (\<forall> i. \<acute>myptr i \<noteq> Null) \<rbrace>"

(*------------------------------------------------------------------*)
subsubsection \<open>Combined Invariant\<close>

definition mcs2_invar :: "mcs2_state set" where
  "mcs2_invar \<equiv> mcs2_inv_prev \<inter> mcs2_inv_last \<inter> mcs2_inv_queue
              \<inter> mcs2_inv_tail \<inter> mcs2_inv_next \<inter> mcs2_inv_ptr"

lemma mcs2_invar_subgoals:
  assumes "s \<in> mcs2_inv_prev"
      and "s \<in> mcs2_inv_last"
      and "s \<in> mcs2_inv_queue"
      and "s \<in> mcs2_inv_tail"
      and "s \<in> mcs2_inv_next"
      and "s \<in> mcs2_inv_ptr"
    shows "s \<in> mcs2_invar"
  using assms unfolding mcs2_invar_def by blast

method method_mcs2_invar = rule mcs2_invar_subgoals,
  goal_cases mcs2_inv_prev mcs2_inv_last mcs2_inv_queue
             mcs2_inv_tail mcs2_inv_next mcs2_inv_ptr

lemmas defs_invar [simp] =
  mcs2_inv_prev_def
  mcs2_inv_last_def
  mcs2_inv_queue_def
  mcs2_inv_tail_def
  mcs2_inv_next_def
  mcs2_inv_ptr_def
  mcs2_invar_def

lemma init_invar:
  "s \<in> mcs2_init \<Longrightarrow> s \<in> mcs2_invar"
  unfolding mcs2_init_def
proof method_mcs2_invar
  case mcs2_inv_ptr then show ?case by (simp add: inj_def)
qed simp_all

(*==================================================================*)
subsection \<open>Rely and Guarantee\<close>

text \<open>All the rely- and guarantee-clauses are inherited from the 
intermediate version of MCS.\<close>

definition mcs2_contract_locals_id :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_contract_locals_id i \<equiv> ids({prev, succ} @ i) 
                            \<inter> id(aux_cas_result @ i)
                            \<inter> id(myptr)"

definition mcs2_contract_queue :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_contract_queue i \<equiv> \<lbrace> queue_contract i \<ordmasculine>aux_queue \<ordfeminine>aux_queue \<rbrace>"

definition mcs2_contract_wait :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_contract_wait i \<equiv> \<lbrace> wait (\<ordfeminine>mynode i) \<noteq> wait (\<ordmasculine>mynode i)
    \<longrightarrow> (i \<in> set \<ordmasculine>aux_queue \<and> hd \<ordmasculine>aux_queue \<noteq> i \<and> hd \<ordfeminine>aux_queue = i
        \<and> wait (\<ordmasculine>mynode i) \<and> \<not> wait (\<ordfeminine>mynode i)) \<rbrace>"

(*------------------------------------------------------------------*)
definition mcs2_rely_knows_succ :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_rely_knows_succ i \<equiv> \<lbrace> next_node (\<ordfeminine>mynode i) \<noteq> next_node (\<ordmasculine>mynode i)
    \<longrightarrow> i \<in> set \<ordfeminine>aux_queue \<and> i \<noteq> last \<ordfeminine>aux_queue \<and>
        next_node (\<ordmasculine>mynode i) = Null \<rbrace>"

definition mcs2_rely_head :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_rely_head i \<equiv> \<lbrace> \<ordmasculine>pred_sat i (\<lambda> h.
    next_node (\<ordmasculine>mynode h) = Null \<longrightarrow> sublist [h,i] \<ordfeminine>aux_queue) \<rbrace>"

definition mcs2_rely_prev :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_rely_prev i \<equiv> \<lbrace> \<ordmasculine>pred_sat i (\<lambda> h.
    next_node (\<ordmasculine>mynode h) = next_node (\<ordfeminine>mynode h)) \<rbrace>"

(*------------------------------------------------------------------*)
definition mcs2_guar_knows_succ :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_guar_knows_succ i \<equiv> \<lbrace>
    (next_node (\<ordmasculine>mynode i) \<noteq> next_node (\<ordfeminine>mynode i)
      \<longrightarrow> i \<notin> set \<ordmasculine>aux_queue \<and> next_node (\<ordfeminine>mynode i) = Null)
  \<and> (\<forall> h. h \<noteq> i
      \<longrightarrow> next_node (\<ordmasculine>mynode h) \<noteq> next_node (\<ordfeminine>mynode h)
        \<longrightarrow> next_node (\<ordmasculine>mynode h) = Null
          \<and> next_node (\<ordfeminine>mynode h) \<noteq> Null
          \<and> \<ordmasculine>prev i = \<ordmasculine>myptr h
          \<and> sublist [h,i] \<ordmasculine>aux_queue) \<rbrace>"

definition mcs2_guar_head :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_guar_head i \<equiv> \<lbrace> \<forall> j.
    sublist [i,j] \<ordmasculine>aux_queue \<and> next_node (\<ordmasculine>mynode i) = Null
    \<longrightarrow> sublist [i,j] \<ordfeminine>aux_queue \<rbrace>"

(*------------------------------------------------------------------*)
subsubsection \<open>Combined Rely and Guarantee\<close>

definition mcs2_rely :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_rely i \<equiv> mcs2_contract_locals_id i
              \<inter> mcs2_contract_queue i
              \<inter> mcs2_contract_wait i
              \<inter> mcs2_rely_knows_succ i
              \<inter> mcs2_rely_prev i
              \<inter> mcs2_rely_head i"

definition mcs2_guar :: "thread_id \<Rightarrow> mcs2_state rel" where
  "mcs2_guar i \<equiv> for_others mcs2_contract_locals_id i
              \<inter> for_others mcs2_contract_queue i
              \<inter> for_others mcs2_contract_wait i
              \<inter> mcs2_guar_knows_succ i
              \<inter> mcs2_guar_head i"

lemmas defs_rg [simp] =
  mcs2_contract_locals_id_def
  mcs2_contract_queue_def
  mcs2_contract_wait_def
  mcs2_rely_prev_def
  mcs2_rely_knows_succ_def
  mcs2_guar_knows_succ_def
  mcs2_rely_head_def
  mcs2_guar_head_def
  mcs2_rely_def
  mcs2_guar_def

lemma mcs2_guar_subgoals:
  assumes "(s1, s2) \<in> for_others mcs2_contract_locals_id i"
      and "(s1, s2) \<in> for_others mcs2_contract_queue i"
      and "(s1, s2) \<in> for_others mcs2_contract_wait i"
      and "(s1, s2) \<in> mcs2_guar_knows_succ i"
      and "(s1, s2) \<in> mcs2_guar_head i"
    shows "(s1, s2) \<in> mcs2_guar i"
  using assms by force (* takes a bit long *)

method method_mcs2_guar =
  rule mcs2_guar_subgoals,
  goal_cases locals queue wait knows_succ head_nod

(*==================================================================*)
subsection \<open>Invariant and RG Combined\<close>

lemma mcs2_guar_inv_subgoals:
  assumes "(s1, s2) \<in> mcs2_guar i"
      and "s1 \<in> mcs2_invar \<and> s2 \<in> mcs2_invar"
    shows "(s1, s2) \<in> lift_guar mcs2_invar (mcs2_guar i)"
  using assms mcs2_guar_def
  apply simp
  by meson

method method_mcs2_guar_inv =
  rule mcs2_guar_inv_subgoals,
  goal_cases guar invar

abbreviation mcs2_stable :: "thread_id \<Rightarrow> mcs2_state set \<Rightarrow> bool" where
  "mcs2_stable i S \<equiv> stable (S \<inter> mcs2_invar)
                           (lift_rely mcs2_invar (mcs2_rely i))"

lemma mcs2_stable_subgoals:
  assumes "\<And> s1 s2.
    \<lbrakk> s1 \<in> S \<inter> mcs2_invar ; (s1,s2) \<in> lift_rely mcs2_invar (mcs2_rely i) \<rbrakk>
    \<Longrightarrow> s2 \<in> S"
  shows "mcs2_stable i S"
  unfolding stable_def
  apply clarify
  apply standard
   using assms apply blast
  apply simp
  by metis

method method_mcs2_stable = rule mcs2_stable_subgoals

lemma mcs2_stable_decompose_conjunction:
  "\<lbrakk> mcs2_stable i \<lbrace> p1 \<rbrace> ; mcs2_stable i \<lbrace> p2 \<rbrace> \<rbrakk> \<Longrightarrow> mcs2_stable i \<lbrace> p1 \<and> p2 \<rbrace>"
  unfolding stable_def by blast

lemma mcs2_stable_decompose_conjunction':
  "\<lbrakk> mcs2_stable i \<lbrace> \<acute>p1 \<rbrace> ; mcs2_stable i \<lbrace> \<acute>p2 \<rbrace> \<rbrakk> \<Longrightarrow> mcs2_stable i \<lbrace> \<acute>p1 \<and> \<acute>p2 \<rbrace>"
  unfolding stable_def by blast

lemma mcs2_stable_decompose_intersubsection:
  "\<lbrakk> mcs2_stable i S1 ; mcs2_stable i S2 \<rbrakk> \<Longrightarrow> mcs2_stable i (S1 \<inter> S2)"
  unfolding stable_def by blast

text \<open>Stability lemmas of simple clauses that are used in both Acquire
and Release.\<close>

lemma mcs2_stable_in_queue:
  shows "mcs2_stable i \<lbrace> i \<in> set \<acute>aux_queue \<rbrace>"
    and "mcs2_stable i \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace>"
  by (method_mcs2_stable, simp)+

lemma mcs2_stable_cas_result:
  shows "mcs2_stable i \<lbrace> \<acute>aux_cas_result i \<rbrace>"
    and "mcs2_stable i \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>"
  by (method_mcs2_stable, simp)+

lemma mcs2_stable_succ_null:
  shows "mcs2_stable i \<lbrace> \<acute>succ i = Null \<rbrace>"
    and "mcs2_stable i \<lbrace> \<acute>succ i \<noteq> Null \<rbrace>"
  by (method_mcs2_stable, simp)+

lemma mcs2_stable_prev_null:
  shows "mcs2_stable i \<lbrace> \<acute>prev i \<noteq> Null \<rbrace>"
  by (method_mcs2_stable, simp)

lemma mcs2_stable_at_head:
  "mcs2_stable i \<lbrace> at_head i \<acute>aux_queue \<rbrace>"
(* A SPATIALLY SHORTER BUT TEMPORALLY LONGER PROOF:
  unfolding stable_def mcs2_rely_def
  using stable_at_head by auto *)
proof method_mcs2_stable
  fix s1 s2
  assume "(s1, s2) \<in> lift_rely mcs2_invar (mcs2_rely i)"
  then have "queue_contract i (aux_queue s1) (aux_queue s2)"
    by simp
  moreover
  assume "s1 \<in> \<lbrace> at_head i \<acute>aux_queue \<rbrace> \<inter> mcs2_invar"
  ultimately
  show "s2 \<in> \<lbrace> at_head i \<acute>aux_queue \<rbrace>" using stable_at_head by fast
qed

(*==================================================================*)
subsection \<open>Acquire\<close>

abbreviation mcs2_swap :: "thread_id \<Rightarrow> mcs2_state \<Rightarrow> mcs2_state" where
  "mcs2_swap i \<equiv> (\<acute>prev[i] \<leftarrow> \<acute>tail) \<circ>>
                (\<acute>tail \<leftarrow> \<acute>myptr i) \<circ>>
                (\<acute>aux_queue \<leftarrow> \<acute>aux_queue @ [i])"

abbreviation mcs2_acq :: "thread_id \<Rightarrow> mcs2_state com" where
  "mcs2_acq i \<equiv>
    (\<acute>myptr@i\<rightarrow>\<acute>wait := True) ;;
    (\<acute>myptr@i\<rightarrow>\<acute>next_node := Null) ;;
    Basic (mcs2_swap i) ;;
    (IF \<acute>prev i \<noteq> Null THEN
      (\<acute>prev@i\<rightarrow>\<acute>next_node := \<acute>myptr i) ;;
      (WHILE wait (\<acute>heap (\<acute>myptr i)) DO SKIP OD)
    FI)"

(*------------------------------------------------------------------*)
abbreviation pre_swap :: "thread_id \<Rightarrow> mcs2_state set" where
  "pre_swap i \<equiv> \<lbrace> i \<notin> set \<acute>aux_queue
    \<and> wait (\<acute>mynode i) 
    \<and> next_node (\<acute>mynode i) = Null \<rbrace>"

abbreviation post_swap :: "thread_id \<Rightarrow> mcs2_state set" where
  "post_swap i \<equiv> \<lbrace> i \<in> set \<acute>aux_queue
    \<and> wait (\<acute>mynode i)
    \<and> \<acute>next_of_pred_is_none i \<rbrace>"

abbreviation pre_acq_loop :: "thread_id \<Rightarrow> mcs2_state set" where
  "pre_acq_loop i \<equiv> \<lbrace> i \<in> set \<acute>aux_queue
    \<and> \<acute>next_of_pred_not_none i
    \<and> \<acute>prev i \<noteq> Null \<rbrace>"

(*------------------------------------------------------------------*)
lemma mcs2_stable_post_swap:
  "mcs2_stable i (post_swap i)"
proof method_mcs2_stable
  fix s1 s2
  assume a1: "s1 \<in> (post_swap i) \<inter> mcs2_invar"
  assume a2: "(s1,s2) \<in> lift_rely mcs2_invar (mcs2_rely i)"
  have "s2 \<in> \<lbrace> i \<in> set \<acute>aux_queue \<rbrace>"
    using a1 a2 by simp
  moreover
  have "s2 \<in> \<lbrace> wait (\<acute>mynode i) \<rbrace>"
    using a1 a2 apply clarsimp
    by (metis in_queue_not_hd_pred sublist_ij_j_not_hd)
  moreover
  have "s2 \<in> \<lbrace> \<acute>pred_sat i (\<lambda>h. next_node (\<acute>mynode h) = Null) \<rbrace>"
    using a1 a2 apply simp
    by (metis in_queue_not_hd_pred_distinct)
  ultimately show "s2 \<in> post_swap i" unfolding stable_def by blast
qed

(*------------------------------------------------------------------*)
lemma mcs2_stable_next_of_pred_not_none:
  "mcs2_stable i \<lbrace> \<acute>next_of_pred_not_none i \<rbrace>"
proof method_mcs2_stable
  fix s1 s2
  assume a1: "s1 \<in> \<lbrace> \<acute>next_of_pred_not_none i \<rbrace> \<inter> mcs2_invar"
  assume a2: "(s1, s2) \<in> lift_rely mcs2_invar (mcs2_rely i)"
  { fix h assume "sublist [h,i] (aux_queue s2)"
    moreover have "queue_contract i (aux_queue s1) (aux_queue s2)
                 \<and> distinct (aux_queue s1) \<and> distinct (aux_queue s2)"
      using a1 a2 by auto
    ultimately have ln: "sublist [h,i] (aux_queue s1)"
      by (metis queue_contract_preserves_sublist_pred)
    then have "next_node (mynode s1 h) \<noteq> Null"
      using a1 by blast
    then have "next_node (mynode s2 h) \<noteq> Null"
      using a2 ln by simp }
  then show "s2 \<in> \<lbrace> \<acute>next_of_pred_not_none i \<rbrace>"
    by blast
qed

(*------------------------------------------------------------------*)
subsubsection \<open>RG Theorems\<close>

theorem acq_init_1:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }
  \<acute>myptr@i\<rightarrow>\<acute>wait := True
  { \<lbrace> i \<notin> set \<acute>aux_queue \<and> wait (\<acute>mynode i) \<rbrace> }"
proof method_basic_inv
  case stab_pre
  then show ?case using mcs2_stable_in_queue(2) by blast
next
  case stab_post
  then show ?case by (method_mcs2_stable, clarsimp)
next
  case est_inv
  then show ?case by (simp, metis injD)
next
  case est_guar
  then show ?case using injD by fastforce
qed auto

(*------------------------------------------------------------------*)
theorem acq_init_2:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { \<lbrace> i \<notin> set \<acute>aux_queue \<and> wait (\<acute>mynode i) \<rbrace> }
  \<acute>myptr@i\<rightarrow>\<acute>next_node := Null
  { pre_swap i }"
proof method_basic_inv
  case stab_pre
  then show ?case by (method_mcs2_stable, clarsimp)
next
  case stab_post
  then show ?case by (method_mcs2_stable, clarsimp)
next
  case est_inv
  then show ?case by (simp, metis)
next
  case est_guar
  then show ?case by (simp add: inj_eq)
qed auto

(*------------------------------------------------------------------*)
theorem acq_swap:
  assumes "i < NumThreads"
  shows "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { pre_swap i }
  Basic (mcs2_swap i)
  { post_swap i }"
proof method_basic_inv
  case stab_pre
  then show ?case by (method_mcs2_stable, clarsimp)
next
  case stab_post
  then show ?case using mcs2_stable_post_swap by blast
next
  case est_inv
  then show ?case
  proof (standard, standard, method_mcs2_invar)
    case (mcs2_inv_prev s)
    then show ?case
    proof-
      { fix j assume a0: "j \<in> set (aux_queue (mcs2_swap i s))"
                     (is "j \<in> set (aux_queue ?s)")
        have "prev ?s j = Null \<longrightarrow> at_head j (aux_queue ?s)" (is ?A)
          using mcs2_inv_prev a0 by auto
        moreover
        have "prev ?s j \<noteq> Null \<longrightarrow> wait (mynode ?s j) = (\<not> at_head j (aux_queue ?s))" (is ?B)
          using mcs2_inv_prev a0 by auto
        moreover
        have  "pred_sat ?s j (\<lambda> h. prev ?s j = myptr ?s h)" (is ?C)
          using mcs2_inv_prev a0 apply clarsimp
          by (metis distinct_singleton empty_iff empty_set last_and_opt_last list.sel(1) option.sel sublist_ij_j_not_hd sublist_ij_not_last sublist_ij_opt_last)
        ultimately have "?A \<and> ?B \<and> ?C" by blast }
      then show ?thesis by simp
    qed
  next
    case (mcs2_inv_next s)
    then show ?case
    proof-
      { fix j assume j: "j \<in> set (aux_queue (mcs2_swap i s))" (is "j \<in> set (aux_queue ?s)")
        have "next_node (mynode ?s j) = Null \<or>
          (\<exists> k. next_node (mynode ?s j) = myptr ?s k \<and> sublist [j,k] (aux_queue ?s))"
        proof (cases "i = j")
          case True
          then show ?thesis using mcs2_inv_next by auto
        next
          case False
          then show ?thesis
            apply (cases "j \<in> set (aux_queue s)")
            using mcs2_inv_next sublist_append apply (simp, blast)
            using j by force
        qed }
      then show ?thesis by auto
    qed
        
  qed( use assms in simp_all)
next
  case est_guar
  then show ?case using sublist_append by auto
next
  case est_post
  then show ?case
    by (clarsimp, metis distinct_singleton list.sel(1) opt_last_some_last sublist_ij_j_not_hd sublist_ij_opt_last)
qed auto

(*------------------------------------------------------------------*)
theorem acq_if_1:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { post_swap i \<inter> \<lbrace> \<acute>prev i \<noteq> Null \<rbrace> }
  \<acute>prev@i\<rightarrow>\<acute>next_node := \<acute>myptr i
  { pre_acq_loop i }"
proof method_basic_inv
  case stab_pre
  then show ?case 
    apply (rule mcs2_stable_decompose_intersubsection)
    using mcs2_stable_post_swap apply fast
    using mcs2_stable_prev_null by fast
next
  case stab_post
  then show ?case
    apply (intro mcs2_stable_decompose_conjunction')
    using mcs2_stable_in_queue(1) apply blast
    using mcs2_stable_next_of_pred_not_none apply blast
    using mcs2_stable_prev_null by blast
next
  case est_inv
  then show ?case
  proof (standard, standard, method_mcs2_invar)
    case (mcs2_inv_prev s)
    then show ?case apply simp
      by metis
  next
    case (mcs2_inv_next s)
    then show ?case apply simp
      by (metis in_queue_not_hd_pred inj_def)
  next
    case (mcs2_inv_last s)
    then show ?case apply simp
      by (metis in_queue_not_hd_pred_distinct injD sublist_ij_i_not_last)
  qed simp_all
next
  case est_guar
  then show ?case
  proof (standard, standard, method_mcs2_guar)
    case (knows_succ s)
    then show ?case using est_guar apply clarsimp
      by (metis in_queue_not_hd_pred_distinct inj_eq)
  qed auto
qed auto

(*------------------------------------------------------------------*)
theorem acq_if_2:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { pre_acq_loop i }
  WHILE wait (\<acute>heap (\<acute>myptr i)) DO SKIP OD
  { \<lbrace> at_head i \<acute>aux_queue \<rbrace> }"
proof method_spinloop
  case stable_pre
  then show ?case
    using mcs2_stable_in_queue(1)
          mcs2_stable_next_of_pred_not_none
          mcs2_stable_prev_null
          mcs2_stable_decompose_conjunction'
    by presburger
next
  case stable_post
  then show ?case
    apply method_mcs2_stable
    using stable_at_head by auto
qed auto

(*==================================================================*)
subsection \<open>Release\<close>

text \<open>Overview of the instructions and assertions of Release.\<close>

abbreviation mcs2_cas :: "thread_id \<Rightarrow> mcs2_state \<Rightarrow> mcs2_state" where
  "mcs2_cas i s \<equiv> (if tail s = myptr s i
    then ((\<acute>tail \<leftarrow> Null) \<circ>>
          (\<acute>aux_cas_result[i] \<leftarrow> True) \<circ>>
          (\<acute>aux_queue \<leftarrow> [])) s
    else (\<acute>aux_cas_result[i] \<leftarrow> False) s)"

abbreviation mcs2_update_flag :: "thread_id \<Rightarrow> mcs2_state \<Rightarrow> mcs2_state" where
  "mcs2_update_flag i s \<equiv> s\<lparr>
    heap := fun_upd (heap s)
                    (succ s i)
                    ((heap s (succ s i))\<lparr>wait := False \<rparr>),
    aux_queue := tl (aux_queue s) \<rparr>"

abbreviation mcs2_rel :: "thread_id \<Rightarrow> mcs2_state com" where
  "mcs2_rel i \<equiv>
    \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i)) ;;
    \<acute>aux_cas_result[i] := False ;;
    (IF \<acute>succ i = Null THEN
      Basic (mcs2_cas i) ;;
      (IF \<not> \<acute>aux_cas_result i THEN
        \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i)) ;;
        WHILE \<acute>succ i = Null DO
          \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i))
        OD
      FI)
    FI) ;;
    (IF \<not> \<acute>aux_cas_result i THEN
      Basic (mcs2_update_flag i)
    FI)"

(*------------------------------------------------------------------*)
subsubsection \<open>Midpoints' Parts\<close>

(*------------------------------------------------------------------*)
abbreviation succ_null_or_some :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "succ_null_or_some s i \<equiv> succ s i = Null \<or>
    (\<forall> j. succ s i = myptr s j \<longrightarrow> sublist [i,j] (aux_queue s))"

lemma mcs2_stable_succ_null_or_some:
  "mcs2_stable i \<lbrace> \<acute>succ_null_or_some i \<rbrace>"
proof method_mcs2_stable
  fix s1 s2
  assume ap: "s1 \<in> \<lbrace> \<acute>succ_null_or_some i \<rbrace> \<inter> mcs2_invar"
  assume ar: "(s1, s2) \<in> lift_rely mcs2_invar (mcs2_rely i)"
  show "s2 \<in> \<lbrace> \<acute>succ_null_or_some i \<rbrace>"
  proof-
    { fix j assume aa: "succ s2 i \<noteq> Null \<and> succ s2 i = myptr s2 j"
      then have "succ s1 i \<noteq> Null"
        using ar mcs2_contract_locals_id_def by (simp, argo)
      then have "succ s1 i = myptr s1 j \<longrightarrow> sublist [i,j] (aux_queue s1)"
        using ap by blast
      moreover have "succ s1 i = myptr s1 j"
        using aa ar by simp
      ultimately have "sublist [i,j] (aux_queue s1)"
        by blast
      moreover have "queue_contract i (aux_queue s1) (aux_queue s2)"
        using ar by simp
      moreover have "distinct (aux_queue s1) \<and> distinct (aux_queue s2)"
        using ap ar by simp
      ultimately have "sublist [i,j] (aux_queue s2)"
        using queue_contract_preserves_sublist_succ by meson }
  then show ?thesis by blast
  qed
qed

(*------------------------------------------------------------------*)
abbreviation succ_next_link :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "succ_next_link s i \<equiv> succ s i \<noteq> Null \<longrightarrow> succ s i = next_node (mynode s i)"

lemma mcs2_stable_succ_next_link:
  "mcs2_stable i \<lbrace> \<acute>succ_next_link i \<rbrace>"
proof method_mcs2_stable
  fix s1 s2
  assume ap: "s1 \<in> \<lbrace> \<acute>succ_next_link i \<rbrace> \<inter> mcs2_invar"
  assume ar: "(s1, s2) \<in> lift_rely mcs2_invar (mcs2_rely i)"
  show "s2 \<in> \<lbrace> \<acute>succ_next_link i \<rbrace>"
  proof-
    { assume aa: "succ s2 i \<noteq> Null"
      have "succ s2 i = succ s1 i"
        using ar by simp
      also have "... = next_node (mynode s1 i)"
        using aa ap calculation by force
      also have "... = next_node (mynode s2 i)"
        using aa ar calculation by clarsimp
      ultimately have "succ s2 i = next_node (mynode s2 i)"
        by force }
    then show ?thesis by blast
  qed
qed

(*------------------------------------------------------------------*)
abbreviation has_succ :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "has_succ s i \<equiv> \<exists> j. sublist [i,j] (aux_queue s)"

lemma mcs2_stable_has_succ:
  "mcs2_stable i \<lbrace> \<acute>has_succ i \<rbrace>"
  apply method_mcs2_stable
  apply simp
  by (metis distinct.simps(2) distinct_singleton hd_in_set head_of_suffix_implies_sublist prefix_code(1) prefix_order.dual_order.antisym sublist_ij_suffix_in_j suffix_after_nonempty)

(*------------------------------------------------------------------*)
abbreviation cas_if_then_else :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "cas_if_then_else s i \<equiv> (if aux_cas_result s i
    then i \<notin> set (aux_queue s)
    else at_head i (aux_queue s) \<and> has_succ s i)"

lemma mcs2_stable_cas_if:
  "mcs2_stable i \<lbrace> \<acute>cas_if_then_else i \<rbrace>"
  apply method_mcs2_stable
  apply simp
  by (metis all_not_in_conv empty_set hd_in_set head_of_suffix_implies_sublist prefix_code(1) prefix_order.dual_order.antisym sublist_ij_suffix_in_j)

(*------------------------------------------------------------------*)
abbreviation knows_succ :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "knows_succ s i \<equiv> succ s i \<noteq> Null \<and>
                    succ s i = next_node (mynode s i)"

lemma mcs2_stable_knows_succ:
  "mcs2_stable i \<lbrace> \<acute>knows_succ i \<rbrace>"
  apply method_mcs2_stable
  apply simp
  by metis

(*------------------------------------------------------------------*)
abbreviation pre_last_block :: "mcs2_state \<Rightarrow> thread_id \<Rightarrow> bool" where
  "pre_last_block s i \<equiv> (if aux_cas_result s i
    then i \<notin> set (aux_queue s)
    else at_head i (aux_queue s) \<and> knows_succ s i)"

lemma mcs2_stable_pre_last:
  "mcs2_stable i \<lbrace> \<acute>pre_last_block i \<rbrace>"
  apply method_mcs2_stable
  apply simp
  by metis

(*==================================================================*)
subsubsection \<open>Actual Midpoints\<close>

(* Release:
 1  \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i)) ;;
 2  \<acute>aux_cas_result[i] := False ;;
 3  (IF \<acute>succ i = Null THEN
 4    Basic (mcs2_cas i) ;;
 5    (IF \<not> \<acute>aux_cas_result i THEN
 6      \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i)) ;;
 7      (WHILE \<acute>succ i = Null DO
 8        \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i))
 9      OD)
10    FI)
11  FI) ;;
12  (IF \<not> \<acute>aux_cas_result i THEN
13    Basic (mcs2_update_flag i)
14  FI)"
*)

text \<open>Below, each midpoint is identified by its preceding instruction.\<close>

abbreviation midpoint_rel_1 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_1 i \<equiv> \<lbrace> at_head i \<acute>aux_queue \<and> \<acute>succ_null_or_some i \<and> \<acute>succ_next_link i \<rbrace>"

abbreviation midpoint_rel_2 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_2 i \<equiv> \<lbrace> at_head i \<acute>aux_queue \<and> \<acute>succ_null_or_some i \<and> \<acute>succ_next_link i \<and> \<not> \<acute>aux_cas_result i \<rbrace>"

abbreviation midpoint_rel_3 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_3 i \<equiv> \<lbrace> at_head i \<acute>aux_queue \<and> \<acute>succ_null_or_some i \<and> \<acute>succ_next_link i \<and> \<not> \<acute>aux_cas_result i  \<and> \<acute>succ i = Null \<rbrace>"

abbreviation midpoint_rel_4 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_4 i \<equiv> \<lbrace> \<acute>cas_if_then_else i \<and> \<acute>succ_null_or_some i \<and> \<acute>succ_next_link i \<and> \<acute>succ i = Null \<rbrace>"

abbreviation midpoint_rel_5 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_5 i \<equiv> \<lbrace> \<not> \<acute>aux_cas_result i \<and> at_head i \<acute>aux_queue \<and> \<acute>has_succ i \<and> \<acute>succ_next_link i \<and> \<acute>succ i = Null \<rbrace>"

abbreviation midpoint_rel_6 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_6 i \<equiv> \<lbrace>  \<not> \<acute>aux_cas_result i \<and> at_head i \<acute>aux_queue \<and> \<acute>has_succ i \<and> \<acute>succ_next_link i \<and> \<acute>succ_null_or_some i \<rbrace>"

abbreviation midpoint_rel_9 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_9 i \<equiv> \<lbrace> \<not> \<acute>aux_cas_result i \<and> at_head i \<acute>aux_queue \<and> \<acute>knows_succ i \<rbrace>"

abbreviation midpoint_rel_11 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_11 i \<equiv> \<lbrace> \<acute>pre_last_block i \<rbrace>"

abbreviation midpoint_rel_12 :: "thread_id \<Rightarrow> mcs2_state set" where
  "midpoint_rel_12 i \<equiv> midpoint_rel_9 i"


(*==================================================================*)
subsubsection \<open>RG Theorems\<close>

theorem rel_init_1:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { \<lbrace> at_head i \<acute>aux_queue \<rbrace> }
  \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i))
  { midpoint_rel_1 i }"
proof method_basic_inv
  case stab_pre
  then show ?case using mcs2_stable_at_head by blast
next
  case stab_post
  then show ?case
    using mcs2_stable_at_head
          mcs2_stable_succ_null_or_some
          mcs2_stable_succ_next_link
          mcs2_stable_decompose_conjunction'
    by meson
next
  case est_post
  then show ?case by (simp, metis injD)
qed auto

(*------------------------------------------------------------------*)
theorem rel_init_2:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { midpoint_rel_1 i }
  \<acute>aux_cas_result[i] := False
  { midpoint_rel_2 i }"
proof method_basic_inv
  case stab_pre
  then show ?case
    using mcs2_stable_at_head
          mcs2_stable_succ_null_or_some
          mcs2_stable_succ_next_link
          mcs2_stable_decompose_conjunction'
    by meson
next
  case stab_post
  then show ?case
    using mcs2_stable_at_head
          mcs2_stable_succ_null_or_some
          mcs2_stable_succ_next_link
          mcs2_stable_cas_result(2)
          mcs2_stable_decompose_conjunction'
    by meson
qed auto

(*------------------------------------------------------------------*)
theorem rel_cas:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { midpoint_rel_3 i }
  Basic (mcs2_cas i)
  { midpoint_rel_4 i }"
proof method_basic_inv
  case stab_pre
  then show ?case
    using mcs2_stable_at_head
          mcs2_stable_succ_null_or_some
          mcs2_stable_succ_next_link
          mcs2_stable_cas_result(2)
          mcs2_stable_succ_null(1)
          mcs2_stable_decompose_conjunction'
    by meson
next
  case stab_post
  then show ?case
    using mcs2_stable_cas_if
          mcs2_stable_succ_null_or_some
          mcs2_stable_succ_next_link
          mcs2_stable_succ_null(1)
          mcs2_stable_decompose_conjunction'
    by meson
next
  case est_post
  then show ?case
  proof (standard, standard, standard, intro conjI, goal_cases cas_if)
    case (cas_if s)
    then show ?case
    proof (cases "aux_cas_result (mcs2_cas i s) i")
      case True
      then show ?thesis using mcs2_state.surjective by force
    next
      case False
      then have guard: "tail s \<noteq> myptr s i"
        by force
      then have "at_head i (aux_queue (mcs2_cas i s))"
        using cas_if by auto
      moreover
      have "i \<noteq> last (aux_queue s)"
      proof-
        have "s \<in> mcs2_inv_tail"
          using cas_if by simp
        moreover have "aux_queue s \<noteq> []"
          using cas_if by force
        ultimately have "tail s = myptr s (last (aux_queue s))"
          using mcs2_inv_tail_def by (metis (mono_tags, lifting) CollectD)
        then have "myptr s i \<noteq> myptr s (last (aux_queue s))"
          using guard by presburger
        then show ?thesis using inj_eq by blast
      qed
      then have "has_succ s i"
        by (metis (no_types, lifting) IntD1 cas_if mem_Collect_eq opt_last_not_none opt_last_some_last)
      then have "has_succ (mcs2_cas i s) i"
        using guard by simp
      ultimately show ?thesis using False by presburger
    qed
  qed auto
next
  case est_guar
  then show ?case
  proof (standard, standard, method_mcs2_guar)
    case (queue s)
    then show ?case
    proof (cases "tail s = myptr s i")
      case True
      have "tail s = myptr s (last (aux_queue s))"
        using queue by auto
      moreover have "inj (myptr s)"
        using queue by simp
      ultimately have "i = last (aux_queue s)"
        using True by (simp add: inj_eq)
      moreover have "at_head i (aux_queue s)"
        using queue by fast
      moreover have "distinct (aux_queue s)"
        using queue by simp
      ultimately have "aux_queue s = [i]"
        by (metis distinct.simps(2) distinct_singleton last_and_opt_last opt_last_at_head)
      then show ?thesis by simp
    next
      case False
      then show ?thesis by force
    qed
  next
    case (head_nod s)
    then show ?case
      by (clarsimp, metis injD sublist_ij_i_not_last)
  qed auto
qed auto

(*------------------------------------------------------------------*)
theorem rel_loop_body:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { midpoint_rel_5 i }
  \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i))
  { midpoint_rel_6 i }"
proof method_basic_inv
  case stab_pre
  then show ?case
    using mcs2_stable_cas_result(2)
          mcs2_stable_at_head
          mcs2_stable_has_succ
          mcs2_stable_succ_next_link
          mcs2_stable_succ_null(1)
          mcs2_stable_decompose_conjunction'
    by meson
next
  case stab_post
  then show ?case
    using mcs2_stable_cas_result(2)
          mcs2_stable_at_head
          mcs2_stable_has_succ
          mcs2_stable_succ_next_link
          mcs2_stable_succ_null_or_some
          mcs2_stable_decompose_conjunction'
    by meson
next
  case est_post
  then show ?case
  proof (standard, standard, standard, intro conjI, goal_cases)
    case (6 s)
    then have "i \<in> set (aux_queue s) \<and> s \<in> mcs2_inv_next"
      by simp
    then have "next_node (mynode s i) = Null \<or>
      (\<exists> j. next_node (mynode s i) = myptr s j \<and> sublist [i,j] (aux_queue s))"
      by simp
    moreover
    have "succ (s\<lparr>succ := (succ s)(i := next_node (mynode s i))\<rparr>) i
        = next_node (mynode s i)" (is "succ ?s i = next_node (mynode s i)")
      by simp
    ultimately
    have "succ ?s i = Null \<or>
      (\<exists> j. succ ?s i = myptr s j \<and> sublist [i,j] (aux_queue s))"
      by presburger
    then show ?case
      using 6 apply simp
      by (metis (no_types, lifting) injD)
  qed auto
qed auto

(*------------------------------------------------------------------*)
theorem rel_loop:
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { midpoint_rel_6 i }
  WHILE \<acute>succ i = Null DO
    \<acute>succ[i] := next_node (\<acute>heap (\<acute>myptr i))
  OD
  { midpoint_rel_9 i }"
proof method_loop
  case stable_pre show ?case
    using mcs2_stable_cas_result(2)
          mcs2_stable_at_head
          mcs2_stable_has_succ
          mcs2_stable_succ_next_link
          mcs2_stable_succ_null_or_some
          mcs2_stable_decompose_conjunction'
    by meson
next
  case stable_post
  then show ?case 
    using mcs2_stable_cas_result(2)
          mcs2_stable_at_head
          mcs2_stable_knows_succ
          mcs2_stable_decompose_conjunction'
    by meson
next
  case id_guar
  then show ?case using lift_guar_def by blast
next
  case loop_exit
  then show ?case by blast
next
  case loop_body
  have "\<lbrace> \<not> \<acute>aux_cas_result i \<and> at_head i \<acute>aux_queue \<and> \<acute>has_succ i \<and>
          \<acute>succ_next_link i \<and> \<acute>succ_null_or_some i\<rbrace> \<inter> mcs2_invar \<inter> \<lbrace>\<acute>succ i = Null\<rbrace>
      \<subseteq> \<lbrace> \<not> \<acute>aux_cas_result i \<and> at_head i \<acute>aux_queue \<and> \<acute>has_succ i \<and>
          \<acute>succ_next_link i \<and> \<acute>succ i = Null \<rbrace> \<inter> mcs2_invar"
    by blast
  then show ?case using rel_loop_body strengthen_pre by fast
qed

(*------------------------------------------------------------------*)
theorem rel_final:
  assumes "i < NumThreads"
  shows
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { midpoint_rel_12 i }
  Basic (mcs2_update_flag i)
  { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }"
proof method_basic_inv
  case stab_pre
  then show ?case
    using mcs2_stable_cas_result(2)
          mcs2_stable_at_head
          mcs2_stable_knows_succ
          mcs2_stable_decompose_conjunction'
    by meson
next
  case stab_post
  then show ?case using mcs2_stable_in_queue(2) by fast
next
  case id_guar
  then show ?case by auto
next
  case est_inv
  then show ?case
  proof (standard, standard, method_mcs2_invar)
    case (mcs2_inv_prev s)
    then show ?case unfolding mcs2_inv_prev_def apply simp
      by (metis at_head_tl injD list.sel(2) list.set_sel(2) sublist_ij_hd_tl tl_preserves_sublist)
  next
    case (mcs2_inv_next s)
    then show ?case unfolding mcs2_inv_next_def apply simp
      by (metis list.sel(2) list.set_sel(2) sublist_ij_holds_on_tl)
  next
    case (mcs2_inv_tail s)
    then show ?case unfolding mcs2_inv_tail_def apply simp
      by (metis last_ConsL last_tl list.collapse)
  next
    case (mcs2_inv_last s)
    then show ?case unfolding mcs2_inv_last_def apply simp
      by (metis Nil_tl last_tl)
  next
    case (mcs2_inv_ptr s)
    then show ?case by simp
  next
    case (mcs2_inv_queue s)
    then show ?case 
      unfolding mcs2_inv_queue_def
      apply standard
      apply standard
      apply standard
      using distinct_tl apply auto[1]
      using assms apply simp
      by (metis dual_order.trans set_mono_suffix suffix_tl)
  qed
next
  case est_post
  then show ?case by (simp add: at_head_tl)
next
  case est_guar
  then show ?case (* cvc4 finds proofs but times out. *)
  proof (standard, standard, method_mcs2_guar)
    case (locals s)
    then show ?case by simp
  next
    case (queue s)
    then show ?case apply simp
      by (metis ComplD insertCI list.collapse list.sel(2) list.set_sel(2) prefix_order.dual_order.refl set_ConsD suffix_tl tl_prefix_before tl_suffix_after)
  next
    case (wait s)
    then show ?case apply simp
      by (metis hd_in_set injD last_ConsL list.collapse list.sel(2) list.set_sel(2) sublist_ij_hd_tl)
  next
    case (knows_succ s)
    then show ?case by simp
  next
    case (head_nod s)
    then show ?case by (simp, metis)
  qed
qed

(*==================================================================*)
subsection \<open>Combined RG Theorems\<close>

method method_seq for m :: "mcs2_state set" =
  rule Seq[where mid = "m \<inter> mcs2_invar"], goal_cases

theorem mcs2_acq_overall:
  assumes "i < NumThreads"
  shows
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }
  mcs2_acq i
  { \<lbrace> at_head i \<acute>aux_queue \<rbrace> }"
proof (method_seq "post_swap i", goal_cases init_swap if_block)
  case init_swap show ?case
  proof (method_seq "pre_swap i", goal_cases init swap)
    case init show ?case
    proof (method_seq "\<lbrace> i \<notin> set \<acute>aux_queue \<and> wait (\<acute>mynode i) \<rbrace>")
      case 1 show ?case using acq_init_1 by fast
      case 2 show ?case using acq_init_2 by fast
    qed
    case swap show ?case using acq_swap assms by fast
  qed
  case if_block show ?case
  proof method_cond
    case stab_pre  show ?case using mcs2_stable_post_swap by fast
    case stab_post show ?case using mcs2_stable_at_head   by fast
    case guar_id   show ?case using lift_guar_def by fast
  next
    case then_br show ?case 
    proof (method_seq "pre_acq_loop i")
      case 1 show ?case using acq_if_1 by (simp add: Int_assoc Int_commute)
      case 2 show ?case using acq_if_2 by fast
    qed
  next
    case else_br show ?case by force
  qed
qed

(*------------------------------------------------------------------*)
theorem mcs2_rel_overall:
  assumes "i < NumThreads"
  shows
  "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
  { \<lbrace> at_head i \<acute>aux_queue \<rbrace> }
  mcs2_rel i
  { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }"
proof (method_seq "midpoint_rel_11 i")
  case 1 show ?case
  proof (method_seq "midpoint_rel_2 i", goal_cases init block)
    case init show ?case
    proof (method_seq "midpoint_rel_1 i")
      case 1 show ?case using rel_init_1 by presburger
      case 2 show ?case using rel_init_2 by presburger
    qed
  next
    case block show ?case
    proof method_cond
      case stab_pre show ?case
        using mcs2_stable_at_head
              mcs2_stable_succ_null_or_some
              mcs2_stable_succ_next_link
              mcs2_stable_cas_result(2)
              mcs2_stable_decompose_conjunction'
        by meson
    next
      case stab_post show ?case using mcs2_stable_pre_last by blast
      case guar_id   show ?case using lift_guar_def by fast
      case else_br   show ?case by auto
    next
      case then_br show ?case
      proof (method_seq "midpoint_rel_4 i", goal_cases cas block)
        case cas
        have "midpoint_rel_2 i \<inter> mcs2_invar \<inter> \<lbrace> \<acute>succ i = Null \<rbrace>
            = midpoint_rel_3 i \<inter> mcs2_invar"
          by fast
        then show ?case using rel_cas by presburger
      next
        case block show ?case
        proof method_cond
          case stab_pre show ?case
            using mcs2_stable_cas_if
                  mcs2_stable_succ_null_or_some
                  mcs2_stable_succ_next_link
                  mcs2_stable_succ_null(1)
                  mcs2_stable_decompose_conjunction'
            by meson
        next
          case stab_post show ?case using mcs2_stable_pre_last by blast
          case guar_id   show ?case by force
          case else_br   show ?case by force
        next
          case then_br show ?case
          proof (method_seq "midpoint_rel_6 i")
            case 1
            have "midpoint_rel_4 i \<inter> mcs2_invar \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>
                \<subseteq> midpoint_rel_5 i \<inter> mcs2_invar"
              by force
            then show ?case using rel_loop_body strengthen_pre by fast
          next
            case 2
            have "midpoint_rel_9 i \<inter> mcs2_invar
               \<subseteq> midpoint_rel_11 i \<inter> mcs2_invar"
              by auto
            then show ?case using rel_loop weaken_post by fast
          qed
        qed
      qed
    qed
  qed
next
  case 2 show ?case
  proof method_cond
    case stab_pre  show ?case using mcs2_stable_pre_last by blast
    case stab_post show ?case using mcs2_stable_in_queue(2) by presburger
    case then_br
    have "midpoint_rel_11 i \<inter> mcs2_invar \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>
        = midpoint_rel_12 i \<inter> mcs2_invar"
      by force
    then show ?case using rel_final assms by presburger
  qed (fastforce+)
qed

(*------------------------------------------------------------------*)
theorem mcs2_local_loop:
  assumes "i < NumThreads"
  shows "rely: mcs2_rely i  guar: mcs2_guar i  inv: mcs2_invar  code:
      { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }
    WHILE True DO (mcs2_acq i ;; mcs2_rel i) OD
      { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }"
proof method_loop
  case stable_pre  show ?case using mcs2_stable_in_queue(2) by fast
  case stable_post show ?case using mcs2_stable_in_queue(2) by fast
  case id_guar     show ?case using lift_guar_def by fast
  case loop_exit   show ?case by fast
next
  case loop_body show ?case
  proof (method_seq "\<lbrace> at_head i \<acute>aux_queue \<rbrace>", goal_cases acq rel)
    case acq
    then show ?case using mcs2_acq_overall assms by auto
  next
    case rel
    then show ?case using mcs2_rel_overall assms by fast
  qed
qed

(*==================================================================*)
subsection \<open>Global RG Theorems\<close>

lemma guar_implies_rely_lma':
  assumes assm_i_j:  "i \<noteq> j"
      and assm_guar: "(s1, s2) \<in> mcs2_guar i"
      and assm_pre: "s1 \<in> mcs2_invar \<and> s2 \<in> mcs2_invar"
    shows "(s1, s2) \<in> mcs2_rely j"
unfolding mcs2_rely_def
proof (intro IntI)
  from assm_guar assm_pre 
  have ln_s2: "s2 \<in> mcs2_invar \<and> (s1,s2) \<in> mcs2_guar i"
    by fastforce
  then have g_nod: "(s1,s2) \<in> mcs2_guar_knows_succ i"
    by simp
  show "(s1,s2) \<in> mcs2_contract_locals_id j"
   and "(s1,s2) \<in> mcs2_contract_queue j"
   and "(s1,s2) \<in> mcs2_contract_wait j"
    using ln_s2 assm_i_j unfolding mcs2_guar_def by fast+
  show "(s1,s2) \<in> mcs2_rely_knows_succ j"
  proof-
    { assume "next_node (mynode s1 j) \<noteq> next_node (mynode s2 j)"
      then have ln1: "next_node (mynode s1 j) = Null
                    \<and> next_node (mynode s2 j) \<noteq> Null
                    \<and> prev s1 i = myptr s1 j
                    \<and> sublist [j,i] (aux_queue s1)"
        using g_nod assm_i_j by simp
      have ln2: "sublist [j,i] (aux_queue s2)"
      proof (rule queue_contract_preserves_sublist_succ[where ?xs = "aux_queue s1"], goal_cases)
        case 1 show ?case using ln_s2 assms(1) by simp
        case 2 show ?case using assm_pre ln_s2 by simp
        case 3 show ?case using ln1 by blast
      qed
      then have "j \<in> set (aux_queue s2)"
        by (metis in_set_conv_decomp sublist_ij_explicit)
      moreover have "j \<noteq> last (aux_queue s2)"
        apply (rule sublist_ij_i_not_last[where ?j = i])
        using assm_pre apply simp
        using ln2 by fast
      ultimately have ?thesis using ln1 by force }
    then show ?thesis by fastforce
  qed
  show "(s1,s2) \<in> mcs2_rely_prev j"
  proof-
    { fix h assume a: "sublist [h,j] (aux_queue s1)"
      have "next_node (mynode s1 h) = next_node (mynode s2 h)"
      proof (cases "h = i")
        case True
        then show ?thesis
          using a ln_s2 apply clarsimp
          by (metis in_set_conv_decomp sublist_ij_explicit)
      next
        case False
        then show ?thesis
          using a g_nod assm_i_j assm_pre apply clarsimp
          by (metis sublist_ij_suffix_hd_j)
      qed }
    then show ?thesis by simp
  qed
  show "(s1,s2) \<in> mcs2_rely_head j"
  proof-
    { fix h assume a: "sublist [h,j] (aux_queue s1) \<and> next_node (mynode s1 h) = Null"
      have "sublist [h,j] (aux_queue s2)"
      proof (cases "h = i")
        case True
        then show ?thesis
          using a ln_s2 mcs2_guar_head_def by fastforce
      next
        case False
        then have "queue_contract h (aux_queue s1) (aux_queue s2)"
          using ln_s2 by simp
        moreover have "distinct (aux_queue s1) \<and> distinct (aux_queue s2)"
          using assm_pre ln_s2 by simp
        ultimately show ?thesis
          by (metis a queue_contract_preserves_sublist_succ)
      qed }
    then show ?thesis by simp
  qed
qed

lemma guar_implies_rely_lma:
  assumes assm_i_j:  "i \<noteq> j"
      and assm_guar: "(s1, s2) \<in> lift_guar mcs2_invar (mcs2_guar i)"
    shows "(s1, s2) \<in> lift_rely mcs2_invar (mcs2_rely j)"
proof-
  have ln1: "s1 = s2 \<or> (s1 \<in> mcs2_invar \<and> s2 \<in> mcs2_invar \<and> (s1, s2) \<in> mcs2_guar i)"
    using assm_guar lift_guar_def by blast
  moreover
  { assume a: "s1 \<noteq> s2"
    then have "(s1, s2) \<in> mcs2_rely j"
      using assms guar_implies_rely_lma' ln1 by blast
    moreover have "s1 \<in> mcs2_invar \<longrightarrow> s2 \<in> mcs2_invar"
      using ln1 a by auto
    ultimately have ?thesis using lift_rely_def by blast }
  ultimately show ?thesis by fastforce
qed

theorem mcs2_global:
  assumes "0 < NumThreads" shows
  "global_init: mcs2_init  global_rely: Id
    \<parallel> i < NumThreads @
      { \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace>, mcs2_rely i }
    WHILE True DO (mcs2_acq i ;; mcs2_rel i) OD
      \<sslash> mcs2_invar
      { mcs2_guar i, \<lbrace> i \<notin> set \<acute>aux_queue \<rbrace> }
  global_guar: UNIV global_post: \<lbrace>  \<acute>aux_queue = [] \<rbrace>"
proof method_multi_parallel
  case guar_rely
  then show ?case using guar_implies_rely_lma by (metis subrelI)
next
  case pre
  then show ?case
    apply standard
    apply standard
    apply standard
    by (metis (mono_tags, lifting) IntI empty_iff empty_set init_invar mcs2_init_def mem_Collect_eq)
next
  case rely
  then show ?case by force
next
  case guar
  then show ?case by fast
next
  case post
  then show ?case
    using assms apply simp
    apply auto
    apply (meson lessThan_iff list.set_sel(1) subsetD)
    by metis
next
  case body
  then show ?case using mcs2_local_loop by auto
qed

(*==================================================================*)
end
