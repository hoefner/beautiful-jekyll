
(*
Title:  RG Verification of the MCS Lock -- the Intermediate Version
Author(s):     Robert Colvin, Scott Heiner, Peter Hoefner, Roger Su
Year:          2026
License:       BSD 2-Clause
Maintainer(s): Robert Colvin <r.colvin@uq.edu.au>
               Peter Hoefner <peter@hoefner-online.de>
               Roger Su <roger.c.su@proton.me>
*)

(* To load this file in the Isabelle IDE, run the following command
in the parent directory (above "afp2"):
  isabelle jedit -d . -R RG_MCS_CLH
*)

section \<open>MCS: Intermediate Version\<close>

text \<open>This is an \emph{intermediate} version of the MCS Lock that 
abstracts most details away, and retains only the MCS Lock's most 
characteristic aspect, which is the loop in \emph{release}.

This loop is necessary due to the potential situation where a releasing
thread knows that it is not at the tail of the queue (after the CAS
returns False) but does not yet know the identity of its successor.
The purpose of the loop is to load the information about the successor.

In this abstraction, a thread can access the abstract queue directly to
check whether it is at the tail of the queue. Whether or not a thread
knows the identity of its successor, we model this with a local
variable @{text knows_succ} per thread; @{text "knows_succ i"} is True 
if and only if Thread @{text i} knows the identity of its successor in 
the queue.\<close>

theory MCS_0

imports
  "RGLocks.Concurrent_Queue_Contract"
  "RGLocks.RG_Syntax_Extensions"

begin

type_synonym thread_id = nat

consts NumThreads :: nat

record mcs0_state =
  knows_succ  :: "thread_id \<Rightarrow> bool"
  wait :: "thread_id \<Rightarrow> bool"
  prev :: "thread_id \<Rightarrow> thread_id option"
  queue :: "thread_id list"
  aux_cas_result :: "thread_id \<Rightarrow> bool"

text \<open>Below is the pseudocode:

\begin{minipage}[t]{7cm}
\begin{verbatim}
  Acquire:
 1  nod[i] := False
 2  wait[i] := True
 3  < prev[i] := opt_last queue ;
 4    queue := queue @ [i] >
 5  IF prev[i] != None THEN
 6    nod[ prev[i] ] := True
 7    WHILE wait[i] DO SKIP OD
 8  FI
\end{verbatim}
\end{minipage}
\begin{minipage}[t]{7cm}
\begin{verbatim}
  Release:
 1  aux_cas_result := False
 2  < IF opt_last queue = Some i THEN
 3     aux_cas_result := True
 4      queue := []
 5  FI >
 6  IF ! aux_cas_result THEN
 7    WHILE ! nod[i] DO SKIP DO
 8    < queue := tl queue ;
 9      wait[ hd queue ] := False >
10  FI
\end{verbatim}
\end{minipage}\<close>
(*
  Acquire:
 1  nod[i] := False
 2  wait[i] := True
 3  \<langle> prev[i] := opt_last queue ;
 4    queue := queue @ [i] \<rangle>
 5  IF prev[i] \<noteq> None THEN
 6    nod[ prev[i] ] := True
 7    WHILE wait[i] DO SKIP OD
 8  FI
  
  Release:
 1  aux_cas_result := False
 2  \<langle> IF opt_last queue = Some i THEN
 3     aux_cas_result := True
 4      queue := []
 5  FI \<rangle>
 6  IF \<not> aux_cas_result THEN
 7    WHILE \<not> nod[i] DO SKIP DO
 8    \<langle> queue := tl queue ;
 9      wait[ hd queue ] := False \<rangle>
10  FI
*)

text \<open>All other variables are initialised in the code, so they do not
need to be explicitly mentioned in the definition of the initial state.\<close>

definition mcs0_init :: "mcs0_state set" where
  "mcs0_init \<equiv> \<lbrace> \<acute>queue = [] \<and> \<acute>prev = (\<lambda>i. None) \<rbrace>"

text \<open>A useful notion that will be used multiple times later.\<close>

abbreviation pred_sat
  :: "mcs0_state \<Rightarrow> thread_id \<Rightarrow> (thread_id \<Rightarrow> bool) \<Rightarrow> bool" where
  "pred_sat s i p \<equiv> \<forall> h. sublist [h,i] (queue s) \<longrightarrow> p h"

(*==================================================================*)
subsection \<open>Invariant\<close>

text \<open>The main part of the invariant is @{text mcs0_inv_prev}.\<close>

definition mcs0_inv_prev :: "mcs0_state set" where
  "mcs0_inv_prev \<equiv> \<lbrace> \<forall> i. \<acute>prev i \<noteq> Some i \<and>
    (i \<in> set \<acute>queue \<longrightarrow>
        (\<acute>prev i = None \<longrightarrow> at_head i \<acute>queue)
      \<and> (\<acute>prev i \<noteq> None \<longleftrightarrow> \<acute>wait i = (\<not> at_head i \<acute>queue))
      \<and> (\<acute>pred_sat i (\<lambda> h. \<acute>prev i = Some h))) \<rbrace>"

text \<open>This definition contains three implication-clauses, which are
detailed below.

\begin{itemize}

\item
For every Thread @{text i} in the queue, if @{term \<open>prev i\<close>} is None,
then it must be the case that @{term i} joined the empty queue and was
already at the head.

In this case, the flag @{term \<open>wait i\<close>} is set to True on Line 2, but
the flag is not used later, as the body of the IF-block is not entered.

\item
For every Thread @{text i} in the queue, if @{term \<open>prev i\<close>} is
\emph{not} None, then whether @{term i} is at the head is inversely
equivalent to the value of the flag @{term \<open>wait i\<close>}.

\item
For every Thread @{text i} in the queue, if @{term i} is preceded by
another thread @{term j}, then @{term \<open>prev i\<close>} must be @{term \<open>Some j\<close>}.

\end{itemize}

Note that the value stored as @{term \<open>prev i\<close>} can become outdated.
Suppose the queue starts with @{term j} followed by @{term i}.
When the predecessor @{term j} leaves the queue and makes @{term i}
the head, the value @{term \<open>prev i\<close>} remains the former predecessor
@{term j}.

Hence, @{term i} being at the head does not imply that @{term \<open>prev i\<close>}
is None, and @{term \<open>prev i\<close>} being @{term \<open>Some j\<close>} does not imply that
@{term j} is predecessor of @{term i}. These mean that the converses of
the first and third implications do not hold.\<close>

text \<open>Furthermore, the clause @{text mcs0_inv_prev} implies the
following condition.\<close>

lemma mcs0_inv_wait_1:
  "mcs0_inv_prev \<subseteq> \<lbrace> \<forall> i. i \<in> set \<acute>queue \<longrightarrow> \<not> \<acute>wait i \<longrightarrow> at_head i \<acute>queue \<rbrace>"
  unfolding mcs0_inv_prev_def by fast

text \<open>We need another clause in the invariant that regulates the
variable @{text knows_succ}. Namely, the @{text knows_succ} of the 
last thread in the queue should always be False, as the last thread 
has no successor.\<close>

definition mcs0_inv_last :: "mcs0_state set" where
  "mcs0_inv_last \<equiv> \<lbrace> \<acute>queue \<noteq> [] \<longrightarrow> \<not> \<acute>knows_succ (last \<acute>queue) \<rbrace>"

text \<open>The queue itself should satisfy the invariant of the Abstract
Queue Lock.\<close>

definition mcs0_inv_queue :: "mcs0_state set" where
  "mcs0_inv_queue \<equiv> \<lbrace> distinct \<acute>queue \<and> set \<acute>queue \<subseteq> {..< NumThreads } \<rbrace>"

text \<open>Finally, the overall invariant is the intersubsection of the three
clauses above.\<close>

definition "mcs0_invar \<equiv> mcs0_inv_prev \<inter> mcs0_inv_last \<inter> mcs0_inv_queue"

(*==================================================================*)
subsection \<open>Rely and Guarantee\<close>

definition mcs0_contract_locals_id :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_contract_locals_id i \<equiv> id(prev @ i) \<inter> id(aux_cas_result @ i)"

definition mcs0_contract_queue :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_contract_queue i \<equiv> \<lbrace> queue_contract i \<ordmasculine>queue \<ordfeminine>queue \<rbrace>"

text \<open>We specify a contract for the wait variable that ensures it cannot
transition from being True in the pre-state to being False in the 
post-state. Under certain conditions, we have a stronger requirement that
wait does not change at all.\<close>

definition mcs0_contract_wait :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_contract_wait i \<equiv> \<lbrace> \<ordmasculine>wait i \<noteq> \<ordfeminine>wait i \<longrightarrow> i \<in> set \<ordmasculine>queue
    \<and> i \<noteq> hd \<ordmasculine>queue \<and> i = hd \<ordfeminine>queue
    \<and> \<ordmasculine>wait i \<and> \<not> \<ordfeminine>wait i \<rbrace>"

(*------------------------------------------------------------------*)
text \<open>Meanwhile, the rely and guarantee related to @{text knows_succ} 
are defined separately, as the specific interference on this variable
cannot be captured by the notions of contracts and @{text for_others}.

Recall that @{term \<open>knows_succ i\<close>} is True when Thread @{text i} knows 
the identity of its successor in the queue. Thus the rely-relation 
states that @{term \<open>knows_succ i\<close>} should not be changed unless Thread 
@{text i} is in the queue and is not the last element, and that when 
@{term \<open>knows_succ i\<close>} is changed, it can only be changed from False 
to True, though not necessarily immediately.\<close>

definition mcs0_rely_knows_succ :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_rely_knows_succ i \<equiv> \<lbrace> \<ordmasculine>knows_succ i \<noteq> \<ordfeminine>knows_succ i \<longrightarrow>
     i \<in> set \<ordfeminine>queue \<and> last \<ordfeminine>queue \<noteq> i \<and> \<not> \<ordmasculine>knows_succ i \<rbrace>"

text \<open>We also need a rely-relation that forbids the head from
leaving the queue when its @{text knows_succ} is not yet set to True.\<close>

definition mcs0_rely_head :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_rely_head i \<equiv> \<lbrace> \<ordmasculine>pred_sat i (\<lambda> h.
    \<not> \<ordmasculine>knows_succ h \<longrightarrow> sublist [h,i] \<ordfeminine>queue) \<rbrace>"

text \<open>Furthermore, the @{text knows_succ} of a thread's predecessor
cannot be changed by other threads.\<close>

definition mcs0_rely_prev :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_rely_prev i \<equiv> \<lbrace> \<forall> h. sublist [h,i] \<ordmasculine>queue \<longrightarrow> \<ordmasculine>knows_succ h = \<ordfeminine>knows_succ h \<rbrace>"

(*------------------------------------------------------------------*)
text \<open>Note that we cannot state that @{term \<open>knows_succ i\<close>} is changed 
by the successor of Thread @{text i}, because the essence of the 
rely-relation is to abstract the identities of the other threads into 
the notion of the \emph{environment}. Nevertheless, the precise 
identities related to  predecessors and successors can be captured in 
the guarantee-relation, defined below.\<close>

definition mcs0_guar_knows_succ :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_guar_knows_succ i \<equiv> \<lbrace>
    (\<ordmasculine>knows_succ i \<noteq> \<ordfeminine>knows_succ i \<longrightarrow>  i \<notin> set \<ordmasculine>queue \<and> \<not> \<ordfeminine>knows_succ i) \<and>
    (\<forall> h. h \<noteq> i \<longrightarrow> \<ordfeminine>knows_succ h \<noteq> \<ordmasculine>knows_succ h \<longrightarrow>
      \<not> \<ordmasculine>knows_succ h \<and> \<ordfeminine>knows_succ h \<and>
      \<ordmasculine>prev i = Some h \<and> sublist [h,i] \<ordmasculine>queue) \<rbrace>"

text \<open>The clauses of the guarantee above are as follows:

\begin{itemize}

\item
Thread @{text i} can change its own @{term \<open>nod i\<close>} to False when it
executes its first line of @{text acquire}.

\item
As for a different thread @{text h}, Thread @{text i} can only change
@{term \<open>nod h\<close>} to True when executing Line 6 of @{text acquire},
provided that:

  \begin{enumerate}
    \item @{text i} and @{text h} are different,
    \item @{text i} is in the queue, and
    \item @{text i} is the successor of @{text h}.
  \end{enumerate}

\end{itemize}\<close>

text \<open>We also need a guarantee-relation that restrict the head from
leaving the queue when its @{text knows_succ} is not yet set to True,
which mirrors @{text mcs0_rely_head}.\<close>

definition mcs0_guar_head :: "thread_id \<Rightarrow> mcs0_state rel" where
  "mcs0_guar_head i \<equiv> \<lbrace> \<forall> j. sublist [i,j] \<ordmasculine>queue
    \<longrightarrow> \<not> \<ordmasculine>knows_succ i \<longrightarrow> sublist [i,j] \<ordfeminine>queue \<rbrace>"

(*------------------------------------------------------------------*)
text \<open>Finally, the combined rely and guarantee are defined below.\<close>

definition "mcs0_rely i \<equiv>
  mcs0_contract_locals_id i \<inter>
  mcs0_contract_queue i \<inter>
  mcs0_contract_wait i \<inter>
  mcs0_rely_knows_succ i \<inter>
  mcs0_rely_prev i \<inter>
  mcs0_rely_head i"

definition "mcs0_guar i \<equiv>
  for_others mcs0_contract_locals_id i \<inter>
  for_others mcs0_contract_queue i \<inter>
  for_others mcs0_contract_wait i \<inter>
  mcs0_guar_knows_succ i \<inter>
  mcs0_guar_head i"

(*------------------------------------------------------------------*)
lemmas defs[simp] =
  mcs0_inv_prev_def
  mcs0_inv_last_def
  mcs0_inv_queue_def
  mcs0_invar_def
  mcs0_contract_locals_id_def
  mcs0_contract_queue_def
  mcs0_contract_wait_def
  mcs0_rely_head_def
  mcs0_rely_knows_succ_def
  mcs0_rely_prev_def
  mcs0_guar_head_def
  mcs0_guar_knows_succ_def
  mcs0_rely_def
  mcs0_guar_def

lemma mcs0_invar_subgoals:
  assumes "s \<in> mcs0_inv_prev"
      and "s \<in> mcs0_inv_last"
      and "s \<in> mcs0_inv_queue"
    shows "s \<in> mcs0_invar"
  using assms unfolding mcs0_invar_def by blast

method method_mcs0_invar =
  rule mcs0_invar_subgoals,
  goal_cases inv_prev inv_knows_succ inv_queue

lemma mcs0_guar_subgoals:
  assumes "ss \<in> for_others mcs0_contract_locals_id i"
      and "ss \<in> for_others mcs0_contract_queue i"
      and "ss \<in> for_others mcs0_contract_wait i"
      and "ss \<in> mcs0_guar_knows_succ i"
      and "ss \<in> mcs0_guar_head i"
    shows "ss \<in> mcs0_guar i"
  using assms unfolding mcs0_guar_def by blast

method method_mcs0_estguar =
  rule mcs0_guar_subgoals,
  goal_cases locals queue wait knows_succ hd_knows_succ

(*==================================================================*)
subsection \<open>Stability Lemmas\<close>

subsubsection \<open>General Utilities\<close>

lemma stable_sub_rel:
  "\<lbrakk> stable S R2 ; R1 \<subseteq> R2 \<rbrakk> \<Longrightarrow> stable S R1"
  by auto

text \<open>The lemma above assures us that the stability lemmas will not be
affected if we add new clauses to the rely-relation.\<close>

lemma stable_intersubsection:
  "\<lbrakk> stable S1 R1 ; stable S1 R2 ; stable S2 R1 ; stable S2 R2 \<rbrakk>
  \<Longrightarrow> stable (S1 \<inter> S2) (R1 \<inter> R2)"
  by (metis Int_iff stable_def)

lemma stable_intersubsection_set:
  "\<lbrakk> stable S1 R ; stable S2 R \<rbrakk> \<Longrightarrow> stable (S1 \<inter> S2) R"
  by auto

lemma intersubsection_distrib: "S1 \<inter> S2 \<inter> I = (S1 \<inter> I) \<inter> (S2 \<inter> I)"
  by blast

lemma stable_intersubsection_set_invar:
  "\<lbrakk> stable (S1 \<inter> I) R ; stable (S2 \<inter> I) R \<rbrakk> \<Longrightarrow> stable (S1 \<inter> S2 \<inter> I) R"
  using intersubsection_distrib stable_intersubsection_set by metis

lemma stable_pred_rel: "stable I {(s,s'). s \<in> I \<longrightarrow> s' \<in> I}" by simp

(*------------------------------------------------------------------*)
subsubsection \<open>MCS Utilities\<close>

abbreviation mcs0_stable :: "thread_id \<Rightarrow> mcs0_state set \<Rightarrow> bool" where
  "mcs0_stable i S \<equiv> stable (S \<inter> mcs0_invar)
                            (lift_rely mcs0_invar (mcs0_rely i))"

lemma stable_mcs0_intersubsection:
  "\<lbrakk> mcs0_stable i S1 ; mcs0_stable i S2 \<rbrakk> \<Longrightarrow> mcs0_stable i (S1 \<inter> S2)"
  using stable_intersubsection_set_invar by blast

lemma stable_mcs0_add_invar:
  "stable S (lift_rely mcs0_invar (mcs0_rely i)) \<Longrightarrow> mcs0_stable i S"
  using lift_rely_def
  by (metis (lifting) inf_sup_ord(2) stable_intersubsection_set stable_pred_rel stable_sub_rel)

lemma local_var_stable:
  assumes "stable S (mcs0_contract_locals_id i)"
    shows "mcs0_stable i S"
proof-
  from assms have "stable S (lift_rely mcs0_invar (mcs0_rely i))"
    by simp
  moreover
  have "stable mcs0_invar (lift_rely mcs0_invar (mcs0_rely i))"
    by clarsimp
  ultimately show ?thesis
    using stable_intersubsection_set by blast
qed

method method_mcs0_local_stable = rule local_var_stable, auto

(*------------------------------------------------------------------*)
subsubsection \<open>MCS Stability Lemmas\<close>

lemma in_queue_stable:
  "stable \<lbrace> i \<in> set \<acute>queue \<rbrace> (lift_rely mcs0_invar (mcs0_rely i))"
  by force

lemma not_in_queue_stable:
  "stable \<lbrace> i \<notin> set \<acute>queue \<rbrace> (lift_rely mcs0_invar (mcs0_rely i))"
  by force

lemma at_head_stable':
  assumes "s1 \<in> \<lbrace> at_head i \<acute>queue \<rbrace>"
      and "(s1, s2) \<in> lift_rely mcs0_invar (mcs0_rely i)"
    shows "s2 \<in> \<lbrace> at_head i \<acute>queue \<rbrace>"
proof-
  have "queue_contract i (queue s1) (queue s2)"
    using assms(2) by simp
  then show ?thesis
    using assms(1) stable_at_head by fast
qed

lemma at_head_stable: "mcs0_stable i \<lbrace> at_head i \<acute>queue \<rbrace>"
proof-
  have "stable \<lbrace> at_head i \<acute>queue \<rbrace> (lift_rely mcs0_invar (mcs0_rely i))"
    using at_head_stable' stable_def by meson
  then show ?thesis
    using lift_rely_def stable_mcs0_add_invar by presburger
qed

lemma prev_not_none_stable: "mcs0_stable i \<lbrace> \<acute>prev i \<noteq> None \<rbrace>"
  by method_mcs0_local_stable

lemma prev_is_none_stable: "mcs0_stable i \<lbrace> \<acute>prev i = None \<rbrace>"
  by method_mcs0_local_stable

lemma in_queue_prev_not_none_stable:
  "mcs0_stable i \<lbrace> i \<in> set \<acute>queue \<and> \<acute>prev i \<noteq> None \<rbrace>"
proof-
  from in_queue_stable prev_not_none_stable
  have "stable (\<lbrace> i \<in> set \<acute>queue \<rbrace> \<inter> (\<lbrace>\<acute>prev i \<noteq> None \<rbrace> \<inter> mcs0_invar))
               (lift_rely mcs0_invar (mcs0_rely i))"
    using stable_intersubsection_set by blast
  moreover
  have "\<lbrace> i \<in> set \<acute>queue \<and> \<acute>prev i \<noteq> None \<rbrace> \<inter> mcs0_invar
      = \<lbrace> i \<in> set \<acute>queue \<rbrace> \<inter> (\<lbrace>\<acute>prev i \<noteq> None \<rbrace> \<inter> mcs0_invar)"
    by blast
  ultimately show ?thesis by argo
qed

lemma in_queue_prev_is_none_stable:
  "mcs0_stable i \<lbrace> i \<in> set \<acute>queue \<and> \<acute>prev i = None \<rbrace>"
proof-
  from in_queue_stable prev_is_none_stable
  have "stable (\<lbrace> i \<in> set \<acute>queue \<rbrace> \<inter> (\<lbrace>\<acute>prev i = None \<rbrace> \<inter> mcs0_invar))
               (lift_rely mcs0_invar (mcs0_rely i))"
    using stable_intersubsection_set by blast
  moreover
  have "\<lbrace> i \<in> set \<acute>queue \<and> \<acute>prev i = None \<rbrace> \<inter> mcs0_invar
      = \<lbrace> i \<in> set \<acute>queue \<rbrace> \<inter> (\<lbrace>\<acute>prev i = None \<rbrace> \<inter> mcs0_invar)"
    by blast
  ultimately show ?thesis by argo
qed

lemma not_cas_stable: "mcs0_stable i \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>"
  by method_mcs0_local_stable

lemma at_head_not_cas_stable:
  "mcs0_stable i \<lbrace> at_head i \<acute>queue \<and> \<not> \<acute>aux_cas_result i \<rbrace>"
proof-
  from at_head_stable not_cas_stable
  have "mcs0_stable i (\<lbrace> at_head i \<acute>queue \<rbrace> \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>)"
    using stable_mcs0_intersubsection by blast
  moreover
  have "\<lbrace> at_head i \<acute>queue \<and> \<not> \<acute>aux_cas_result i \<rbrace>
      = \<lbrace> at_head i \<acute>queue \<rbrace> \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>"
    by blast
  ultimately show ?thesis by metis
qed

lemma knows_succ_stable:
  "stable \<lbrace> \<acute>knows_succ i \<rbrace> (lift_rely mcs0_invar (mcs0_rely i))"
  by (simp add: inf_commute)

(*==================================================================*)
subsection \<open>Acquire\<close>

(*------------------------------------------------------------------*)
subsubsection \<open>Initialisation\<close>

theorem mcs0_acq_ln1:
  "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }
    \<acute>knows_succ[i] := False
    { \<lbrace> i \<notin> set \<acute>queue \<and> \<not> \<acute>knows_succ i \<rbrace> }"
  by (method_basic_inv; force)

abbreviation acq_post_init :: "thread_id \<Rightarrow> mcs0_state set" where
  "acq_post_init i \<equiv> \<lbrace> i \<notin> set \<acute>queue \<and> \<not> \<acute>knows_succ i \<and> \<acute>wait i \<rbrace>"

theorem mcs0_acq_ln2:
 "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { \<lbrace> i \<notin> set \<acute>queue \<and> \<not> \<acute>knows_succ i \<rbrace> }
    \<acute>wait[i] := True
    { acq_post_init i }"
  by (method_basic_inv; force)

(*------------------------------------------------------------------*)
subsubsection \<open>Swap\<close>

abbreviation acq_post_swap :: "thread_id \<Rightarrow> mcs0_state set" where
  "acq_post_swap i \<equiv> \<lbrace> i \<in> set \<acute>queue \<and> \<acute>wait i
    \<and> (\<acute>pred_sat i (\<lambda>h. \<not> \<acute>knows_succ h)) \<rbrace>"

lemma acq_post_swap_stable: "mcs0_stable i (acq_post_swap i)"
proof-
  { fix s  assume assm_s:   "s \<in> acq_post_swap i \<inter> mcs0_invar"
    fix s' assume assm_rel: "(s,s') \<in> lift_rely mcs0_invar (mcs0_rely i)"
    have "s' \<in> acq_post_swap i \<inter> mcs0_invar"
    proof (standard, standard, intro conjI)
      show "i \<in> set (queue s')" using assm_s assm_rel by simp
    next
      show "wait s' i"
      text \<open>We shall show that we always enter the else-clause
      of the conditional definition @{text mcs0_contract_wait}.\<close>
      proof (cases "i = hd (queue s)")
        case True
        then show ?thesis using assm_s assm_rel by simp
      next
        case False
        text \<open>If there is another thread @{term j} ahead of @{term i},
        we shall show that @{term j} does not have the knows_succ, and then have
        @{term i} cannot be the head of the queue in the post-state,
        which brings us into the else-clause of the contract.\<close>
        moreover have "i \<in> set (queue s)"
          using assm_s by blast
        ultimately have "\<exists> h. sublist [h,i] (queue s)"
          using in_queue_not_hd_pred_distinct assm_s 
          unfolding mcs0_invar_def by fastforce
        then obtain h where "sublist [h,i] (queue s)"
          by blast
        then have "sublist [h,i] (queue s')"
          using assm_s assm_rel by simp
        moreover have "distinct (queue s')"
          using assm_s assm_rel by simp
        ultimately have "i \<noteq> hd (queue s')"
          using sublist_ij_j_not_hd by fast
        then show ?thesis using assm_s assm_rel by simp
      qed
    next
      { fix h assume ln0: "sublist [h,i] (queue s')"
        moreover have "distinct (queue s) \<and> distinct (queue s')"
          using assm_s assm_rel by simp
        moreover have "queue_contract i (queue s) (queue s')"
          using assm_rel by simp
        ultimately have ln1: "sublist [h,i] (queue s)"
          using queue_contract_preserves_sublist_pred by meson
        then have "\<not> knows_succ s h"
          using assm_s assm_rel by blast
        then have "\<not> knows_succ s' h"
          using ln1 assm_rel by simp }
      then show "\<forall> h. sublist [h,i] (queue s') \<longrightarrow> \<not> knows_succ s' h" by blast
    next
      show "s' \<in> mcs0_invar" using assm_s assm_rel by simp
    qed }
  then show ?thesis unfolding stable_def by blast
qed

(*------------------------------------------------------------------*)
lemma acq3_estinv:
  assumes assm_i: "t < NumThreads"
      and assm_pre: "s \<in> acq_post_init t \<inter> mcs0_invar"
      and assm_new: "s' =
            ((\<lambda>s. s\<lparr>prev := (prev s)(t := opt_last (queue s))\<rparr>) \<circ>>
             (\<lambda>s. s\<lparr>queue := queue s @ [t]\<rparr>)) s"
    shows "s' \<in> mcs0_invar"
proof method_mcs0_invar
  case inv_prev
  then show ?case unfolding mcs0_inv_prev_def
  proof (standard, standard, standard, goal_cases)
    case (1 i)
    then show ?case
      using assm_pre assm_new apply simp
      by (meson opt_last_some)
  next
    case (2 i)
    { fix i assume a0: "i \<in> set (queue s')"
      then have "i \<in> set (queue s) \<or> i = t" (is "?P \<or> ?Q")
        using assm_new by force
      then have "(prev s' i = None \<longrightarrow> at_head i (queue s'))
          \<and> (prev s' i \<noteq> None \<longleftrightarrow> (wait s' i = (\<not> at_head i (queue s'))))
          \<and> (\<forall> j. sublist [j, i] (queue s') \<longrightarrow> prev s' i = Some j)"
      proof (rule disjE[where P = ?P and Q = ?Q], goal_cases)
        case 1
        then show ?case 
          using assm_pre assm_new apply simp
          by (metis (no_types, opaque_lifting) hd_append list.set_cases neq_Nil_conv sublist_ij_not_last)
      next
        case 2
        then show ?case
          using assm_pre assm_new apply simp
          by (metis hd_append hd_in_set last_and_opt_last list.sel(1) not_None_eq opt_last.simps(1) sublist_ij_opt_last)
      qed }
    then show ?case by presburger
  qed
next
  case inv_knows_succ
  then show ?case using assm_pre assm_new by simp
next
  case inv_queue
  then show ?case using assm_pre assm_new assm_i by simp
qed

(*------------------------------------------------------------------*)
lemma acq3_estpost:
  assumes "s \<in> acq_post_init i \<inter> mcs0_invar"
    shows "((\<lambda>s. s\<lparr>prev := (prev s)(i := opt_last (queue s))\<rparr>) \<circ>>
            (\<lambda>s. s\<lparr>queue := queue s @ [i]\<rparr>)) s \<in> acq_post_swap i"
      (is "?s \<in> acq_post_swap i")
proof (standard, intro conjI)
  show "i \<in> set (queue ?s)" using assms by simp
next
  show "wait ?s i" using assms by simp
next
  show "\<forall> h. sublist [h,i] (queue ?s) \<longrightarrow> \<not> knows_succ ?s h"
    using assms apply clarsimp
    by (metis last_and_opt_last opt_last.simps(1) option.distinct(1) option.inject sublist_ij_opt_last)
qed

(*------------------------------------------------------------------*)
theorem mcs0_acq_ln3:
  assumes "i < NumThreads"
  shows "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { acq_post_init i }
    Basic ((\<acute>prev[i] \<leftarrow> opt_last \<acute>queue) \<circ>>
           (\<acute>queue \<leftarrow> \<acute>queue @ [i]))
    { acq_post_swap i }"
proof method_basic_inv
  case stab_pre
  then show ?case by force
next
  case stab_post
  then show ?case using acq_post_swap_stable by blast
next
  case id_guar
  then show ?case by force
next
  case est_inv
  then show ?case using acq3_estinv assms by blast
next
  case est_post
  then show ?case using acq3_estpost by blast
next
  case est_guar
  then show ?case by (simp add: sublist_snoc)
qed

(*------------------------------------------------------------------*)
subsubsection \<open>If-Block\<close>

abbreviation knows_succ_prev_assigned_true :: "thread_id \<Rightarrow> mcs0_state \<Rightarrow> mcs0_state" where
  "knows_succ_prev_assigned_true i s
    \<equiv> s\<lparr> knows_succ := fun_upd_opt (knows_succ s) (prev s i) True \<rparr>"

abbreviation acq_post_set_knows_succ :: "thread_id \<Rightarrow> mcs0_state set" where
  "acq_post_set_knows_succ i \<equiv> \<lbrace> i \<in> set \<acute>queue \<and> \<acute>prev i \<noteq> None
    \<and> (\<forall> h. sublist [h,i] \<acute>queue \<longrightarrow> \<acute>knows_succ h) \<rbrace>"

lemma acq_post_set_knows_succ_stable:
  assumes "s  \<in> acq_post_set_knows_succ i \<inter> mcs0_invar"
      and "(s,s') \<in> lift_rely mcs0_invar (mcs0_rely i)"
    shows "s' \<in> acq_post_set_knows_succ i \<inter> mcs0_invar"
proof-
  have "mcs0_stable i \<lbrace> i \<in> set \<acute>queue \<rbrace>"
    using in_queue_stable stable_mcs0_add_invar by blast
  moreover have "mcs0_stable i \<lbrace> \<acute>prev i \<noteq> None \<rbrace>"
    using prev_not_none_stable stable_mcs0_add_invar by blast
  moreover have "mcs0_stable i \<lbrace> \<forall> h. sublist [h,i] \<acute>queue \<longrightarrow> \<acute>knows_succ h \<rbrace>"
  proof-
    { fix s s'
      assume a1: "s  \<in> \<lbrace> \<forall> h. sublist [h,i] \<acute>queue \<longrightarrow> \<acute>knows_succ h \<rbrace> \<inter> mcs0_invar"
      assume a2: "(s,s') \<in> lift_rely mcs0_invar (mcs0_rely i)"
      have "s' \<in> \<lbrace> \<forall> h. sublist [h,i] \<acute>queue \<longrightarrow> \<acute>knows_succ h \<rbrace> \<inter> mcs0_invar"
      proof-
        { fix h assume a_new: "sublist [h,i] (queue s')"
          moreover have "distinct (queue s) \<and> distinct (queue s')"
            using a1 a2 by simp
          moreover have "queue_contract i (queue s) (queue s')"
            using a2 by simp
          ultimately have ln: "sublist [h,i] (queue s)"
            using queue_contract_preserves_sublist_pred by meson
          then have "knows_succ s h"
            using a1 by blast
          then have "knows_succ s' h"
            using a2 ln mcs0_rely_prev_def by simp }
        then show ?thesis using a1 a2 by simp
      qed }
    then show ?thesis unfolding stable_def by blast
  qed
  ultimately show ?thesis unfolding stable_def using assms by blast
qed

theorem mcs0_acq_ln5:
 "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { acq_post_swap i \<inter> \<lbrace> \<acute>prev i \<noteq> None \<rbrace> }
  Basic (knows_succ_prev_assigned_true i)
    { acq_post_set_knows_succ i }"
proof method_basic_inv
  case stab_pre
  then show ?case
    using acq_post_swap_stable prev_not_none_stable stable_mcs0_intersubsection
    by blast
next
  case stab_post
  then show ?case using acq_post_set_knows_succ_stable unfolding stable_def by meson
next
  case id_guar
  then show ?case by force
next
  case est_inv
  then show ?case
    by (clarsimp, metis append_butlast_last_id in_queue_not_hd_pred option.sel queue_contract_id queue_contract_nonempty sublist_ij_suffix_in_j suffix_after_intro)
next
  case est_guar
  then show ?case
    by (clarsimp, metis in_queue_not_hd_pred option.sel)
next
  case est_post
  show ?case using in_queue_not_hd_pred by force
qed

theorem mcs0_acq_ln6:
 "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { acq_post_set_knows_succ i }
  WHILE \<acute>wait i DO SKIP OD
    { \<lbrace> at_head i \<acute>queue \<rbrace> }"
proof method_spinloop
  case stable_pre
  then show ?case using acq_post_set_knows_succ_stable unfolding stable_def by meson
next
  case stable_post
  then show ?case using at_head_stable by blast
next
  case guar_id
  then show ?case using lift_guar_def by fast
next
  case est_post
  then show ?case by auto
qed

theorem mcs0_acq_ln7:
 "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { \<lbrace> i \<in> set \<acute>queue \<and> \<acute>prev i = None \<rbrace> }
  SKIP
    { \<lbrace> at_head i \<acute>queue \<rbrace> }"
proof method_skip
  case stab_pre
  then show ?case using in_queue_prev_is_none_stable by blast
next
  case stab_post
  then show ?case using at_head_stable by blast
qed auto

(*==================================================================*)
subsection \<open>Release\<close>

(*------------------------------------------------------------------*)
subsubsection \<open>CAS\<close>

text \<open>At the start of Release, we can only be certain that the thread is 
at the head of the queue. As for the other variables:

\begin{itemize}
  \item @{text knows_succ} can be either True or False, 
        depending on the progress of the successor.
  \item @{text wait} can be either True or False, 
        depending on whether the thread joined an empty queue or not.
  \item @{text prev} can be either None or Some, 
        depending on whether the thread joined an empty queue or not.
\end{itemize}\<close>

theorem mcs0_rel_ln1:
 "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { \<lbrace> at_head i \<acute>queue \<rbrace> }
    \<acute>aux_cas_result[i] := False
    { \<lbrace> at_head i \<acute>queue \<and> \<acute>aux_cas_result i = False \<rbrace> }"
proof method_basic
  case stable_pre
  then show ?case using at_head_stable by blast
next
  case stable_post
  then show ?case using at_head_not_cas_stable by presburger
qed auto

(*------------------------------------------------------------------*)
text \<open>We now move on to the CAS instruction, which is encoded as the
state-transformation function below.\<close>

abbreviation mcs0_cas :: "thread_id \<Rightarrow> mcs0_state \<Rightarrow> mcs0_state" where
  "mcs0_cas i s \<equiv> (if opt_last (queue s) = Some i
    then ((\<acute>aux_cas_result[i] \<leftarrow> True) \<circ>> (\<acute>queue \<leftarrow> [])) s
    else s)"

text \<open>Recall that the postcondition of @{text mcs0_rel_ln1} does not
involve @{text knows_succ}, @{text wait} or @{text prev}. There is not 
sufficient information on the values of these variables.

Now, as the CAS instruction modifies none of these three variables, 
its postcondition again cannot say anything about them.\<close>

abbreviation cas_post :: "thread_id \<Rightarrow> mcs0_state set" where
  "cas_post i \<equiv> \<lbrace> (if \<acute>aux_cas_result i then i \<notin> set \<acute>queue
    else at_head i \<acute>queue \<and> (\<exists>j. sublist [i,j] \<acute>queue)) \<rbrace>"

lemma cas_post_stable:
  "stable (cas_post i \<inter> mcs0_invar) (lift_rely mcs0_invar (mcs0_rely i))"
  (is "stable ?Q ?R")
proof-
  { fix s1 assume a1: "s1 \<in> ?Q"
    fix s2 assume a2: "(s1, s2) \<in> ?R"
    from a2 have ln1: "aux_cas_result s1 i = aux_cas_result s2 i"
      by fastforce
    (*------------------------------------------*)
    have "s2 \<in> cas_post i"
    proof (cases "aux_cas_result s2 i")
      case True then show ?thesis using a1 a2 by auto
    next
      case False
      then have ln2: "at_head i (queue s1) \<and> (\<exists>j. sublist [i,j] (queue s1))"
        using a1 ln1 by auto
      from ln2 have ln3: "at_head i (queue s2)"
        using a2 stable_at_head by auto
      (*------------------------------*)
      from ln2 obtain j where "sublist [i,j] (queue s1)"
        by blast
      then have "\<exists> ps ss. queue s1 = ps @ i # j # ss"
        using sublist_ij_explicit by metis
      then obtain ps ss where "queue s1 = ps @ i # j # ss"
        by blast
      moreover have "queue_contract i (queue s1) (queue s2)"
        using a2 by simp
      moreover have "distinct (queue s1) \<and> distinct (queue s2)"
        using a1 a2 by simp
      ultimately have "\<exists> xs ys. queue s2 = xs @ i # j # ys"
        using sublist_ij_contract_explicit by fast
      then have "sublist [i,j] (queue s2)"
        using sublist_ij_explicit by metis
      then show ?thesis using False ln2 ln3 by auto
    qed
    (*------------------------------------------*)
    moreover have "s2 \<in> mcs0_invar"
      using a1 a2 by simp
    ultimately have "s2 \<in> ?Q"
      by blast }
  then show ?thesis using stable_def by meson
qed

theorem mcs0_rel_cas:
  assumes "i < NumThreads"
  shows "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { \<lbrace> at_head i \<acute>queue \<and> \<acute>aux_cas_result i = False \<rbrace> }
    Basic (mcs0_cas i)
    { cas_post i }"
 (is "rely: ?R  guar: ?G  inv: ?I  code: { ?P } ?C { ?Q }")
proof method_basic_inv
  case stab_pre
  then show ?case using at_head_not_cas_stable by presburger
next
  case stab_post
  then show ?case using cas_post_stable by blast
next
  case id_guar
  then show ?case by simp
next
  case est_inv
  then show ?case by auto
next
  case est_guar
  then show ?case
  proof (standard, standard, method_mcs0_estguar)
    case (queue s)
    then show ?case
    proof (cases "opt_last (queue s) = Some i")
      case True
      then have "queue s = [i]"
        using assms
        by (metis (mono_tags, lifting) CollectD IntD1 IntD2 mcs0_inv_queue_def mcs0_invar_def opt_last_at_head queue)
      moreover
      have "queue (mcs0_cas i s) = []"
        using True by simp
      ultimately show ?thesis by force
    next
      case False
      then show ?thesis by force
    qed
  next
    case (wait s)
    then show ?case by (simp add: opt_last_at_head_j)
  next
    case (hd_knows_succ s)
    then show ?case
      unfolding mcs0_guar_head_def mcs0_invar_def apply simp
      by (metis opt_last_some_last sublist_ij_i_not_last)
  qed auto
next
  case est_post
  then show ?case by (simp add: opt_last_not_none)
qed

(*------------------------------------------------------------------*)
subsubsection \<open>Spin and Update\<close>

theorem mcs0_rel_while:
 "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { cas_post i \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace> }
    WHILE \<not> \<acute>knows_succ i DO SKIP OD
    { cas_post i \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace> \<inter> \<lbrace> \<acute>knows_succ i \<rbrace> }"
proof method_spinloop
  case stable_pre
  then show ?case
    using cas_post_stable not_cas_stable stable_intersubsection_set_invar
    by blast
next
  case stable_post
  have "mcs0_stable i (cas_post i)"
    using cas_post_stable by blast
  moreover have "mcs0_stable i \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>"
    by simp
  moreover have "mcs0_stable i \<lbrace> \<acute>knows_succ i \<rbrace>"
    using knows_succ_stable stable_mcs0_add_invar by fast
  ultimately show ?case
    using stable_intersubsection_set_invar by meson
qed (fastforce+)

(*------------------------------------------------------------------*)
lemma update_flag_estinv:
  assumes "i < NumThreads"
      and "s \<in> cas_post i \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace> \<inter> \<lbrace> \<acute>knows_succ i \<rbrace> \<inter> mcs0_invar"
    shows "((\<lambda>s. s\<lparr>queue := tl (queue s)\<rparr>) \<circ>>
            (\<lambda>s. s\<lparr>wait := (wait s)(hd (queue s) := False)\<rparr>)) s
          \<in> mcs0_invar"
      (is "?s \<in> mcs0_invar")
proof method_mcs0_invar
  case inv_queue
  then show ?case
    apply simp
    apply standard
    using assms(2) distinct_tl apply auto[1]
    using assms(1,2) apply simp
    by (metis dual_order.trans set_mono_suffix suffix_tl)
next
  case inv_prev
  then show ?case 
  proof-
    have ln1: "at_head i (queue s) \<and> distinct (queue s)"
      using assms by simp
    have ln2: "queue ?s = tl (queue s)"
      using assms by simp
    have ln3: "i \<notin> set (queue ?s)"
      using ln1 ln2 at_head_tl by metis
    have ln4: "s \<in> mcs0_inv_prev"
      using assms unfolding mcs0_invar_def by blast
    { fix i assume assm_i: "i \<in> set (queue ?s)"
      then have ln5: "i \<in> set (queue s) \<and> \<not> at_head i (queue s)"
        using assms ln1 ln2 ln3 by (metis list.sel(2) list.set_sel(2))
      then have ln6: "prev s i \<noteq> None"
        using ln4 by force
      then have ln7: "prev ?s i \<noteq> None"
        using assms by simp
      then have "prev ?s i = None \<longrightarrow> at_head i (queue ?s)"
        (is ?A) by blast
      moreover (*--------------------------------------*)
      have "wait s i = (\<not> at_head i (queue s))"
        using ln4 ln5 ln6 by simp
      then have ln8: "wait s i"
        using ln5 by fastforce
      have ln9: "\<not> at_head i (queue ?s) \<longrightarrow> wait ?s i = wait s i"
        using assms assm_i by auto
      have "at_head i (queue ?s) \<longrightarrow> wait ?s i = False"
        using assms by auto
      then have "wait ?s i = (\<not> at_head i (queue ?s))"
        using ln8 ln9 by blast
      then have "prev ?s i \<noteq> None \<longleftrightarrow> wait ?s i = (\<not> at_head i (queue ?s))"
        (is ?B) using ln7 by blast
      moreover (*--------------------------------------*)
      from ln2 have "\<forall> h. sublist [h,i] (queue ?s) \<longrightarrow> sublist [h,i] (queue s)"
        using sublist_order.order.trans by auto
      then have "\<forall> h. sublist [h,i] (queue ?s) \<longrightarrow> prev ?s i = Some h"
        (is ?C) using ln4 ln5 assms by force
      ultimately (*--------------------------------------*)
      have "?A \<and> ?B \<and> ?C" by blast }
    moreover have "\<forall> i. prev ?s i \<noteq> Some i"
      using assms ln4 by simp
    ultimately show ?thesis by simp
  qed
next
  case inv_knows_succ
  then show ?case
    apply clarsimp
    using assms by (simp add: last_tl)
qed

(*------------------------------------------------------------------*)
lemma update_flag_estguar:
  assumes "i < NumThreads"
      and "s \<in> cas_post i \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace> \<inter> \<lbrace> \<acute>knows_succ i \<rbrace> \<inter> mcs0_invar"
    shows "(s, ((\<lambda>s. s\<lparr>queue := tl (queue s)\<rparr>) \<circ>>
                (\<lambda>s. s\<lparr>wait := (wait s)(hd (queue s) := False)\<rparr>)) s)
          \<in> mcs0_guar i"
      (is "(s, ?s) \<in> ?G")
proof method_mcs0_estguar
  case wait
  have ln_wait_changed: "wait ?s (hd (tl (queue s))) = False"
    by simp
  have ln_wait_unchanged: "\<forall> j. j \<noteq> hd (tl (queue s)) \<longrightarrow> wait s j = wait ?s j"
    by simp
  have queue_post: "queue ?s = tl (queue s)"
    by simp
  (*--------------------------------------------*)
  have ln_i: "at_head i (queue s)"
    using assms by simp
  have "\<exists> j. sublist [i,j] (queue s)"
    using assms by simp
  then obtain elem2 where elem2: "sublist [i,elem2] (queue s)"
    by blast
  then have elem2_1: "elem2 \<in> set (queue s)"
    by (meson list.set_intros(1) set_mono_sublist set_subset_Cons subsetD)
  have elem2_2: "elem2 = hd (tl (queue s))"
    using elem2 assms ln_i sublist_ij_hd_tl
    by (metis (no_types, lifting) Int_Collect Int_iff mcs0_inv_queue_def mcs0_invar_def)
  have elem2_3: "elem2 \<noteq> hd (queue s)"
    using elem2 assms
    by (metis (no_types, lifting) IntE Int_Collect mcs0_inv_queue_def mcs0_invar_def sublist_ij_j_not_hd)
  then show ?case
  proof-
    { fix j assume j_neq_i: "j \<noteq> i"
      have "(s, ?s) \<in> mcs0_contract_wait j"
      proof (cases "j = elem2") (* queue s = i # j # xs *)
        case True (* need to show that "wait j" is changed *)
        have ln0: "j = hd (tl (queue s))"
          using True elem2_2 by blast
        have ln1: "j \<in> set (queue s)"
          using True elem2_1 by blast
        have "wait s j \<and> \<not> wait ?s j" (is "?A \<and> ?B")
          using ln0 ln1 assms ln_i j_neq_i mcs0_inv_wait_1 ln_wait_changed by auto
        moreover
        have "j \<in> set (queue s) \<and> j \<noteq> hd (queue s) \<and> j = hd (queue ?s)"
         (is "?A \<and> ?B \<and> ?C")
        proof-
          have ?B using elem2_3 True by simp
          moreover
          have ?C using ln0 queue_post by presburger
          ultimately
          show ?thesis using ln1 by blast
        qed
        ultimately show ?thesis by force
      next
        case False (* queue s = i # elem2 # xs \<and> j \<noteq> i \<noteq> elem2 *)
        then show ?thesis using elem2_2 by simp
      qed }
    then show ?thesis by blast
  qed
next (*-----------------------------------------*)
  case queue
  then show ?case
  proof-
    { fix j assume "i \<noteq> j"
      then have "\<not> at_head j (queue s)"
        using assms by simp
      then have "(s, ?s) \<in> mcs0_contract_queue j"
        using queue_contract_tl by force }
    then show ?thesis by fast
  qed
next (*-----------------------------------------*)
  case hd_knows_succ
  then show ?case using assms by simp
qed auto

(*------------------------------------------------------------------*)
lemma update_flag_estpost:
  assumes "s1 \<in> cas_post i \<inter> \<lbrace>\<not> \<acute>aux_cas_result i\<rbrace> \<inter> \<lbrace>\<acute>knows_succ i\<rbrace> \<inter> mcs0_invar"
      and "s2 = ((\<lambda>s. s\<lparr>queue := tl (queue s)\<rparr>) \<circ>>
                 (\<lambda>s. s\<lparr>wait := (wait s)(hd (queue s) := False)\<rparr>)) s1"
    shows "s2 \<in> \<lbrace> i \<notin> set \<acute>queue \<rbrace>"
proof-
  have "at_head i (queue s1) \<and> distinct (queue s1)"
    using assms(1) by simp
  moreover have "queue s2 = tl (queue s1)"
    using assms(2) by simp
  ultimately have "i \<notin> set (queue s2)"
    using at_head_tl by metis
  then show ?thesis by blast
qed

(*------------------------------------------------------------------*)
theorem mcs0_rel_update_flag:
  assumes "i < NumThreads"
  shows "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { cas_post i \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace> \<inter> \<lbrace> \<acute>knows_succ i \<rbrace> }
  Basic ((\<acute>queue \<leftarrow> tl \<acute>queue) \<circ>>
         (\<acute>wait[hd \<acute>queue] \<leftarrow> False))
    { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }"
proof method_basic_inv
  case stab_pre (* copied from "stable_post" of "mcs0_rel_while" *)
  have "mcs0_stable i (cas_post i)"
    using cas_post_stable by blast
  moreover have "mcs0_stable i \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace>"
    by simp
  moreover have "mcs0_stable i \<lbrace> \<acute>knows_succ i \<rbrace>"
    using knows_succ_stable stable_mcs0_add_invar by fast
  ultimately show ?case
    using stable_intersubsection_set_invar by meson
next
  case est_inv  show ?case using assms update_flag_estinv  by blast
next
  case est_guar show ?case using assms update_flag_estguar by blast
next
  case est_post show ?case using update_flag_estpost by blast
qed (simp_all)

(*------------------------------------------------------------------*)
theorem mcs0_rel_skip:
  "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
    { cas_post i \<inter> \<lbrace> \<acute>aux_cas_result i \<rbrace> }
  SKIP
    { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }"
  by (method_skip; fastforce)

(*==================================================================*)
subsection \<open>Combined RG Theorems\<close>

method method_seq for m :: "mcs0_state set" =
  rule Seq[where mid = "m \<inter> mcs0_invar"], goal_cases

abbreviation "code_acq i \<equiv>
  \<acute>knows_succ[i] := False ;;
  \<acute>wait[i] := True ;;
  Basic ((\<acute>prev[i] \<leftarrow> opt_last \<acute>queue) \<circ>>
         (\<acute>queue \<leftarrow> \<acute>queue @ [i])) ;;
  (IF \<acute>prev i \<noteq> None THEN
    Basic (knows_succ_prev_assigned_true i) ;;
    (WHILE \<acute>wait i DO SKIP OD)
  FI)"

abbreviation "code_rel i \<equiv>
  \<acute>aux_cas_result[i] := False ;;
  Basic (mcs0_cas i) ;;
  (IF \<not> \<acute>aux_cas_result i THEN
    (WHILE \<not> \<acute>knows_succ i DO SKIP OD) ;;
    Basic ((\<acute>queue \<leftarrow> tl \<acute>queue) \<circ>>
           (\<acute>wait[hd \<acute>queue] \<leftarrow> False))
  FI)"

theorem mcs0_acq_overall:
  assumes "i < NumThreads"
  shows "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
      { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }
    code_acq i
      { \<lbrace> at_head i \<acute>queue \<rbrace> }"
proof (method_seq "acq_post_swap i")
  case 1 show ?case
  proof (method_seq "acq_post_init i")
    case 1 show ?case
    proof (method_seq "\<lbrace> i \<notin> set \<acute>queue \<and> \<not> \<acute>knows_succ i \<rbrace>")
      case 1 show ?case using mcs0_acq_ln1 by fast
      case 2 show ?case using mcs0_acq_ln2 by fast
    qed
    case 2 show ?case using mcs0_acq_ln3 assms by fast
  qed
next
  case 2 show ?case
  proof method_cond
    case stab_pre show ?case using acq_post_swap_stable by fast
    case stab_post show ?case using at_head_stable by fast
    case then_br show ?case
    proof (method_seq "acq_post_set_knows_succ i")
      case 1 show ?case using mcs0_acq_ln5 by (simp add: Int_assoc inf_commute)
      case 2 show ?case using mcs0_acq_ln6 by fast
    qed
  qed auto
qed

theorem mcs0_rel_overall:
  assumes "i < NumThreads"
  shows "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
      { \<lbrace> at_head i \<acute>queue \<rbrace> }
    code_rel i
      { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }"
proof (method_seq "cas_post i")
  case 1 show ?case
  proof (method_seq "\<lbrace> at_head i \<acute>queue \<and> \<not> \<acute>aux_cas_result i \<rbrace>")
    case 1 show ?case using mcs0_rel_ln1 by meson
    case 2 show ?case using mcs0_rel_cas assms by fastforce
  qed
  case 2 show ?case
  proof method_cond
    case stab_pre show ?case using cas_post_stable by fast
    case then_br  show ?case
    proof (method_seq "cas_post i \<inter> \<lbrace> \<not> \<acute>aux_cas_result i \<rbrace> \<inter> \<lbrace> \<acute>knows_succ i \<rbrace>")
      case 1 show ?case using mcs0_rel_while by (simp add: Int_assoc inf_commute)
      case 2 show ?case using mcs0_rel_update_flag assms by fast
    qed
  qed auto
qed

theorem mcs0_local_loop:
  assumes "i < NumThreads"
  shows   "rely: mcs0_rely i  guar: mcs0_guar i  inv: mcs0_invar  code:
      { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }
    WHILE True DO (code_acq i ;; code_rel i) OD
      { \<lbrace> i \<notin> set \<acute>queue \<rbrace> }"
proof method_loop
  case loop_body show ?case
  proof (method_seq "\<lbrace> at_head i \<acute>queue \<rbrace>")
    case 1 show ?case using mcs0_acq_overall assms by force
    case 2 show ?case using mcs0_rel_overall assms by force
  qed
qed auto

(*==================================================================*)
subsection \<open>Global RG Theorems\<close>

lemma guar_implies_rely_inv_cond_lma_1:
  assumes assm_i_j:  "i \<noteq> j"
      and assm_guar: "(s1, s2) \<in> mcs0_guar i"
      and assm_inv:  "s1 \<in> mcs0_invar \<and> s2 \<in> mcs0_invar"
    shows "(s1, s2) \<in> mcs0_rely j"
  unfolding mcs0_rely_def
proof (intro IntI)
  show "(s1, s2) \<in> mcs0_contract_locals_id j"
    using assms by fastforce
next
  show "(s1, s2) \<in> mcs0_contract_queue j"
    using assms by fastforce
next
  show "(s1, s2) \<in> mcs0_contract_wait j"
    using assms apply simp
    by (metis ComplI singletonD)
next
  have g_knows_succ: "(s1, s2) \<in> mcs0_guar_knows_succ i"
    using assm_guar mcs0_guar_def by fast
  show "(s1, s2) \<in> mcs0_rely_knows_succ j"
  proof-
    { assume a: "knows_succ s2 j \<noteq> knows_succ s1 j"
      from a g_knows_succ have ln1: "\<not> knows_succ s1 j \<and> knows_succ s2 j"
        using assm_i_j mcs0_guar_knows_succ_def by force
      from a g_knows_succ have ln2: "sublist [j,i] (queue s1)"
        using assm_i_j mcs0_guar_knows_succ_def by force
      have "sublist [j,i] (queue s2)"
        apply (rule queue_contract_preserves_sublist_succ[where ?xs = "queue s1"])
        using assm_guar mcs0_guar_def assm_i_j mcs0_contract_queue_def apply simp
        using assm_inv mcs0_invar_def apply simp
        using ln2 by simp
      moreover have "distinct (queue s2)"
        using assm_inv assm_guar by force
      ultimately have "j \<in> set (queue s2) \<and> last (queue s2) \<noteq> j"
        by (meson list.set_intros(1) set_mono_sublist sublist_ij_i_not_last subsetD)
      then have "j \<in> set (queue s2) \<and> last (queue s2) \<noteq> j \<and> \<not> knows_succ s1 j"
        using ln1 by blast
    }
    then show ?thesis using mcs0_rely_knows_succ_def by auto
  qed
next
  show "(s1, s2) \<in> mcs0_rely_prev j"
  proof-
    { fix h assume a: "sublist [h,j] (queue s1)"
      have "knows_succ s1 h = knows_succ s2 h"
      proof (cases "h = i")
        case True
        then show ?thesis
          using a assm_guar assm_inv apply clarsimp
          by (metis distinct.simps(2) distinct_singleton sublist_ij_suffix_in_j suffix_after_nonempty)
      next
        case False
        have "(s1, s2) \<in> mcs0_guar_knows_succ i"
          using assm_inv assm_guar mcs0_guar_def by fast
        then show ?thesis
          using False a mcs0_guar_knows_succ_def apply clarsimp
          by (smt (verit) Int_Collect assm_i_j assm_inv mcs0_inv_queue_def mcs0_invar_def sublist_ij_suffix_hd_j)
      qed }
    then show ?thesis using mcs0_rely_prev_def by simp
  qed
next
  show "(s1, s2) \<in> mcs0_rely_head j"
  proof-
    { fix h assume a: "sublist [h,j] (queue s1) \<and> \<not> knows_succ s1 h"
      have "sublist [h,j] (queue s2)"
      proof (cases "h = i")
        case True
        then show ?thesis
          using a assm_guar mcs0_guar_def mcs0_guar_head_def by auto
      next
        case False
        show ?thesis
          apply (rule queue_contract_preserves_sublist_succ[where ?xs = "queue s1"])
          using False assm_guar mcs0_guar_def mcs0_contract_queue_def apply force
          using assm_inv assm_guar mcs0_invar_def apply simp
          using a by simp
      qed }
    then show ?thesis using mcs0_rely_head_def by simp
  qed
qed

lemma guar_implies_rely_inv_cond_lma:
  assumes assm_i_j:  "i \<noteq> j"
      and assm_guar: "(s1, s2) \<in> lift_guar mcs0_invar (mcs0_guar i)"
    shows "(s1, s2) \<in> lift_rely mcs0_invar (mcs0_rely j)"
proof-
  have ln1: "s1 = s2 \<or> (s1 \<in> mcs0_invar \<and> s2 \<in> mcs0_invar \<and> (s1, s2) \<in> mcs0_guar i)"
    using assm_guar lift_guar_def by blast
  moreover
  { assume a: "s1 \<noteq> s2"
    then have "(s1, s2) \<in> mcs0_rely j"
      using assms guar_implies_rely_inv_cond_lma_1 lift_guar_def by blast
    moreover have "s1 \<in> mcs0_invar \<longrightarrow> s2 \<in> mcs0_invar"
      using ln1 a by auto
    ultimately have ?thesis using lift_rely_def by blast }
  ultimately show ?thesis by force
qed

theorem mcs0_global:
  assumes "0 < NumThreads" shows
  "global_init: mcs0_init  global_rely: Id
    \<parallel> i < NumThreads @
      { \<lbrace> i \<notin> set \<acute>queue \<rbrace>, mcs0_rely i }
    WHILE True DO (code_acq i ;; code_rel i) OD
      \<sslash> mcs0_invar
      { mcs0_guar i, \<lbrace> i \<notin> set \<acute>queue \<rbrace> }
  global_guar: UNIV global_post: \<lbrace> \<acute>queue = [] \<rbrace>"
proof method_multi_parallel
  case guar_rely
  then show ?case using guar_implies_rely_inv_cond_lma by (metis subrelI)
next
  case pre
  then show ?case using mcs0_init_def by force
next
  case rely
  then show ?case by force
next
  case guar
  then show ?case by fast
next
  case post
  then show ?case
    apply standard
    apply standard
    unfolding mcs0_invar_def mcs0_inv_queue_def
    using assms
    apply clarsimp
    by (smt (verit, ccfv_threshold) INT_iff IntD2 Int_Collect hd_in_set inf.orderE inf_commute lessThan_def)
next
  case body
  then show ?case using mcs0_local_loop by fast
qed

(*==================================================================*)
end
