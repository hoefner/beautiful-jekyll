
(*
Title:         Pointers for Rely-Guarantee Reasoning
Author(s):     Robert Colvin, Scott Heiner, Peter Hoefner, Roger Su
Year:          2026
License:       BSD 2-Clause
Maintainer(s): Robert Colvin <r.colvin@uq.edu.au>
               Peter Hoefner <peter@hoefner-online.de>
               Roger Su <roger.c.su@proton.me>
*)

(* To load this file in the Isabelle IDE, run the following command
in the parent directory (above "afp2"):
  isabelle jedit -d . -R RG_MCS_CLH
*)

section \<open>Pointers for Rely-Guarantee Library\<close>

theory Pointers
imports Main "HOL-Hoare_Parallel.RG_Syntax"
begin

type_synonym addr = nat

datatype pointer = Null | Ptr addr

record 'a heap =
  heap :: "pointer \<Rightarrow> 'a"

text \<open>In what follows, the type @{typ \<open>('a, 'b) heap_scheme\<close>} denotes
the state space, where each state is a record with a @{text heap} that
stores values of type @{typ 'a}. All remaining fields of the state are
collectively represented by the type @{typ 'b}.\<close>

fun deref :: "('a, 'b) heap_scheme \<Rightarrow> pointer \<Rightarrow> 'a" where
  "deref s = heap s"

(* The structure-pointer operator: "\<acute>p\<rightarrow>f" means "(\<acute>deref s).f"

The structure-pointer operation is involved in assignment-instructions
in the following syntax: "\<acute>heap[\<acute>p].\<acute>f := v". Could we defined further
syntactic sugar to write this as "\<acute>p \<rightarrow> \<acute>f := v"?
*)

fun struct_pointer
  :: "('a, 'b) heap_scheme \<Rightarrow> pointer \<Rightarrow> ('a \<Rightarrow> 'c) \<Rightarrow> 'c" where
  "struct_pointer s p f = f (deref s p)"

(*==================================================================*)
subsection \<open>Syntax and Translations\<close>

(* Below copied from:
   NGTF-UQ-ANU/papers/CLH/Isabelle/MCS/MCS_param_locksep.thy *)

syntax "_deref_abbrev" :: "'c \<Rightarrow> ('a, 'b) heap_scheme \<Rightarrow> 'd" ("*_" 62)
translations "*n" \<rightharpoonup> " (\<acute>(CONST heap) \<acute>\<guillemotleft>n\<guillemotright>)"

syntax "_heap_update" :: "idt \<Rightarrow> 'c \<Rightarrow> idt \<Rightarrow> 'd \<Rightarrow> 'b \<Rightarrow> 'a com" 
  ("(\<acute>_[_].\<acute>_ \<rightarrow> _ := _)" 61)
translations "\<acute>p[i].\<acute>n \<rightarrow> f := a" \<rightharpoonup> 
  "CONST Basic \<guillemotleft>\<acute>(CONST heap_update  (\<lambda>_. \<acute>(CONST heap)(n (\<acute>p i) := 
     (_update_name f (\<lambda>_. a)) (\<acute>(CONST heap)(n (\<acute>p i))))))\<guillemotright>"

syntax "_heap_update2" :: "idt \<Rightarrow> 'c \<Rightarrow> idt \<Rightarrow> 'd \<Rightarrow> 'b \<Rightarrow> ('a \<Rightarrow> 'a)" 
  ("(\<acute>_[_].\<acute>_ \<rightarrow> _ \<leftarrow> _)" 61)
translations "\<acute>p[i].\<acute>n \<rightarrow> f \<leftarrow> a" \<rightharpoonup> 
  "\<guillemotleft>\<acute>(CONST heap_update  (\<lambda>_. \<acute>(CONST heap)(n (\<acute>p i) := 
     (_update_name f (\<lambda>_. a)) (\<acute>(CONST heap)(n (\<acute>p i))))))\<guillemotright>"

(* New addition on 17 June 2025 *)

syntax "_heap_update" :: "idt \<Rightarrow> 'c \<Rightarrow> idt \<Rightarrow> 'b \<Rightarrow> 'a com" 
  ("(\<acute>_@_\<rightarrow> \<acute>_ := _)" 61)
translations "\<acute>p@i\<rightarrow> \<acute>f := a" \<rightharpoonup> 
  "CONST Basic \<guillemotleft>\<acute>(CONST heap_update  (\<lambda>_. \<acute>(CONST heap)( (\<acute>p i) := 
     (_update_name f (\<lambda>_. a)) (\<acute>(CONST heap)( (\<acute>p i))))))\<guillemotright>"

end
