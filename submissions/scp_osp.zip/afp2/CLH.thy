
(*
Title:         The RG Verification of the CLH Lock
Author(s):     Robert Colvin, Scott Heiner, Peter Hoefner, Roger Su
Year:          2026
License:       BSD 2-Clause
Maintainer(s): Robert Colvin <r.colvin@uq.edu.au>
               Peter Hoefner <peter@hoefner-online.de>
               Roger Su <roger.c.su@proton.me>
*)

(* To load this file in the Isabelle IDE, run the following command
in the parent directory (above "afp2"):
  isabelle jedit -d . -R RG_MCS_CLH
*)

section \<open>CLH\<close>

theory CLH

imports 
  "RGLocks.Concurrent_Queue_Contract"
  "RGLocks.RG_Syntax_Extensions"
  Pointers

begin

type_synonym thread_id = nat

consts NumThreads :: nat

abbreviation "AllThreads \<equiv> {0 ..< NumThreads}"

record node = wait :: bool

record clhs_state = "node heap" +
  tail  ::  pointer
  prev  :: "thread_id \<Rightarrow> pointer"
  myptr :: "thread_id \<Rightarrow> pointer" (* "procs[i].node" in the paper *)
  tmp   :: "thread_id \<Rightarrow> pointer" (* "procs[i].tmp"  in the paper *)
  aux_queue    :: "thread_id list"
  aux_lone     ::  pointer
  aux_reserved :: "thread_id \<Rightarrow> pointer"

definition clhs_init :: "clhs_state set" where
  "clhs_init \<equiv> \<lbrace> \<acute>aux_queue = []
    \<and> \<acute>tail = \<acute>aux_lone \<and> \<acute>tail = Ptr NumThreads \<and> \<not> wait (\<acute>heap \<acute>tail)
    \<and> (\<forall> i < NumThreads. \<acute>myptr i = Ptr i \<and> \<acute>aux_reserved i = Ptr i) \<rbrace>"

(*==================================================================*)
subsection \<open>Specification\<close>

definition clhs_inv_coupl :: "clhs_state set" where
  "clhs_inv_coupl \<equiv> \<lbrace> \<acute>aux_lone # (map \<acute>aux_reserved \<acute>aux_queue)
                      = map \<acute>prev \<acute>aux_queue @ [\<acute>tail] \<rbrace>"

definition clhs_inv_wait :: "clhs_state set" where
  "clhs_inv_wait \<equiv> \<lbrace> \<not> wait (\<acute>heap \<acute>aux_lone)
    \<and> (\<forall> i \<in> set \<acute>aux_queue. wait (\<acute>heap (\<acute>aux_reserved i))) \<rbrace>"

definition clhs_invar :: "clhs_state set" where
  "clhs_invar \<equiv> clhs_inv_coupl \<inter> clhs_inv_wait \<inter>
    \<lbrace> distinct \<acute>aux_queue
    \<and> set \<acute>aux_queue \<subseteq> AllThreads
    \<and> inj_on \<acute>aux_reserved AllThreads
    \<and> (\<forall> i < NumThreads. \<acute>aux_reserved i \<noteq> \<acute>aux_lone) \<rbrace>"

(*------------------------------------------------------------------*)
definition clhs_contract_locals :: "thread_id \<Rightarrow> clhs_state rel" where
  "clhs_contract_locals i \<equiv> ids({myptr, prev, tmp, aux_reserved} @ i)"

definition clhs_contract_queue :: "thread_id \<Rightarrow> clhs_state rel" where
  "clhs_contract_queue i \<equiv> \<lbrace> queue_contract i \<ordmasculine>aux_queue \<ordfeminine>aux_queue \<rbrace>"

definition clhs_contract_flag :: "thread_id \<Rightarrow> clhs_state rel" where
  "clhs_contract_flag i \<equiv>
    \<lbrace> wait (\<ordfeminine>heap (\<ordfeminine>aux_reserved i)) = wait (\<ordmasculine>heap (\<ordmasculine>aux_reserved i)) \<rbrace>"

definition clhs_contract :: "thread_id \<Rightarrow> clhs_state rel" where
  "clhs_contract i \<equiv> clhs_contract_locals i
                   \<inter> clhs_contract_queue i
                   \<inter> clhs_contract_flag i"

(*------------------------------------------------------------------*)
lemmas defs [simp] =
  clhs_inv_coupl_def
  clhs_inv_wait_def
  clhs_invar_def
  clhs_contract_locals_def
  clhs_contract_queue_def
  clhs_contract_flag_def
  clhs_contract_def

(* Peter TO BE FIXED *)
lemma init_invar: "0 < NumThreads \<Longrightarrow> clhs_init \<subseteq> clhs_invar"
  unfolding clhs_init_def
  apply clarsimp
  apply (intro conjI)
  apply (fastforce simp: Collect_mono_iff)
   apply fastforce
  apply (clarsimp simp add: inj_on_def)
  by (metis less_irrefl_nat pointer.inject)

abbreviation "stable_clhs i S \<equiv>
  stable (S \<inter> clhs_invar)
         (lift_rely clhs_invar (clhs_contract i))"

(* Need to override the default on in the library. *)
abbreviation for_others :: "(thread_id \<Rightarrow> 'a rel) \<Rightarrow> thread_id \<Rightarrow> 'a rel" where
  "for_others R i \<equiv> \<Inter> j \<in> (AllThreads - {i}). R j"

method method_seq for m :: "clhs_state set" =
  rule Seq[where mid = "m \<inter> clhs_invar"], goal_cases

(*------------------------------------------------------------------*)
lemma prev_hd_is_lone:
  assumes "s \<in> clhs_inv_coupl"
      and "aux_queue s \<noteq> []"
    shows "prev s (hd (aux_queue s)) = aux_lone s"
  using assms apply clarsimp
  apply(frule hd_map)
  thm hd_append hd_map 
  by (metis hd_append hd_map list.map_disc_iff list.sel(1))

lemma map_helper:
  "\<lbrakk> map f xs = (map g ys) @ [b] ; y \<in> set ys \<rbrakk>
  \<Longrightarrow> \<exists> x \<in> set xs. f x = g y"
  by (induction ys arbitrary: xs;fastforce)

lemma in_queue_not_wait_is_head:
  assumes "s \<in> clhs_invar"
      and "i \<in> set (aux_queue s)"
      and "\<not> wait (heap s (prev s i))"
    shows "i = hd (aux_queue s)"
proof-
  { assume "i \<noteq> hd (aux_queue s)"
    then obtain j ts where a_ts: "i \<noteq> j \<and> aux_queue s = j # ts \<and> i \<in> set ts"
      using assms(2)  by(fastforce elim: list.set_cases)
    then have "map (aux_reserved s) (aux_queue s) = map (prev s) ts @ [tail s]"
      using assms(1) by force
    then have "\<exists> k. k \<in> set (aux_queue s) \<and> prev s i = aux_reserved s k"
      using a_ts by (fastforce dest: map_helper)
    then have "wait (heap s (prev s i))"
      using assms(1) by fastforce
    then have False
      using assms(3) by fastforce }
  then show ?thesis by fast
qed

(*==================================================================*)
subsection \<open>Acquire\<close>

abbreviation acq_code :: "thread_id \<Rightarrow> clhs_state com" where
  "acq_code i \<equiv>
    (\<acute>myptr@i\<rightarrow>\<acute>wait := True) ;;
    Basic ((\<acute>prev[i] \<leftarrow> \<acute>tail) \<circ>>
           (\<acute>tail \<leftarrow> \<acute>myptr i) \<circ>>
           (\<acute>aux_queue \<leftarrow> \<acute>aux_queue @ [i])) ;;
    (\<acute>tmp[i] := \<acute>prev i) ;;
    (WHILE wait (\<acute>heap (\<acute>prev i)) DO SKIP OD)"

abbreviation "acq_mid_0 i \<equiv>
  \<lbrace> i \<notin> set \<acute>aux_queue \<and> \<acute>myptr i = \<acute>aux_reserved i \<rbrace>"

abbreviation "acq_mid_1 i \<equiv>
  \<lbrace> i \<notin> set \<acute>aux_queue \<and> \<acute>myptr i = \<acute>aux_reserved i
    \<and> wait (\<acute>heap (\<acute>myptr i)) \<rbrace>"

abbreviation "acq_mid_2 i \<equiv>
  \<lbrace> i \<in> set \<acute>aux_queue \<and> \<acute>myptr i = \<acute>aux_reserved i \<rbrace>"

abbreviation "acq_mid_3 i \<equiv>
  \<lbrace> i \<in> set \<acute>aux_queue \<and> \<acute>myptr i = \<acute>aux_reserved i
    \<and> \<acute>tmp i = \<acute>prev i \<rbrace>"

abbreviation "acq_mid_4 i \<equiv>
  \<lbrace> at_head i \<acute>aux_queue \<and> \<acute>myptr i = \<acute>aux_reserved i
    \<and> \<acute>tmp i = \<acute>aux_lone \<rbrace>"

lemma stable_clhs_conjI:
  "\<lbrakk> stable_clhs i \<lbrace> \<acute>P i \<rbrace> ; stable_clhs i \<lbrace> \<acute>Q i \<rbrace> \<rbrakk>
  \<Longrightarrow> stable_clhs i \<lbrace> \<acute>P i \<and> \<acute>Q i \<rbrace>"
  unfolding stable_def by blast

lemma stable_clhs_acq_mid_4: "stable_clhs i (acq_mid_4 i)"
proof-
  have "stable_clhs i \<lbrace> \<acute>myptr i = \<acute>aux_reserved i \<rbrace>"
    by fastforce
  moreover
  have "stable_clhs i \<lbrace> at_head i \<acute>aux_queue \<and> \<acute>tmp i = \<acute>aux_lone \<rbrace>"
    unfolding stable_def apply clarsimp
    by (metis Nil_suffix empty_iff hd_append2 hd_map list.map_disc_iff list.sel(1) 
              prefix_before_empty_is_head set_empty suffix_order.dual_order.antisym)
  ultimately have "stable_clhs i \<lbrace> \<acute>myptr i = \<acute>aux_reserved i \<and>
                     at_head i \<acute>aux_queue \<and> \<acute>tmp i = \<acute>aux_lone \<rbrace>"
    by (fast intro: stable_clhs_conjI)
  moreover
  have "acq_mid_4 i = \<lbrace> \<acute>myptr i = \<acute>aux_reserved i \<and> 
                        at_head i \<acute>aux_queue \<and> \<acute>tmp i = \<acute>aux_lone \<rbrace>"
    by fast
  ultimately show ?thesis by metis
qed

(*------------------------------------------------------------------*)
lemma acq_1:
  assumes "i < NumThreads" shows
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_0 i }
  \<acute>myptr@i\<rightarrow>\<acute>wait := True
    { acq_mid_1 i }"
proof method_basic_inv
  case est_guar
  then show ?case 
    by (clarsimp simp add: assms inj_onD)
qed (use assms in fastforce)+

(*------------------------------------------------------------------*)
lemma acq_2:
  assumes "i < NumThreads" shows
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_1 i }
  Basic ((\<acute>prev[i] \<leftarrow> \<acute>tail) \<circ>>
           (\<acute>tail \<leftarrow> \<acute>myptr i) \<circ>>
           (\<acute>aux_queue \<leftarrow> \<acute>aux_queue @ [i]))
    { acq_mid_2 i }"
  apply (method_basic_inv; simp add: assms)
  by (fastforce)+

(*------------------------------------------------------------------*)
lemma acq_3:
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_2 i }
  \<acute>tmp[i] := \<acute>prev i
    { acq_mid_3 i }"
  apply (method_basic_inv; simp)
  by (fastforce)+

(*------------------------------------------------------------------*)
lemma acq_4:
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_3 i }
  WHILE wait (\<acute>heap (\<acute>prev i)) DO SKIP OD
    { acq_mid_4 i }"
proof method_spinloop
  case est_post
  then show ?case
  proof-
    { fix x
      assume a: "x \<in> acq_mid_3 i \<inter> clhs_invar \<inter> - \<lbrace> wait (\<acute>heap (\<acute>prev i)) \<rbrace>"
      then have "x \<in> \<lbrace> at_head i \<acute>aux_queue \<rbrace>"
        using in_queue_not_wait_is_head by fast
      moreover have "x \<in> \<lbrace> \<acute>tmp i = \<acute>aux_lone \<rbrace>"
        using a apply simp
        by (metis (no_types, lifting) Int_iff a clhs_invar_def in_queue_not_wait_is_head 
                  prev_hd_is_lone queue_contract_id queue_contract_nonempty)
      ultimately have "x \<in> acq_mid_4 i \<inter> clhs_invar"
        using a by fast }
    then show ?thesis by blast
  qed
qed (fastforce intro!: stable_clhs_acq_mid_4)+

(*------------------------------------------------------------------*)
theorem acq_combined:
  assumes "i < NumThreads" shows
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_0 i }
  acq_code i
    { acq_mid_4 i }"
proof (method_seq "acq_mid_3 i", goal_cases 13 4)
  case 13 show ?case
  proof (method_seq "acq_mid_2 i", goal_cases 12 3)
    case 12 show ?case
      apply (method_seq "acq_mid_1 i")
      by (fastforce intro!: assms acq_1 acq_2)+
    case 3 show ?case by (fastforce intro!: acq_3)
  qed
  case 4 show ?case by (fastforce intro!: acq_4)
qed

(*==================================================================*)
subsection \<open>Release\<close>

(* Sets the "wait" flag to False. *)
abbreviation set_flag :: "thread_id \<Rightarrow> clhs_state \<Rightarrow> clhs_state" where
  "set_flag i s \<equiv> s\<lparr>
    heap := (heap s)(myptr s i := \<lparr> wait = False \<rparr>) \<rparr>"

(* Exchanges the values of "aux_lone" and "aux_reserved i". *)
abbreviation exchange :: "thread_id \<Rightarrow> clhs_state \<Rightarrow> clhs_state" where
  "exchange i s \<equiv> s\<lparr>
    aux_lone := aux_reserved s i,
    aux_reserved := (aux_reserved s)(i := aux_lone s) \<rparr>"

abbreviation rel_code :: "thread_id \<Rightarrow> clhs_state com" where
  "rel_code i \<equiv>
    Basic ((set_flag i) \<circ>>
           (exchange i) \<circ>>
           (\<acute>aux_queue \<leftarrow> tl \<acute>aux_queue)) ;;
    (\<acute>myptr[i] := \<acute>tmp i)"

abbreviation rel_ln1 :: "thread_id \<Rightarrow> clhs_state \<Rightarrow> clhs_state" where
  "rel_ln1 i \<equiv>
    (set_flag i) \<circ>>
    (exchange i) \<circ>>
    (\<acute>aux_queue \<leftarrow> tl \<acute>aux_queue)"

abbreviation "rel_mid_1 i \<equiv>
  \<lbrace> i \<notin> set \<acute>aux_queue \<and> \<acute>tmp i = \<acute>aux_reserved i \<rbrace>"

(*------------------------------------------------------------------*)
lemma rel_1_est_inv:
  assumes "s \<in> acq_mid_4 i \<inter> clhs_invar"
      and "i < NumThreads"
    shows "rel_ln1 i s \<in>  clhs_invar"
  unfolding clhs_invar_def
proof (intro IntI, goal_cases coupl wait others)
  case coupl
  then show ?case 
    using assms(1) apply clarsimp
    by (metis (no_types, lifting) at_head_tl length_map length_pos_if_in_set less_numeral_extra(3) 
                        list.collapse list.sel(3) list.simps(9) list.size(3) map_fun_upd tl_append2) 
next
  case wait
  then show ?case 
    using assms(1) apply clarsimp
    by (meson at_head_tl inj_on_eq_iff set_mono_suffix subset_code(1) suffix_tl)
next
  case others
  then show ?case
  proof (standard, intro conjI, goal_cases)
    case 1
    then show ?case
      using assms(1) distinct_tl by fastforce
  next
    case 2
    have "set (aux_queue s) \<subseteq> AllThreads"
      using assms(1) by fastforce
    then have "set (tl (aux_queue s)) \<subseteq> AllThreads"
      by (metis set_mono_sublist sublist_tl subset_trans)
    then show ?case
      by fastforce
  next
    case 3
    have "inj_on (aux_reserved s) AllThreads"
      using assms(1) by simp
    moreover have "\<forall> j \<in> AllThreads. aux_reserved s j \<noteq> aux_lone s"
      using assms(1) by simp
    ultimately show ?case
      unfolding  inj_on_def  apply simp
      by fastforce
  next
    case 4
    show ?case
      using assms apply simp
      unfolding inj_on_def
      by (metis atLeastLessThan_iff less_eq_nat.simps(1))
  qed
qed

(*------------------------------------------------------------------*)
lemma rel_1_est_guar:
  assumes "s \<in> acq_mid_4 i \<inter> clhs_invar"
      and "i < NumThreads"
    shows "(s, rel_ln1 i s) \<in> for_others clhs_contract i"
  unfolding clhs_contract_def
proof (standard, intro IntI, goal_cases locals queue flag)
  case (queue j)
  then show ?case
    using assms apply clarsimp
    by (metis (no_types) IntI prefix_suffix_clause_def queue_contract_def queue_contract_tl)
next
  case (flag j)
  then show ?case
    using assms
    by (clarsimp simp: inj_on_contraD)
qed (clarsimp)

(*------------------------------------------------------------------*)
lemma rel_1:
  assumes "i < NumThreads" shows
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_4 i }
    Basic ((set_flag i) \<circ>>
           (exchange i) \<circ>>
           (\<acute>aux_queue \<leftarrow> tl \<acute>aux_queue))
    { rel_mid_1 i }"
proof method_basic_inv
  case stab_pre
  then show ?case using stable_clhs_acq_mid_4 by fast
next
  case est_inv
  then show ?case using assms rel_1_est_inv by blast
next
  case est_post
  then show ?case using at_head_tl by fastforce
next
  case est_guar
  then show ?case using assms rel_1_est_guar by blast
qed (force+)

(*------------------------------------------------------------------*)
lemma rel_2:
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { rel_mid_1 i }
  \<acute>myptr[i] := \<acute>tmp i
    { acq_mid_0 i }"
  by (method_basic_inv;(clarsimp; fastforce))

(*------------------------------------------------------------------*)
theorem rel_combined:
  assumes "i < NumThreads" shows
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_4 i }
  rel_code i
    { acq_mid_0 i }"
  by (method_seq "rel_mid_1 i"; fastforce intro!: rel_1 rel_2 simp: assms)

(*==================================================================*)
subsection \<open>Combined\<close>

lemma clhs_local_loop:
  assumes "i < NumThreads" shows
  "rely: clhs_contract i  guar: for_others clhs_contract i
    inv: clhs_invar       code:
    { acq_mid_0 i }
  WHILE True DO (acq_code i ;; rel_code i) OD
    { {} }"
proof method_loop
  case loop_body show ?case
    apply (method_seq "acq_mid_4 i")
    using assms by (fastforce dest: acq_combined rel_combined)+
qed (force+)

theorem clhs__global:
  assumes "0 < NumThreads" shows
  "global_init: clhs_init  global_rely: Id
    \<parallel> i < NumThreads @
      { acq_mid_0 i, clhs_contract i }
    WHILE True DO (acq_code i ;; rel_code i) OD
      \<sslash> clhs_invar
      { for_others clhs_contract i, {} }
  global_guar: UNIV global_post: {}"
proof method_multi_parallel
  case pre
  then show ?case
    apply (standard, standard, standard)
    apply (rule IntI)
    using clhs_init_def apply force
    using init_invar by fastforce
qed (fastforce intro!: clhs_local_loop assms)+ (* takes a few seconds *)

end
