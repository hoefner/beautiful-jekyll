(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Crunch
imports
  Lib.Crunch
  VCG_No_Div
  VCG_No_Fail
  VCG_No_Trace
  VCG_Non_Null
  VCG_Single_Step
begin

lemmas [crunch_param_rules] = Let_def return_bind K_bind_def split_def bind_assoc

ML \<open>
fun get_trace_monad_state_type
      (Type ("Set.set", [Type ("Trace_Monad.tmres", [v,_])])) = SOME v
  | get_trace_monad_state_type _ = NONE

structure CrunchValidInstance : CrunchInstance =
struct
  val name = "valid";
  val prefix_name_scheme = false;
  type extra = term;
  val eq_extra = ae_conv;
  fun parse_extra ctxt extra
        = case extra of
            "" => error "A post condition is required"
          | extra => let val pre = Syntax.parse_term ctxt extra
              in (pre, Abs ("_", dummyT, pre)) end;
  val has_preconds = true;
  fun mk_term pre body post =
    (Syntax.parse_term @{context} "valid") $ pre $ body $ post;
  fun dest_term ((Const (@{const_name "valid"}, _)) $ pre $ body $ post)
        = SOME (pre, body, post)
    | dest_term _ = NONE;
  fun put_precond pre ((v as Const (@{const_name "valid"}, _)) $ _ $ body $ post)
        = v $ pre $ body $ post
    | put_precond _ _ = error "put_precond: not a hoare triple";
  val pre_thms = @{thms "hoare_pre"};
  val pre_delim = @{const_name inf};
  val wpc_tactic = wp_cases_tactic_weak;
  fun wps_tactic _ _ _ = no_tac;
  val magic = Syntax.parse_term @{context}
    "\<lambda>mapp_lambda_ignore. valid P_free_ignore mapp_lambda_ignore Q_free_ignore";
  val get_monad_state_type = get_trace_monad_state_type;
end;

structure CrunchValid : CRUNCH = Crunch(CrunchValidInstance);

structure CrunchNoFailInstance : CrunchInstance =
struct
  val name = "no_fail";
  val prefix_name_scheme = true;
  type extra = unit;
  val eq_extra = op =;
  fun parse_extra ctxt extra
        = case extra of
            "" => (Syntax.parse_term ctxt "%_. True", ())
          | _ => (Syntax.parse_term ctxt extra, ());
  val has_preconds = true;
  fun mk_term pre body _ =
    (Syntax.parse_term @{context} "no_fail") $ pre $ body;
  fun dest_term ((Const (@{const_name "no_fail"}, _)) $ pre $ body)
        = SOME (pre, body, ())
    | dest_term _ = NONE;
  fun put_precond pre ((v as Const (@{const_name "no_fail"}, _)) $ _ $ body)
        = v $ pre $ body
    | put_precond _ _ = error "put_precond: not a no_fail term";
  val pre_thms = @{thms "no_fail_pre"};
  val pre_delim = @{const_name inf};
  val wpc_tactic = wp_cases_tactic_weak;
  fun wps_tactic _ _ _ = no_tac;
  val magic = Syntax.parse_term @{context}
    "\<lambda>mapp_lambda_ignore. no_fail P_free_ignore mapp_lambda_ignore";
  val get_monad_state_type = get_trace_monad_state_type;
end;

structure CrunchNoFail : CRUNCH = Crunch(CrunchNoFailInstance);

structure CrunchNoDivInstance : CrunchInstance =
struct
  val name = "no_div";
  val prefix_name_scheme = true;
  type extra = unit;
  val eq_extra = op =;
  fun parse_extra ctxt extra
        = case extra of
            "" => (Syntax.parse_term ctxt "%_. True", ())
          | _ => (Syntax.parse_term ctxt extra, ());
  val has_preconds = true;
  fun mk_term pre body _ =
    (Syntax.parse_term @{context} "no_div") $ pre $ body;
  fun dest_term ((Const (@{const_name "no_div"}, _)) $ pre $ body)
        = SOME (pre, body, ())
    | dest_term _ = NONE;
  fun put_precond pre ((v as Const (@{const_name "no_div"}, _)) $ _ $ body)
        = v $ pre $ body
    | put_precond _ _ = error "put_precond: not a no_div term";
  val pre_thms = @{thms "no_div_pre"};
  val pre_delim = @{const_name inf};
  val wpc_tactic = wp_cases_tactic_weak;
  fun wps_tactic _ _ _ = no_tac;
  val magic = Syntax.parse_term @{context}
    "\<lambda>mapp_lambda_ignore. no_div P_free_ignore mapp_lambda_ignore";
  val get_monad_state_type = get_trace_monad_state_type;
end;

structure CrunchNoDiv : CRUNCH = Crunch(CrunchNoDivInstance);

structure CrunchNoTraceInstance : CrunchInstance =
struct
  val name = "no_trace";
  val prefix_name_scheme = true;
  type extra = unit;
  val eq_extra = op =;
  fun parse_extra ctxt extra
        = case extra of
            "" => (Syntax.parse_term ctxt "%_. True", ())
          | _ => (Syntax.parse_term ctxt extra, ());
  val has_preconds = true;
  fun mk_term pre body _ =
    (Syntax.parse_term @{context} "no_trace") $ pre $ body;
  fun dest_term ((Const (@{const_name "no_trace"}, _)) $ pre $ body)
        = SOME (pre, body, ())
    | dest_term _ = NONE;
  fun put_precond pre ((v as Const (@{const_name "no_trace"}, _)) $ _ $ body)
        = v $ pre $ body
    | put_precond _ _ = error "put_precond: not a no_trace term";
  val pre_thms = @{thms "no_trace_pre"};
  val pre_delim = @{const_name inf};
  val wpc_tactic = wp_cases_tactic_weak;
  fun wps_tactic _ _ _ = no_tac;
  val magic = Syntax.parse_term @{context}
    "\<lambda>mapp_lambda_ignore. no_trace P_free_ignore mapp_lambda_ignore";
  val get_monad_state_type = get_trace_monad_state_type;
end;

structure CrunchNoTrace : CRUNCH = Crunch(CrunchNoTraceInstance);

structure CrunchNonEmptyInstance : CrunchInstance =
struct
  val name = "non_null";
  val prefix_name_scheme = true;
  type extra = unit;
  val eq_extra = op =;
  fun parse_extra ctxt extra
        = case extra of
            "" => (Syntax.parse_term ctxt "%_. False", ())
          | _ => (Syntax.parse_term ctxt extra, ());
  val has_preconds = true;
  fun mk_term pre body _ =
    (Syntax.parse_term @{context} "non_null") $ pre $ body;
  fun dest_term ((Const (@{const_name "non_null"}, _)) $ pre $ body)
        = SOME (pre, body, ())
    | dest_term _ = NONE;
  fun put_precond pre ((v as Const (@{const_name "non_null"}, _)) $ _ $ body)
        = v $ pre $ body
    | put_precond _ _ = error "put_precond: not a non_null term";
  val pre_thms = @{thms "non_null_pre"};
  val pre_delim = @{const_name sup};
  val wpc_tactic = wp_cases_tactic_weak;
  fun wps_tactic _ _ _ = no_tac;
  val magic = Syntax.parse_term @{context}
    "\<lambda>mapp_lambda_ignore. non_null P_free_ignore mapp_lambda_ignore";
  val get_monad_state_type = get_trace_monad_state_type;
end;

structure CrunchNonEmpty : CRUNCH = Crunch(CrunchNonEmptyInstance);

\<close>

setup \<open>
  add_crunch_instance "" (CrunchValid.crunch_x, CrunchValid.crunch_ignore_add_dels)
\<close>
setup \<open>
  add_crunch_instance "valid" (CrunchValid.crunch_x, CrunchValid.crunch_ignore_add_dels)
\<close>
setup \<open>
  add_crunch_instance "no_fail" (CrunchNoFail.crunch_x, CrunchNoFail.crunch_ignore_add_dels)
\<close>
setup \<open>
  add_crunch_instance "no_div" (CrunchNoDiv.crunch_x, CrunchNoDiv.crunch_ignore_add_dels)
\<close>
setup \<open>
  add_crunch_instance "no_trace" (CrunchNoTrace.crunch_x, CrunchNoTrace.crunch_ignore_add_dels)
\<close>
setup \<open>
  add_crunch_instance "non_null" (CrunchNonEmpty.crunch_x, CrunchNonEmpty.crunch_ignore_add_dels)
\<close>

end
