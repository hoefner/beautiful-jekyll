(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_More
  imports
    VCG_Crunch
begin

(* FIXME ryanb: update wrt. current hierarchy *)

definition validc :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> 's zstep ltl \<Rightarrow> bool"
  ("\<lbrace>_\<rbrace>/ _ /\<lbrace>_\<rbrace>\<^sup>\<omega>") where
  "\<lbrace>P\<rbrace> f \<lbrace>F\<rbrace>\<^sup>\<omega> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>tr \<in> runTrace f s. (tr,0) \<Turnstile> F)"

lemma validc_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>\<omega> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>\<omega>"
  by (fastforce simp: validc_def)

lemmas validc_weaken_pre[wp_pre] = validc_pre_imp[rotated]

lemma validc_post_imp:
  "\<lbrakk> \<And>ts. (ts,0) \<Turnstile> Q' \<Longrightarrow> (ts,0) \<Turnstile> Q; \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>\<omega> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>\<omega>"
  by (auto simp: validc_def split_def)

lemmas validc_strengthen_post = validc_post_imp[rotated]


definition validL :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> 's zstep ltl \<Rightarrow> bool"
  ("\<lbrace>_\<rbrace>/ _ /\<lbrace>_\<rbrace>\<^sup>\<infinity>") where
  "\<lbrace>P\<rbrace> f \<lbrace>F\<rbrace>\<^sup>\<infinity> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>tr \<in> runStream f s. (tr,0) \<tturnstile> F)"

lemma validL_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>\<infinity> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>\<infinity>"
  by (fastforce simp: validL_def)

lemmas validL_weaken_pre[wp_pre] = validL_pre_imp[rotated]

lemma validL_post_imp:
  "\<lbrakk> \<And>ts. (ts,0) \<tturnstile> Q' \<Longrightarrow> (ts,0) \<tturnstile> Q; \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>\<infinity> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>\<infinity>"
  by (auto simp: validL_def split_def)

lemmas validL_strengthen_post = validL_post_imp[rotated]

lemma no_trace_G:
  "no_trace P f \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>\<box>G\<rbrace>\<^sup>*"
  apply (clarsimp simp: validl_def2)
  apply (drule runList_tmres, clarsimp)
  apply (drule (2) no_traceD)
  apply (clarsimp simp: ltl_semantics)
  done

lemma when_G[wp_split]:
  "\<lbrakk> P \<Longrightarrow> \<lbrace>Q\<rbrace> f \<lbrace>\<box>G\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>if P then Q else \<top>\<rbrace> when P f \<lbrace>\<box>G\<rbrace>\<^sup>*"
  apply (clarsimp simp: when_def)
  apply (wp no_trace_G)
  done

(* FIXME ryanb *)
declare wp_post_taut[simp, wp]
declare validl_post_taut[wp]

lemma K_bind_app:
  "K_bind f rv = f"
  by simp

end
