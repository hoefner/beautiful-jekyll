(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_RG
imports VCG_More
begin

abbreviation Rely :: "('s \<Rightarrow> 's \<Rightarrow> bool) \<Rightarrow> 's zstep ltl" where
  "Rely R \<equiv> \<A>(\<lambda>(s,a,s'). a = Env \<longrightarrow> R s s')"

abbreviation Guar :: "('s \<Rightarrow> 's \<Rightarrow> bool) \<Rightarrow> 's zstep ltl" where
  "Guar G \<equiv> \<A>(\<lambda>(s,a,s'). a = Proc \<longrightarrow> G s s')"

abbreviation RG\<^sub>l :: "('s \<Rightarrow> 's \<Rightarrow> bool) \<Rightarrow> ('s \<Rightarrow> 's \<Rightarrow> bool) \<Rightarrow> 's zstep ltl" where
  "RG\<^sub>l R G \<equiv> (\<not>\<^sub>lRely R \<R> Guar G)"

lemma ltl_RG_def:
  "(ts,n) \<Turnstile> RG\<^sub>l R G = (\<forall>i. n \<le> i \<and> i < llength ts \<and>
                           (\<forall>j. n \<le> j \<and> j \<le> i \<longrightarrow> (ts,j) \<Turnstile> Rely R)
                       \<longrightarrow> (\<forall>j. n \<le> j \<and> j \<le> i \<longrightarrow> (ts,j) \<Turnstile> Guar G))"
  apply (rule iffI; clarsimp?)
   apply (smt (verit) antisym_conv2 enat_ord_simps(1) ltl_not_def ltl_releaseD order.strict_implies_order order.strict_trans)
  apply (rule ccontr)
  apply (subst (asm) ltl_not_def[symmetric])
  apply (simp only: ltl_nnf)
  apply (clarsimp simp: ltl_until_def ltl_not_def)
  apply (erule_tac x="enat j" in allE, clarsimp)
  by (smt (verit) case_prodI2 le_eq_less_or_eq ltl_atom_def prod.inject tmid.distinct(1))

lemma GG_RG:
  "(ts,n) \<Turnstile> \<box> Guar G \<Longrightarrow> (ts,n) \<Turnstile> RG\<^sub>l R G"
  by (simp add: LTL_Release_def ltl_disj_def)

(* FIXME ryanb: move *)
lemma last_st_iff:
  "last_st ts s = (if ts = [] then s else snd (ts ! (length ts - 1)))"
  apply (induct ts arbitrary: s; clarsimp split: if_splits)
  apply (case_tac ts; clarsimp)
  done

(* FIXME ryanb: move *)
lemma ltlf_drop_Suc:
  "(xs, Suc n) \<turnstile> F = (drop 1 xs, n) \<turnstile> F"
  by (simp add: ltlf_drop)

(* FIXME ryanb: move *)
lemma zlist_nth_iff:
  "n < length ts \<Longrightarrow>
   zlist ts s ! n = (if n = 0 then s else snd (ts ! (n - 1)), ts ! n)"
  by (induct ts arbitrary: s n; clarsimp?)

lemma validl2_globally_induct:
 assumes "\<And>a s s'. \<lbrakk> P s; R (s,a,s') \<rbrakk> \<Longrightarrow> P s' \<and> R' (s,a,s')"
  shows "\<lbrace>P\<rbrace>,\<lbrace>\<box>\<A>(R)\<rbrace> f \<lbrace>\<lambda>_. P\<rbrace>,\<lbrace>\<box>\<A>(R')\<rbrace>"
  apply (clarsimp simp: validl2_def)
  apply (case_tac "ts = []", clarsimp simp: ltl_semantics)
  apply (thin_tac "Result ts rv \<in> f s")
  apply (prop_tac "0 < length (zlist ts s)")
   apply (simp add: zlist_length)
  apply clarsimp
  apply (prop_tac "ts \<noteq> [] \<and> (zlist ts s, 0) \<turnstile> \<box>\<A>(R) \<and> P s"; clarsimp)
  subgoal for s ts apply (induct ts arbitrary: s rule: list_nonempty_induct)
    using assms apply (fastforce simp: ltl_semantics)
    apply clarsimp
    apply (rename_tac s' ts s)
    apply (erule_tac x=s' in meta_allE)
    apply (prop_tac "(zlist ts s', 0) \<turnstile> \<box>\<A>(R)")
     apply (rule ltl_globallyI)
     apply (erule_tac i="Suc i" in ltl_globallyE(2); clarsimp simp: ltlf_drop_Suc)
    apply clarsimp
    apply (drule meta_mp)
    using assms apply (fastforce simp: ltl_semantics)
    apply (clarsimp simp: last_st_iff)
    apply (rule ltl_globallyI)
    apply (case_tac i; clarsimp)
     apply (erule_tac i=0 in ltl_globallyE(2); clarsimp?)
    using assms apply (fastforce simp: ltl_semantics)
    apply (clarsimp simp: ltlf_drop_Suc)
    apply (erule_tac i=nat in ltl_globallyE(2); clarsimp)
    done
  done

lemma rely_env_steps:
  "\<lbrace>P\<rbrace>,\<lbrace>\<box>\<A>(\<lambda>(s,a,s'). R s s')\<rbrace> env_steps \<lbrace>Q\<rbrace>,\<lbrace>F\<rbrace>
   \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>\<box>Rely R\<rbrace> env_steps \<lbrace>Q\<rbrace>,\<lbrace>F\<rbrace>"
  apply (rule validl2I)
  apply (erule (2) validl2D)
  apply (clarsimp simp: ltl_semantics)
  apply (clarsimp simp: env_steps_def get_def put_list_def put_llist_def
                        choice_def select_def bind_def return_def)
  apply (auto simp: hd_drop_conv_nth zlist_length zlist_nth_iff)

  done

end
