(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Loop
imports
  VCG_Measure
  VCG_More
  VCG_Validl2
begin

lemma loop_simple:
  "\<lbrakk> non_null \<top> f; no_div \<top> f \<rbrakk>
     \<Longrightarrow> loop f = dloop f"
  apply (rule ext)
  apply (rename_tac s)
  apply (intro equalityI subsetI)
   apply (simp add: loop_def2)
   apply (elim disjE; clarsimp)
    apply (clarsimp simp: dloop_def)
   apply (simp add: dloop_def)
   apply (rule_tac x=ts in exI, clarsimp)
   apply (erule dloop_div.coinduct) back back
  apply (subst (asm) whileLoopD.simps)
  apply (fastforce simp: no_div_def diverged_def non_null_def)
  apply (clarsimp simp: dloop_def)
  apply (elim disjE; clarsimp)
   apply (clarsimp simp: loop_def2)
  apply (simp add: loop_def2)
   apply (rule_tac x=tr in exI, clarsimp)
   apply (erule whileLoopD.coinduct) back back
  apply (subst (asm) dloop_div.simps)
  apply (fastforce simp: no_div_def diverged_def non_null_def)
  done

lemma runTrace_loop_simple:
  "\<lbrakk> ts \<in> runTrace (loop f) s; no_div \<top> f; non_null \<top> f \<rbrakk>
    \<Longrightarrow> stream_of_llist ts \<in> runStream (dloop f) s"
  apply (simp add: loop_simple)
  apply (clarsimp simp: runTrace_def)
  apply (case_tac x; clarsimp)
  apply (simp add: dloop_infinite zstream_tmres ztrace_zstream)
  using dloop_cases by force

lemma runTrace_dloop_infinite:
  "ts \<in> runTrace (dloop f) s \<Longrightarrow> \<not>lfinite ts"
  apply (clarsimp simp: runTrace_def dloop_def)
  apply (frule dloop_div_infinite)
  apply (drule dloop_div_non_null)
  apply (prop_tac "lfinite (lconcat tr)")
   apply (simp add: lfinite_conv_llength_enat ztrace_length)
  by (metis in_lset_conv_lnth lfilter_id_conv lfinite_lconcat)

lemma runTrace_ltl_semantics:
  "\<lbrakk> ts \<in> runTrace (loop f) s; no_div \<top> f; non_null \<top> f; \<And>ts. ts \<in> runStream (loop f) s \<Longrightarrow> (ts,n) \<tturnstile> P \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> P"
  apply (subgoal_tac "\<not>lfinite ts")
   apply (frule (2) runTrace_loop_simple)
   apply (metis llist_of_stream_stream_of_llist loop_simple ltli_from)
  apply (simp add: loop_simple runTrace_dloop_infinite)
  done

(* FIXME ryanb: rename and move *)
lemma bcoversE':
  "\<lbrakk> fs bcovers\<^sup>+ F; (L, R) \<in> set fs; (xs, 0) \<turnstile> L; (ys, 0) \<tturnstile> R; xs \<noteq> []; (xs @- ys, 0) \<tturnstile> F \<Longrightarrow> P\<rbrakk>
     \<Longrightarrow> P"
  using bcoversE(3)[where xs="llist_of xs" and ys="llist_of_stream ys", simplified from_ltl]
  by (metis lappend_llist_of_stream_conv_shift lfinite_llist_of lnull_llist_of ltli_from)


lemma loop_g:
  "\<lbrakk> ts \<in> runStream (loop f) s; no_div \<top> f; non_null \<top> f; I s; [(L,R)] bcovers\<^sup>+ P;
     \<And>ts s. \<lbrakk> ts \<in> runList f s; I s\<rbrakk> \<Longrightarrow> (ts,0) \<turnstile> \<box>L;
     \<And>ts s. \<lbrakk> ts \<in> runStream (loop f) s; I s\<rbrakk> \<Longrightarrow> (ts,0) \<tturnstile> R;
     \<And>ts s. \<lbrakk> ts \<in> runList f s; I s\<rbrakk> \<Longrightarrow> (ts,0) \<turnstile> ltl_invariant I \<rbrakk>
     \<Longrightarrow> (ts, n) \<tturnstile> \<box>P"
  apply (simp add: loop_simple)
  apply (rule ltl_globallyI)
  apply (rule ltl_sdrop[where j=0, simplified])
  apply (erule_tac I=I in zloopE, clarsimp)
   apply (elim meta_allE)
   apply (drule (1) meta_mp)+
   apply (case_tac "xs = []")
    apply clarsimp
   apply (clarsimp simp: ltlf_opt_def finally_globally_atom)
   apply (subst (asm) finally_globally_atom; fastforce)
  apply (erule meta_allE, erule meta_allE, drule (1) meta_mp, drule (1) meta_mp)
  apply (erule meta_allE, erule meta_allE, drule (1) meta_mp, drule (1) meta_mp)
  apply (prop_tac "(drop na xs, 0) \<turnstile> L")
   apply (simp add: ltlf_drop ltlf_globally_def)
  apply (erule bcoversE', simp+)
  done

lemma loop_f:
  "\<lbrakk> ts \<in> runStream (loop f) s; no_div \<top> f; non_null \<top> f; I s; [(L,R)] bcovers\<^sup>+ P;
     \<And>ts s. \<lbrakk> ts \<in> runList f s; I s \<rbrakk> \<Longrightarrow> (ts,0) \<turnstile> \<diamond>L;
     \<And>ts s. \<lbrakk> ts \<in> runStream (loop f) s; I s \<rbrakk> \<Longrightarrow> (ts,0) \<tturnstile> R;
     \<And>ts s. \<lbrakk> ts \<in> runList f s; I s \<rbrakk> \<Longrightarrow> (ts,0) \<turnstile> ltl_invariant I \<rbrakk>
     \<Longrightarrow> (ts, n) \<tturnstile> \<diamond>P"
  apply (simp add: loop_simple)
  apply (rule ltl_sdrop[where j=0, simplified])
  apply (erule_tac I=I in zloopE, clarsimp)
   apply (elim meta_allE)
   apply (drule (1) meta_mp)+
   apply (case_tac "xs = []")
    apply clarsimp
   apply (clarsimp simp: ltlf_opt_def finally_globally_atom)
   apply (subst (asm) finally_globally_atom; fastforce)
  apply (rename_tac st n)
  apply (subgoal_tac "(ys,0) \<tturnstile> \<diamond>P")
   apply (erule bcoversE'[OF bcovers_finally(3)]; simp?)
    apply (clarsimp simp: plist_defs, simp)
   apply simp
  apply (erule dloop_zcases)
  apply clarsimp
  apply (rename_tac ys zs)
  apply (erule_tac x=zs in meta_allE, erule meta_allE, drule (1) meta_mp)
  apply (erule_tac x=ys in meta_allE, erule meta_allE, drule (1) meta_mp, drule (1) meta_mp)+
  apply (drule meta_mp)
   apply (clarsimp simp: ltlf_opt_def)
   apply (prop_tac "ys \<noteq> []")
    apply (metis less_nat_zero_code list.size(3) ltlf_finally_def)
   apply (metis finally_globally_atom ltl_conjE(2))
  apply (rule_tac ys=zs in bcoversE'[OF bcovers_finally(3)]; simp?)
   apply (fastforce simp: plist_defs)
  by (metis less_nat_zero_code list.size(3) ltlf_finally_def)

lemma loop_gf:
  "\<lbrakk> ts \<in> runStream (loop f) s; no_div \<top> f; non_null \<top> f; I s;
     \<And>ts s. \<lbrakk> ts \<in> runStream (loop f) s; I s \<rbrakk> \<Longrightarrow> (ts,0) \<tturnstile> \<diamond>P;
     \<And>ts s. \<lbrakk> ts \<in> runList f s; I s\<rbrakk> \<Longrightarrow> (ts,0) \<turnstile> ltl_invariant I \<rbrakk>
     \<Longrightarrow> (ts, n) \<tturnstile> \<box>\<diamond>P"
  apply (simp add: loop_simple)
  apply (rule ltl_globallyI)
  apply (rule ltl_sdrop[where j=0, simplified])
  apply (erule_tac I=I in zloopE, clarsimp)
   apply (erule_tac x=xs in meta_allE)
   apply (erule_tac x=sa in meta_allE)
   apply (drule (1) meta_mp)+
   apply (case_tac "xs = []")
    apply clarsimp
   apply (clarsimp simp: ltlf_opt_def finally_globally_atom)
   apply (subst (asm) finally_globally_atom; fastforce)
  apply (erule meta_allE, erule meta_allE, drule (1) meta_mp, drule (1) meta_mp)
  apply (rule bcoversE'[OF bcovers_finally(3)]; simp?)
    apply (rule bcovers_False)
   apply (clarsimp simp: plist_defs, simp)
  apply simp
  done

lemma loop_measure:
  fixes mf :: "'s measure"
  assumes mono: "\<And>ts s. \<lbrakk> ts \<in> runList f s; I s \<rbrakk>
                           \<Longrightarrow> (ts,0) \<turnstile> \<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')"
  and progress: "\<And>ts s. \<lbrakk> ts \<in> runList f s; I s \<rbrakk>
                          \<Longrightarrow> (ts,0) \<turnstile> \<diamond>\<A>(\<lambda>(s,a,s'). measure_progress mf s s')"
  and invariant: "\<And>ts s. \<lbrakk> ts \<in> runList f s; I s \<rbrakk>
                           \<Longrightarrow> (ts,0) \<turnstile> ltl_invariant I"
  and measurable: "measurable mf s"
  and no_div: "no_div \<top> f"
  and non_null: "non_null \<top> f"
  and ts: "ts \<in> runStream (loop f) s"
  and init: "I s"
  shows "(ts,0) \<tturnstile> \<box>\<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
proof -
  have m: "(ts,0) \<tturnstile> \<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')"
    by (fastforce elim: mono invariant
                 intro: loop_g[where I=I, OF ts no_div non_null init] bcovers_atom)
  have p: "(ts,0) \<tturnstile> \<box>\<diamond>\<A>(\<lambda>(s,a,s'). measure_progress mf s s')"
    by (fastforce elim: loop_f[where I=I, OF _ no_div non_null] progress invariant
                 intro: loop_gf[where I=I, OF ts no_div non_null init] bcovers_atom)
  show ?thesis
    apply (insert measurable ts)
    apply (rule measure_ltl[OF m p])
     apply (drule zshd_runStream)
     apply (clarsimp simp: runStream_def split: tmres.splits)
     apply (case_tac ts; clarsimp simp: ltl_semantics)
    apply (clarsimp simp: runStream_def)
    apply (case_tac x; clarsimp simp: zstream_sconnected)
    done
qed

lemma validL_loop_measure:
  fixes mf :: "'s measure"
  assumes mono: "\<lbrace>P\<rbrace> f \<lbrace>\<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')\<rbrace>\<^sup>*"
  and progress: "\<lbrace>P\<rbrace> f \<lbrace>\<diamond>\<A>(\<lambda>(s,a,s'). measure_progress mf s s')\<rbrace>\<^sup>*"
  and invariant: "f \<lbrace>P\<rbrace>"
  and no_div: "no_div \<top> f"
  and non_null: "non_null \<top> f"
  shows "\<lbrace>P and measurable mf\<rbrace> loop f \<lbrace>\<box>\<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)\<rbrace>\<^sup>\<infinity>"
proof (clarsimp simp: validL_def iff del: not_infinity_eq)
  fix tr s
  assume P: "P s" and tr: "tr \<in> runStream (loop f) s" and d: "measurable mf s"
  have m: "\<And>ts s. \<lbrakk> ts \<in> runList f s; P s\<rbrakk>
                 \<Longrightarrow> (ts, 0) \<turnstile> \<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')"
    using mono use_validl'' by fastforce
  have p: "\<And>ts s. \<lbrakk>ts \<in> runList f s; P s\<rbrakk>
    \<Longrightarrow> (ts, 0) \<turnstile> \<diamond>\<A>(\<lambda>(s,a,s'). measure_progress mf s s')"
    using progress use_validl'' by fastforce
  have i: "\<And>ts s. \<lbrakk>ts \<in> runList f s; P s\<rbrakk> \<Longrightarrow> (ts, 0) \<turnstile> ltl_invariant P"
    using invariant ltl_invariant_def by fastforce
  show "(tr, 0) \<tturnstile> \<box>\<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
    by (rule loop_measure[OF m p i d no_div non_null tr P]; assumption?)
qed

lemma validc_loop_measure:
  fixes mf :: "'s measure"
  assumes mono: "\<lbrace>P\<rbrace> f \<lbrace>\<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')\<rbrace>\<^sup>*"
  and progress: "\<lbrace>P\<rbrace> f \<lbrace>\<diamond>\<A>(\<lambda>(s,a,s'). measure_progress mf s s')\<rbrace>\<^sup>*"
  and invariant: "f \<lbrace>P\<rbrace>"
  and no_div: "no_div \<top> f"
  and non_null: "non_null \<top> f"
  shows "\<lbrace>P and measurable mf\<rbrace> loop f \<lbrace>\<box>\<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)\<rbrace>\<^sup>\<omega>"
  apply (insert validL_loop_measure[OF assms])
  apply (clarsimp simp: validc_def validL_def iff del: not_infinity_eq)
  apply (erule_tac x=s in allE, clarsimp)
  apply (erule runTrace_ltl_semantics)
  by (auto simp: assms)

end
