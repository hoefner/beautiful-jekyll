(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Setup
imports
  LTL.LTL_Toplevel
  Monads.WPSimp
begin

(* Nothing to do here *)

end