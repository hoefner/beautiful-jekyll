(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Toplevel
imports
  VCG_RG
  VCG_Loop
begin

(* Nothing to do *)

end
