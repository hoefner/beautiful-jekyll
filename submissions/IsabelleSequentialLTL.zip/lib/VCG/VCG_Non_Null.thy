(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Non_Null
imports VCG_Valid
begin

definition non_null :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> bool" where
  "non_null P f = (\<forall>s. P s \<longrightarrow> (\<forall>rv. Result [] rv \<notin> f s))"

lemma non_null_pre[wp_pre]:
  "\<lbrakk> non_null P f; \<And>s. Q s \<Longrightarrow> P s\<rbrakk> \<Longrightarrow> non_null Q f"
  by (auto simp: non_null_def)

lemma wpc_helper_non_null_final:
  "non_null Q f \<Longrightarrow> wpc_helper (P, P', P'') (Q, Q', Q'') (non_null P f)"
  by (clarsimp simp: wpc_helper_def elim!: non_null_pre)

wpc_setup "\<lambda>m. non_null P m" wpc_helper_non_null_final


bundle no_pre = hoare_pre [wp_pre del] non_null_pre [wp_pre del]

bundle classic_wp_pre =
  hoare_pre [wp_pre del]
  all_classic_wp_combs[wp_comb del]
  all_classic_wp_combs[wp_comb]


lemmas non_nullD = non_null_def[THEN iffD1, rule_format]

lemma non_null_bind[wp]:
  "\<lbrakk> non_null P f; \<And>x. non_null (R x) (g x); \<lbrace>Q\<rbrace> f \<lbrace>R\<rbrace> \<rbrakk> \<Longrightarrow> non_null (P or Q) (f >>= (\<lambda>rv. g rv))"
  by (fastforce simp: non_null_def bind_def tappend_def2 valid_def in_mres
               split: tmres.splits)

lemma non_null_False[simp]:
  "non_null (\<lambda>_. False) X"
  by (clarsimp simp: non_null_def)

lemma non_null_get[simp, wp]:
  "non_null \<top> get"
  by (simp add: non_null_def get_def)

lemma non_null_put[simp, wp]:
  "non_null \<top> (put s)"
  by (simp add: non_null_def put_def)

lemma non_null_modify[simp, wp]:
  "non_null \<top> (modify f)"
  by (simp add: non_null_def modify_def)

lemma non_null_return[simp, wp]:
  "non_null \<bottom> (return x)"
  by (simp add: return_def non_null_def)

lemma non_null_fail[simp, wp]:
  "non_null \<top> fail"
  by (simp add: non_null_def fail_def)

lemma non_null_select[simp, wp]:
  "non_null \<bottom> (select S)"
  by (clarsimp simp add: non_null_def select_def)

lemma non_null_gets[simp, wp]:
  "non_null \<top> (gets f)"
  unfolding gets_def
  by (rule non_null_pre) wpsimp+

lemma non_null_assert[simp, wp]:
  "non_null \<bottom> (assert P)"
  by (simp add: assert_def)

lemma non_null_case_option[wp]:
  assumes f: "non_null P f"
  assumes g: "\<And>x. non_null (Q x) (g x)"
  shows "non_null (if x = None then P else Q (the x)) (case_option f g x)"
  by (clarsimp simp add: f g)

lemma non_null_assert_opt[simp, wp]:
  "non_null \<bottom> (assert_opt P)"
  by (simp add: assert_opt_def split: option.splits)

lemma non_null_alt[wp]:
  "\<lbrakk> non_null P f; non_null Q g \<rbrakk> \<Longrightarrow> non_null (P and Q) (f \<^bold>+ g)"
  by (auto simp: non_null_def choice_def)

lemma non_null_when[wp]:
  "(P \<Longrightarrow> non_null Q f) \<Longrightarrow> non_null (if P then Q else \<bottom>) (when P f)"
  by (simp add: when_def)

lemma non_null_unless[wp]:
  "(\<not>P \<Longrightarrow> non_null Q f) \<Longrightarrow> non_null (if P then \<bottom> else Q) (unless P f)"
  by (simp add: unless_def when_def)

lemma non_null_if[wp]:
  "\<lbrakk> P \<Longrightarrow> non_null Q f; \<not>P \<Longrightarrow> non_null R g \<rbrakk> \<Longrightarrow> non_null (if P then Q else R) (if P then f else g)"
  by simp

lemma non_null_apply[wp]:
  "non_null P (f (g x)) \<Longrightarrow> non_null P (f $ g x)"
  by simp

lemma non_null_liftM[wp]:
  "non_null P m \<Longrightarrow> non_null P (liftM f m)"
  unfolding liftM_def
  by wpsimp

lemma non_null_undefined[simp, wp]:
  "non_null \<bottom> undefined"
  by (simp add: non_null_def)

lemma non_null_assume_pre:
  "(\<And>s. P s \<Longrightarrow> non_null P f) \<Longrightarrow> non_null P f"
  by (simp add: non_null_def)

lemma non_null_pre_and:
  "non_null P f \<Longrightarrow> non_null (P and Q) f"
  by (erule non_null_pre) simp

lemma non_null_spec:
  "\<lbrakk> \<And>s. non_null (((=) s) and P) f \<rbrakk> \<Longrightarrow> non_null P f"
  by (simp add: non_null_def)

lemma non_null_spec_pre:
  "\<lbrakk> non_null (((=) s) and P') f; \<And>s. P s \<Longrightarrow> P' s \<rbrakk> \<Longrightarrow> non_null (((=) s) and P) f"
  by (erule non_null_pre, simp)

lemma non_null_or:
  "\<lbrakk>non_null P a; non_null Q a\<rbrakk> \<Longrightarrow> non_null (P or Q) a"
  by (clarsimp simp: non_null_def)

lemma non_null_condition[wp]:
  "\<lbrakk>non_null Q A; non_null R B\<rbrakk> \<Longrightarrow> non_null (\<lambda>s. (C s \<longrightarrow> Q s) \<and> (\<not> C s \<longrightarrow> R s)) (condition C A B)"
  unfolding condition_def non_null_def
  by clarsimp

lemma non_null_ex_lift:
  "(\<And>x. non_null (P x) f) \<Longrightarrow> non_null (\<lambda>s. \<exists>x. P x s) f"
  by (fastforce simp: non_null_def)

lemma non_null_grab_asm:
  "(G \<Longrightarrow> non_null P f) \<Longrightarrow> non_null (\<lambda>s. G \<and> P s) f"
  by (cases G; clarsimp)

lemma non_null_parallel[wp]:
  "\<lbrakk> non_null P f \<or> non_null Q g \<rbrakk> \<Longrightarrow> non_null (P and Q) (parallel f g)"
  by (auto simp: non_null_def parallel_def)

declare non_null_False[simp del]

lemma non_nullD':
  "\<lbrakk> non_null P f; P s; Result ts rv \<in> f s \<rbrakk>
     \<Longrightarrow> ts \<noteq> []"
  by (meson non_nullD)

end
