(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Validl2
  imports
    VCG_More_Valid
    VCG_Crunch
begin

lemma validl2_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by (fastforce simp: validl2_def)

lemmas validl2_weaken_pre[wp_pre] = validl2_pre_imp[rotated]


lemma use_validl2:
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>; P s; Result ts rv \<in> f s; (zlist ts s, 0) \<turnstile> F \<rbrakk>
     \<Longrightarrow> Q rv (last_st ts s) \<and> (zlist ts s, 0) \<turnstile> G"
  by (simp add: validl2_def zlist_tmres)

lemma use_validl2':
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>; P s \<rbrakk>
     \<Longrightarrow> \<forall>ts rv. Result ts rv \<in> f s \<and> (zlist ts s, 0) \<turnstile> F
                 \<longrightarrow> Q rv (last_st ts s) \<and> (zlist ts s, 0) \<turnstile> G"
  by (auto simp: validl2_def zlist_tmres)

lemma use_validl2'':
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>; ts \<in> runList f s; P s; (ts, 0) \<turnstile> F \<rbrakk> \<Longrightarrow> (ts, 0) \<turnstile> G"
  by (auto simp: validl2_def dest: runList_tmres)


lemma validl2_split_contextL:
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>\<top>\<top>\<rbrace>,\<lbrace>G\<rbrace>; \<lbrace>P'\<rbrace>,\<lbrace>F \<and>\<^sub>l G\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>True\<^sub>l\<rbrace> \<rbrakk>
  \<Longrightarrow> \<lbrace>P and P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by (fastforce simp: validl2_def ltl_semantics)

lemma validl2_split':
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>\<top>\<top>\<rbrace>,\<lbrace>G\<rbrace>; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>True\<^sub>l\<rbrace> \<rbrakk>
  \<Longrightarrow> \<lbrace>P and P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by (fastforce simp: validl2_def ltl_semantics)

lemma validl2_split:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>\<top>\<top>\<rbrace>,\<lbrace>G\<rbrace> \<rbrakk>
  \<Longrightarrow> \<lbrace>P and P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  apply (clarsimp simp: validl2_def valid_def ltl_semantics)
  by (metis case_prodD in_mres)

lemma validl2_K_bind:
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>
   \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> K_bind f x \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by simp

lemma validl2_skipL:
 "\<lbrakk> no_trace \<top> f; \<And>rv. \<lbrace>Q' rv\<rbrace>,\<lbrace>F\<rbrace> g rv \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>; \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace> \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f >>= g \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  apply (clarsimp simp: validl2_def split_def bind_def2)
  apply (case_tac x; clarsimp)
  apply (drule (1) use_valid')
  apply (drule bspec)
   apply (force simp: mres_def image_iff split: if_splits)
  apply (fastforce dest: no_traceD)
  done

lemma validl2_skipR:
  "\<lbrakk> \<And>rv. no_trace \<top> (g rv); \<And>rv. \<lbrace>Q' rv\<rbrace> g rv \<lbrace>Q\<rbrace>; \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q'\<rbrace>,\<lbrace>G\<rbrace> \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f >>= g \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  apply (subst validl2_def)
  apply (clarsimp simp: split_def bind_def)
  apply (case_tac x; clarsimp)
  apply (case_tac xa; clarsimp)
  apply (rename_tac rv' ts rv ts')
  apply (erule_tac x=rv in meta_allE)
  apply (drule no_traceD, simp+)
   apply (clarsimp simp: mres_def image_iff split: if_splits)
  apply (erule_tac x=rv in meta_allE)
  apply (drule (3) use_validl2)
  apply (fastforce dest: in_mres use_valid')
  done

lemma bindE:
  "\<lbrakk> Result ts rv \<in> (f >>= g) s;
     \<And>ru us vs. \<lbrakk> ts = us @ vs; Result us ru \<in> f s; Result vs rv \<in> g ru (last_st us s) \<rbrakk> \<Longrightarrow> R \<rbrakk>
   \<Longrightarrow> R"
  apply (clarsimp simp: bind_def)
  apply (case_tac x; clarsimp)
  apply (case_tac xa; clarsimp)
  done

lemma ltlf_pcoversE:
  "\<lbrakk> fs pcovers\<^sup>* F; (xs@ys,0) \<turnstile> F;
     \<And>L R. \<lbrakk> (L,R) \<in> set fs; (xs,0) \<turnstile> L; (ys,0) \<turnstile> R \<rbrakk> \<Longrightarrow> P \<rbrakk>
     \<Longrightarrow> P"
  apply (erule_tac xs="llist_of xs" and ys="llist_of ys" in LTL_Cover_Finite.pcoversE)
  by (simp add: lappend_llist_of_llist_of ltlf_from)+

lemma ltlf_bcoversE:
  "\<lbrakk> fs bcovers\<^sup>* F; (L,R) \<in> set fs; (xs,0) \<turnstile> L; (ys,0) \<turnstile> R; (xs@ys,0) \<turnstile> F \<Longrightarrow> P \<rbrakk>
     \<Longrightarrow> P"
  apply (erule_tac xs="llist_of xs" and ys="llist_of ys" in LTL_Cover_Finite.bcoversE)
  by (simp add: lappend_llist_of_llist_of ltlf_from)+


definition validl2_bind
 where
  "validl2_bind P fs f g Q gs \<equiv>
     \<forall>s. P s \<longrightarrow> (\<forall>xs ys rv rv'. Result xs rv \<in> f s \<and> Result ys rv' \<in> g rv (last_st xs s)
               \<longrightarrow> (\<forall>(L,R) \<in> set fs. (zlist xs s, 0) \<turnstile> L \<and> (zlist ys (last_st xs s), 0) \<turnstile> R
                    \<longrightarrow> Q rv' (last_st (xs @ ys) s) \<and> (\<exists>(L',R')\<in>set gs. (zlist xs s, 0) \<turnstile> L' \<and> (zlist ys (last_st xs s), 0) \<turnstile> R')))"

(* Introduce bind format for splitting *)
lemma validl2_bindI:
  "\<lbrakk> fs pcovers\<^sup>* F; gs bcovers\<^sup>* G; validl2_bind P fs f g Q gs \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f >>= g \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  supply last_st_append[simp del]
  apply (unfold validl2_def validl2_bind_def)
  apply (erule all_forward, erule (1) imp_forward, clarsimp)
  apply (erule bindE, clarsimp simp: zlist_append)
  apply (elim allE, drule mp, fastforce)
  apply (erule (1) ltlf_pcoversE, drule (1) bspec, clarsimp)
  apply (erule (4) ltlf_bcoversE)
  done

(* Split bind format *)
lemma validl2_bind_split_asm:
  "\<lbrakk> validl2_bind P [x] f g Q gs; validl2_bind P' (x'#xs) f g Q gs \<rbrakk>
     \<Longrightarrow> validl2_bind (P and P') (x#x'#xs) f g Q gs"
  by (auto simp: validl2_bind_def)

(* Split bind format *)
lemma validl2_bind_split_ccl:
  "\<lbrakk> validl2_bind P fs f g Q [y]; validl2_bind P' fs f g Q (y'#ys) \<rbrakk>
     \<Longrightarrow> validl2_bind (P or P') fs f g Q (y#y'#ys)"
  by (auto simp: validl2_bind_def split_def)

(* Go back up to validl2 format *)
lemma validl_validl2_bind:
  "\<lbrakk> \<And>rv. \<lbrace>P' rv\<rbrace>,\<lbrace>R\<rbrace> g rv \<lbrace>Q\<rbrace>,\<lbrace>R'\<rbrace>; \<lbrace>P\<rbrace>,\<lbrace>L\<rbrace> f \<lbrace>P'\<rbrace>,\<lbrace>L'\<rbrace> \<rbrakk>
     \<Longrightarrow> validl2_bind P [(L,R)] f g Q [(L',R')]"
  apply (clarsimp simp: validl2_bind_def)
  apply (subst (asm) validl2_def) back
  apply (erule allE, drule (1) mp)
  apply (elim allE, drule mp, fastforce, clarsimp)
  apply (subst (asm) validl2_def)
  apply (erule_tac x=rv in meta_allE)
  apply (erule allE, drule (1) mp)
  apply (elim allE, drule mp, fastforce)
  apply clarsimp
  done

lemma validl2_vcg_if_split:
  "\<lbrakk> P \<Longrightarrow> \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>; \<not>P \<Longrightarrow> \<lbrace>P''\<rbrace>,\<lbrace>F\<rbrace> g \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace> \<rbrakk>
     \<Longrightarrow> \<lbrace>\<lambda>s. (P \<longrightarrow> P' s) \<and> (\<not>P \<longrightarrow> P'' s)\<rbrace>,\<lbrace>F\<rbrace> if P then f else g \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by simp

method ltl_wp_post =
   (((rule validl2_bind_split_asm)+)?; ((rule validl2_bind_split_ccl)+)?; rule validl_validl2_bind; (rule validl2_K_bind)?)

method ltl_wp =
  (rule validl2_bindI validl2_validf[OF validl2_bindI], solves ptac, solves ptac, ltl_wp_post)

method ltl_wpl =
  (rule validl2_bindI validl2_validf[OF validl2_bindI], solves ptac, solves ptacL, ltl_wp_post)

method ltl_wpr =
  (rule validl2_bindI validl2_validf[OF validl2_bindI], solves ptac, solves ptacR, ltl_wp_post)

end