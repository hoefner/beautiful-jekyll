(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_LTL
imports VCG_Setup
begin

definition validl ::
  "('s \<Rightarrow> bool) \<Rightarrow> 's zstep ltl \<Rightarrow> ('s,'a) tmonad \<Rightarrow> 's zstep ltl \<Rightarrow> bool"
  ("(\<lbrace>_\<rbrace>,/ \<lbrace>_\<rbrace>)/ _ /(\<lbrace>_\<rbrace>\<^sup>\<omega>)") where
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>\<omega> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>ts \<in> runTrace f s. (ts, 0) \<Turnstile> F \<longrightarrow> (ts, 0) \<Turnstile> G)"

(* FIXME ryanb: change naming *)
definition valids ::
  "('s \<Rightarrow> bool) \<Rightarrow> 's zstep ltl \<Rightarrow> ('s,'a) tmonad \<Rightarrow> 's zstep ltl \<Rightarrow> bool"
  ("(\<lbrace>_\<rbrace>,/ \<lbrace>_\<rbrace>)/ _ /(\<lbrace>_\<rbrace>\<^sup>\<infinity>)") where
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>\<infinity> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>ts \<in> runStream f s. (ts, 0) \<tturnstile> F \<longrightarrow> (ts, 0) \<tturnstile> G)"

(* Finite variation *)
definition validf ::
  "('s \<Rightarrow> bool) \<Rightarrow> 's zstep ltl \<Rightarrow> ('s,'a) tmonad \<Rightarrow> 's zstep ltl \<Rightarrow> bool"
  ("(\<lbrace>_\<rbrace>,/ \<lbrace>_\<rbrace>)/ _ /(\<lbrace>_\<rbrace>\<^sup>*)") where
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>* \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>ts \<in> runList f s. (ts, 0) \<turnstile> F \<longrightarrow> (ts, 0) \<turnstile> G)"


lemmas validfI = iffD2[OF meta_eq_to_obj_eq[OF validf_def], OF allI, OF impI, OF ballI, OF impI]
lemmas validfD = mp[OF bspec[OF mp[OF spec[OF iffD1[OF meta_eq_to_obj_eq[OF validf_def]]]]]]

definition valid2 ::
  "('s \<Rightarrow> bool) \<Rightarrow> 's zstep ltl \<Rightarrow> ('s,'a) tmonad \<Rightarrow> ('a \<Rightarrow> 's \<Rightarrow> bool) \<Rightarrow> bool"
  ("(\<lbrace>_\<rbrace>,/ \<lbrace>_\<rbrace>)/ _ /(\<lbrace>_\<rbrace>)") where
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>ts rv. Result ts rv \<in> f s
                                        \<longrightarrow> (zlist ts s, 0) \<turnstile> F
                                        \<longrightarrow> Q rv (last_st ts s))"

lemmas valid2I = iffD2[OF meta_eq_to_obj_eq[OF valid2_def], OF allI, OF impI, OF allI, OF allI, OF impI, OF impI]
lemmas valid2D = mp[OF mp[OF spec[OF spec[OF mp[OF spec[OF iffD1[OF meta_eq_to_obj_eq[OF valid2_def]]]]]]]]


definition validl2 ("(\<lbrace>_\<rbrace>,/ \<lbrace>_\<rbrace>)/ _ /(\<lbrace>_\<rbrace>,/ \<lbrace>_\<rbrace>)") where validl2_def2:
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace> \<equiv> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace> \<and> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>*"

lemma validl2_def:
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>ts rv. Result ts rv \<in> f s \<longrightarrow> (zlist ts s, 0) \<turnstile> F \<longrightarrow> Q rv (last_st ts s) \<and> (zlist ts s, 0) \<turnstile> G)"
  apply (rule eq_reflection)
  apply (auto simp: validf_def validl2_def2 valid2_def zlist_tmres elim: runList_cases)
  done

lemmas validl2I' = iffD2[OF meta_eq_to_obj_eq[OF validl2_def2], OF conjI]
lemmas validl2I = iffD2[OF meta_eq_to_obj_eq[OF validl2_def], OF allI, OF impI, OF allI, OF allI, OF impI, OF impI]
lemmas validl2D = mp[OF mp[OF spec[OF spec[OF mp[OF spec[OF iffD1[OF meta_eq_to_obj_eq[OF validl2_def]]]]]]]]

definition valid ::
  "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> ('a \<Rightarrow> 's \<Rightarrow> bool) \<Rightarrow> bool"
  ("\<lbrace>_\<rbrace>/ _ /\<lbrace>_\<rbrace>") where valid_def2:
  "\<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace> \<equiv> \<lbrace>P\<rbrace>,\<lbrace>True\<^sub>l\<rbrace> f \<lbrace>Q\<rbrace>"

lemmas valid_valid2 = iffD1[OF meta_eq_to_obj_eq[OF valid_def2]]
lemmas valid2_valid = iffD2[OF meta_eq_to_obj_eq[OF valid_def2]]

lemma valid_def:
  "\<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace> \<equiv> \<forall>s. P s \<longrightarrow> (\<forall>(r,s') \<in> mres f s. Q r s')"
  apply (rule eq_reflection)
  apply (auto simp: valid_def2 valid2_def mres_def)
  done

lemma runTrace_runStream:
  "\<lbrakk> ts \<in> runTrace f s; \<not> lfinite ts \<rbrakk>
    \<Longrightarrow> stream_of_llist ts \<in> runStream f s"
  apply (clarsimp simp: runTrace_def)
  apply (case_tac x; clarsimp)
  apply (metis lfinite_llist_of stream.Rep_inverse zstream_tmres ztrace_zlist ztrace_zstream)
  by (simp add: ztrace_zlist)

(* Equivalence to regular variant *)
lemma valids_validl:
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>\<infinity> = \<lbrace>P\<rbrace>,\<lbrace>infinite\<^sub>l \<and>\<^sub>l F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>\<omega>"
  apply (clarsimp simp: valids_def validl_def)
  apply (rule iffI; erule all_forward; clarsimp simp: ltl_semantics)
   apply (metis llist_of_stream_stream_of_llist ltli_from runTrace_runStream)
  apply (meson lfinite_llist_of_stream ltli_from runStream_runTrace)
  done

(* FIXME ryanb: update naming etc. wrt. current hierarchy *)
abbreviation validf1 ::
  "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> 's zstep ltl \<Rightarrow> bool"
  ("\<lbrace>_\<rbrace>/ _ /\<lbrace>_\<rbrace>\<^sup>*") where
  "\<lbrace>P\<rbrace> f \<lbrace>F\<rbrace>\<^sup>* \<equiv> \<lbrace>P\<rbrace>,\<lbrace>True\<^sub>l\<rbrace> f \<lbrace>\<lambda>_ _. True\<rbrace>,\<lbrace>F\<rbrace>"

lemmas validf1_def = validl2_def

lemma validl_def2:
  "\<lbrace>P\<rbrace> f \<lbrace>F\<rbrace>\<^sup>* = (\<forall>s. P s \<longrightarrow> (\<forall>tr \<in> runList f s. (tr,0) \<turnstile> F))"
  unfolding validf1_def
  by (auto dest: zlist_tmres elim!: runList_cases)


lemma validl_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (fastforce simp: validl_def2)

lemmas validl_weaken_pre[wp_pre] = validl_pre_imp[rotated]


lemma wpc_helper_validl:
  "\<lbrace>Q\<rbrace> g \<lbrace>F\<rbrace>\<^sup>* \<Longrightarrow> wpc_helper (P, P', P'') (Q, Q', Q'') \<lbrace>P\<rbrace> g \<lbrace>F\<rbrace>\<^sup>*"
  by (clarsimp simp: wpc_helper_def elim!: validl_weaken_pre)

wpc_setup "\<lambda>m. \<lbrace>P\<rbrace> m \<lbrace>F\<rbrace>\<^sup>*" wpc_helper_validl

lemma use_validl:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>\<phi>\<rbrace>\<^sup>*; P s; Result ts rv \<in> f s \<rbrakk> \<Longrightarrow> (zlist ts s, 0) \<turnstile> \<phi>"
  by (simp add: validl_def2 zlist_tmres)

lemma use_validl':
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>\<phi>\<rbrace>\<^sup>*; P s \<rbrakk> \<Longrightarrow> \<forall>ts rv. Result ts rv \<in> f s \<longrightarrow> (zlist ts s, 0) \<turnstile> \<phi>"
  by (simp add: validl_def2 zlist_tmres)

lemma use_validl'':
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>\<phi>\<rbrace>\<^sup>*; ts \<in> runList f s; P s \<rbrakk> \<Longrightarrow> (ts, 0) \<turnstile> \<phi>"
  by (simp add: validl_def2 zlist_tmres)


lemma validl_TrueI:
  "\<lbrace>P\<rbrace> f \<lbrace>True\<^sub>l\<rbrace>\<^sup>*"
  by (simp add: validl_def2)

lemmas validl_post_taut = validl_TrueI[where P=\<top>]

lemma validl_post_conj[intro]:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q \<and>\<^sub>l Q'\<rbrace>\<^sup>*"
  by (fastforce simp: validl_def2 ltl_semantics)

lemma validl_pre_disj[intro]:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P or P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (simp add: validl_def2)

lemma validl_conj:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P'\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P and P'\<rbrace> f \<lbrace>Q \<and>\<^sub>l Q'\<rbrace>\<^sup>*"
  unfolding validl_def2 by (auto simp: ltl_semantics)

lemma validl_False[simp]:
  "\<lbrace>\<bottom>\<rbrace> f \<lbrace>P\<rbrace>\<^sup>*"
  by (simp add: validl_def2)

lemma validl_if:
  "\<lbrakk> P' \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<not> P' \<Longrightarrow> \<lbrace>P\<rbrace> g \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> if P' then f else g \<lbrace>Q\<rbrace>\<^sup>*"
  by simp

lemma validl_pre_subst:
  "\<lbrakk> P = P'; \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (erule subst)

lemma validl_post_subst:
  "\<lbrakk> Q = Q'; \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>*"
  by (erule subst)

lemma validl_post_imp:
  "\<lbrakk> \<And>ts i. (ts, i) \<turnstile> Q' \<Longrightarrow> (ts, i) \<turnstile> Q; \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (auto simp: validl_def2 split_def)

lemmas validl_strengthen_post = validl_post_imp[rotated]

lemmas post_by_validl = use_validl[rotated]


lemma validl_gen_asm:
  "(P \<Longrightarrow> \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*) \<Longrightarrow> \<lbrace>P' and K P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (fastforce simp add: validl_def2)

lemmas validl_gen_asm_single = validl_gen_asm[where P'="\<top>", simplified pred_conj_def simp_thms]

lemma validl_gen_asm_lk:
  "(P \<Longrightarrow> \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*) \<Longrightarrow> \<lbrace>K P and P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (fastforce simp add: validl_def2)

lemma validl_gen_asm_spec':
  "\<lbrakk> \<And>s. P s \<Longrightarrow> S \<and> P' s; S \<Longrightarrow> \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (fastforce simp: validl_def2)

lemma validl_gen_asm_spec:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> S; S \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (rule validl_gen_asm_spec'[where S=S and P'=P]) simp

lemma validl_conjI:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q \<and>\<^sub>l Q'\<rbrace>\<^sup>*"
  unfolding validl_def2 by (auto simp: ltl_semantics)

lemma validl_disjI1:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q \<or>\<^sub>l Q' \<rbrace>\<^sup>*"
  unfolding validl_def2 by (auto simp: ltl_semantics)

lemma validl_disjI2:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q \<or>\<^sub>l Q' \<rbrace>\<^sup>*"
  unfolding validl_def2 by (auto simp: ltl_semantics)

lemma validl_assume_pre:
  "(\<And>s. P s \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*) \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (auto simp: validl_def2)


lemma validl_vcg_if_split:
  "\<lbrakk> P \<Longrightarrow> \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<not>P \<Longrightarrow> \<lbrace>P''\<rbrace> g \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk>
     \<Longrightarrow> \<lbrace>\<lambda>s. (P \<longrightarrow> P' s) \<and> (\<not>P \<longrightarrow> P'' s)\<rbrace> if P then f else g \<lbrace>Q\<rbrace>\<^sup>*"
  by simp

lemma validl_vcg_split_case_option:
  "\<lbrakk> \<And>x. x = None \<Longrightarrow> \<lbrace>P x\<rbrace> f x \<lbrace>Q x\<rbrace>\<^sup>*; \<And>x y. x = Some y \<Longrightarrow> \<lbrace>P' x y\<rbrace> g x y \<lbrace>Q x\<rbrace>\<^sup>* \<rbrakk>
   \<Longrightarrow> \<lbrace>\<lambda>s. (x = None \<longrightarrow> P x s) \<and> (\<forall>y. x = Some y \<longrightarrow> P' x y s)\<rbrace>
       case x of None \<Rightarrow> f x | Some y \<Rightarrow> g x y
       \<lbrace>Q x\<rbrace>\<^sup>*"
  by (cases x; simp)

lemma validl_vcg_split_case_sum:
  "\<lbrakk> \<And>x a. x = Inl a \<Longrightarrow> \<lbrace>P x a\<rbrace> f x a \<lbrace>Q x\<rbrace>\<^sup>*; \<And>x b. x = Inr b \<Longrightarrow> \<lbrace>P' x b\<rbrace> g x b \<lbrace>Q x\<rbrace>\<^sup>* \<rbrakk>
   \<Longrightarrow> \<lbrace>\<lambda>s. (\<forall>a. x = Inl a \<longrightarrow> P x a s) \<and> (\<forall>b. x = Inr b \<longrightarrow> P' x b s)\<rbrace>
       case x of Inl a \<Rightarrow> f x a | Inr b \<Rightarrow> g x b
       \<lbrace>Q x\<rbrace>\<^sup>*"
  by (cases x; simp)

lemma validl_vcg_conj_lift:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P'\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. P s \<and> P' s\<rbrace> f \<lbrace>Q \<and>\<^sub>l Q'\<rbrace>\<^sup>*"
  unfolding validl_def2 by (auto simp: ltl_semantics)

lemma validl_vcg_disj_lift:
  "\<lbrakk> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P'\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. P s \<or> P' s\<rbrace> f \<lbrace>Q \<or>\<^sub>l Q'\<rbrace>\<^sup>*"
  unfolding validl_def2 by (auto simp: ltl_semantics)

lemma validl_vcg_imp_lift:
  "\<lbrakk> \<lbrace>P'\<rbrace> f \<lbrace>\<not>\<^sub>l P\<rbrace>\<^sup>*; \<lbrace>Q'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. \<not> P' s \<longrightarrow> Q' s\<rbrace> f \<lbrace>P \<longrightarrow>\<^sub>l Q\<rbrace>\<^sup>*"
  by (simp add: ltl_imp_conv_disj imp_conv_disj validl_vcg_disj_lift)

lemma validl_vcg_imp_lift':
  "\<lbrakk> \<lbrace>P'\<rbrace> f \<lbrace>\<not>\<^sub>l P\<rbrace>\<^sup>*; \<lbrace>Q'\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. P' s \<or> Q' s\<rbrace> f \<lbrace>P \<longrightarrow>\<^sub>l Q\<rbrace>\<^sup>*"
  by (wpsimp wp: validl_vcg_imp_lift)

lemma validl_K_bind[wp_split]:
  "\<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<Longrightarrow> \<lbrace>P\<rbrace> K_bind f x \<lbrace>Q\<rbrace>\<^sup>*"
  by simp

(* for instantiations *)
lemma validl_triv:    "\<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*" .


lemma hoare_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace> f \<lbrace>Q\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace>"
  by (fastforce simp: valid_def)

lemma valid2_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>"
  by (fastforce simp: valid2_def)

lemma validf_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*"
  by (fastforce simp: validf_def)

lemma validl2_pre_imp:
  "\<lbrakk> \<And>s. P s \<Longrightarrow> P' s; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by (fastforce simp: validl2_def)

lemmas hoare_weaken_pre = hoare_pre_imp[rotated]
lemmas valid2_weaken_pre[wp_pre] = valid2_pre_imp[rotated]
lemmas validf_weaken_pre[wp_pre] = validf_pre_imp[rotated]
lemmas validl2_weaken_pre[wp_pre] = validl2_pre_imp[rotated]

lemmas hoare_pre [wp_pre] =
  hoare_weaken_pre
  valid2_weaken_pre
  validf_weaken_pre
  validl2_weaken_pre

lemma valid2_post_taut[wp]:
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>\<lambda>_ _. True\<rbrace>"
  by (rule valid2I, simp)

lemma validf_post_taut[wp]:
  "\<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>True\<^sub>l\<rbrace>\<^sup>*"
  by (rule validfI, simp)

lemma valid2_asm_imp:
  "\<lbrakk> F \<Longrightarrow>\<^sub>l F'; \<lbrace>P\<rbrace>,\<lbrace>F'\<rbrace> f \<lbrace>Q\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>"
  apply (rule valid2I)
  apply (erule (2) valid2D)
  using ltlf_from by blast

lemmas valid2_weaken_asm = valid2_asm_imp[rotated]

lemma validl2_asm_imp:
  "\<lbrakk> F \<Longrightarrow>\<^sub>l F'; \<lbrace>P\<rbrace>,\<lbrace>F'\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  apply (rule validl2I)
  apply (erule (2) validl2D)
  using ltlf_from by blast

lemmas validl2_weaken_asm = validl2_asm_imp[rotated]

lemma validl2_conj_elim:
  "\<lbrakk> \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>G\<rbrace>\<^sup>*; \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace> \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. P s \<and> P' s\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>,\<lbrace>G\<rbrace>"
  by (auto intro: validl2I' elim: valid2_weaken_pre validf_weaken_pre)

lemmas validf_validl2 = iffD2[OF meta_eq_to_obj_eq[OF validl2_def2], OF conjI, OF valid2_post_taut]
lemmas validl2_validf = iffD1[OF meta_eq_to_obj_eq[OF validl2_def2[where Q="\<top>\<top>"]], simplified valid2_post_taut simp_thms]

end
