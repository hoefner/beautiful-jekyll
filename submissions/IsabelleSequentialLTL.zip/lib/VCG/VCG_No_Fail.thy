(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_No_Fail
imports VCG_Valid
begin

definition failed :: "(('s, 'a) tmres) set \<Rightarrow> bool" where
  "failed r \<equiv> Failed \<in> r"

definition no_fail :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> bool" where
  "no_fail P m \<equiv> \<forall>s. P s \<longrightarrow> \<not> failed (m s)"

lemma failed_simps[simp]:
  "failed {x} = (x = Failed)"
  "failed (r \<union> r') = (failed r \<or> failed r')"
  "\<not> failed {}"
  by (auto simp: failed_def)

lemma no_fail_pre[wp_pre]:
  "\<lbrakk> no_fail P f; \<And>s. Q s \<Longrightarrow> P s\<rbrakk> \<Longrightarrow> no_fail Q f"
  by (simp add: no_fail_def)

lemma wpc_helper_no_fail_final:
  "no_fail Q f \<Longrightarrow> wpc_helper (P, P', P'') (Q, Q', Q'') (no_fail P f)"
  by (clarsimp simp: wpc_helper_def elim!: no_fail_pre)

wpc_setup "\<lambda>m. no_fail P m" wpc_helper_no_fail_final


bundle no_pre = hoare_pre [wp_pre del] no_fail_pre [wp_pre del]

bundle classic_wp_pre =
  hoare_pre [wp_pre del]
  all_classic_wp_combs[wp_comb del]
  all_classic_wp_combs[wp_comb]


lemma no_failD:
  "\<lbrakk> no_fail P m; P s \<rbrakk> \<Longrightarrow> \<not> failed (m s)"
  by (simp add: no_fail_def)

lemma no_fail_return[simp, wp]:
  "no_fail \<top> (return x)"
  by (simp add: return_def no_fail_def)

lemma no_fail_bind[wp]:
  "\<lbrakk> no_fail P f; \<And>x. no_fail (R x) (g x); \<lbrace>Q\<rbrace> f \<lbrace>R\<rbrace> \<rbrakk>
     \<Longrightarrow> no_fail (P and Q) (f >>= (\<lambda>rv. g rv))"
  apply (clarsimp simp: no_fail_def bind_def2 image_Un image_image
                        in_image_constant failed_def)
  apply (clarsimp split: tmres.splits)
  apply (drule (1) post_by_hoare, erule in_mres, fastforce)
  apply (clarsimp simp: tappend_def2 split: tmres.splits)
  done

lemma no_fail_get[simp, wp]:
  "no_fail \<top> get"
  by (simp add: get_def no_fail_def)

lemma no_fail_put[simp, wp]:
  "no_fail \<top> (put s)"
  by (simp add: put_def no_fail_def)

lemma no_fail_modify[wp,simp]:
  "no_fail \<top> (modify f)"
  by (simp add: modify_def no_fail_def)

lemma no_fail_gets_simp[simp]:
  "no_fail P (gets f)"
  by (wpsimp simp: gets_def)

lemma no_fail_gets[wp]:
  "no_fail \<top> (gets f)"
  by simp

lemma no_fail_select[wp,simp]:
  "no_fail \<top> (select S)"
  by (simp add: no_fail_def select_def image_def failed_def)

lemma no_fail_alt[wp]:
  "\<lbrakk> no_fail P f; no_fail Q g \<rbrakk> \<Longrightarrow> no_fail (P and Q) (f \<^bold>+ g)"
  by (auto simp: no_fail_def choice_def)

lemma no_fail_when[wp]:
  "(P \<Longrightarrow> no_fail Q f) \<Longrightarrow> no_fail (if P then Q else \<top>) (when P f)"
  by (simp add: when_def)

lemma no_fail_unless[wp]:
  "(\<not>P \<Longrightarrow> no_fail Q f) \<Longrightarrow> no_fail (if P then \<top> else Q) (unless P f)"
  by (simp add: unless_def when_def)

lemma no_fail_fail[simp, wp]:
  "no_fail \<bottom> fail"
  by (simp add: fail_def no_fail_def)

lemma no_fail_assert[simp, wp]:
  "no_fail (\<lambda>_. P) (assert P)"
  by (simp add: assert_def)

lemma no_fail_assert_opt[simp, wp]:
  "no_fail (\<lambda>_. P \<noteq> None) (assert_opt P)"
  by (simp add: assert_opt_def split: option.splits)

lemma no_fail_case_option[wp]:
  assumes f: "no_fail P f"
  assumes g: "\<And>x. no_fail (Q x) (g x)"
  shows "no_fail (if x = None then P else Q (the x)) (case_option f g x)"
  by (clarsimp simp add: f g)

lemma no_fail_if[wp]:
  "\<lbrakk> P \<Longrightarrow> no_fail Q f; \<not>P \<Longrightarrow> no_fail R g \<rbrakk> \<Longrightarrow> no_fail (if P then Q else R) (if P then f else g)"
  by simp

lemma no_fail_apply[wp]:
  "no_fail P (f (g x)) \<Longrightarrow> no_fail P (f $ g x)"
  by simp

lemma no_fail_undefined[simp, wp]:
  "no_fail \<bottom> undefined"
  by (simp add: no_fail_def)

lemma no_fail_assume_pre:
  "(\<And>s. P s \<Longrightarrow> no_fail P f) \<Longrightarrow> no_fail P f"
  by (simp add: no_fail_def)

lemma no_fail_liftM[wp]:
  "no_fail P m \<Longrightarrow> no_fail P (liftM f m)"
  unfolding liftM_def
  by wpsimp

lemma no_fail_pre_and:
  "no_fail P f \<Longrightarrow> no_fail (P and Q) f"
  by (erule no_fail_pre) simp

lemma no_fail_spec:
  "\<lbrakk> \<And>s. no_fail (((=) s) and P) f \<rbrakk> \<Longrightarrow> no_fail P f"
  by (simp add: no_fail_def)

lemma no_fail_spec_pre:
  "\<lbrakk> no_fail (((=) s) and P') f; \<And>s. P s \<Longrightarrow> P' s \<rbrakk> \<Longrightarrow> no_fail (((=) s) and P) f"
  by (erule no_fail_pre, simp)

lemma no_fail_gets_the[wp]:
  "no_fail (\<lambda>s. f s \<noteq> None) (gets_the f)"
  unfolding gets_the_def
  by wpsimp

lemma no_fail_False[simp]:
  "no_fail (\<lambda>_. False) X"
  by (clarsimp simp: no_fail_def)

lemma no_fail_gets_map[wp]:
  "no_fail (\<lambda>s. f s p \<noteq> None) (gets_map f p)"
  unfolding gets_map_def by wpsimp

lemma no_fail_or:
  "\<lbrakk>no_fail P a; no_fail Q a\<rbrakk> \<Longrightarrow> no_fail (P or Q) a"
  by (clarsimp simp: no_fail_def)

lemma no_fail_state_assert[wp]:
  "no_fail P (state_assert P)"
  unfolding state_assert_def
  by wpsimp

lemma no_fail_condition[wp]:
  "\<lbrakk>no_fail Q A; no_fail R B\<rbrakk> \<Longrightarrow> no_fail (\<lambda>s. (C s \<longrightarrow> Q s) \<and> (\<not> C s \<longrightarrow> R s)) (condition C A B)"
  unfolding condition_def no_fail_def
  by clarsimp

lemma no_fail_ex_lift:
  "(\<And>x. no_fail (P x) f) \<Longrightarrow> no_fail (\<lambda>s. \<exists>x. P x s) f"
  by (fastforce simp: no_fail_def)

lemma no_fail_grab_asm:
  "(G \<Longrightarrow> no_fail P f) \<Longrightarrow> no_fail (\<lambda>s. G \<and> P s) f"
  by (cases G; clarsimp)

lemma no_fail_put_elem[wp]:
  "no_fail \<top> (put_elem x)"
  by (simp add: put_elem_def no_fail_def)

lemma no_fail_put_list[wp]:
  "no_fail \<top> (put_list xs)"
  by (simp add: put_list_def no_fail_def)

lemma no_fail_put_stream[wp]:
  "no_fail \<top> (put_llist xs)"
  by (simp add: put_llist_def no_fail_def)

lemma no_fail_interference[wp]:
  "no_fail \<top> (interference rv)"
  by (wpsimp simp: interference_def env_steps_def)

lemma no_fail_Await[wp]:
  "\<exists>s. c s \<Longrightarrow> no_fail \<top> (Await c)"
  by (wpsimp simp: Await_def)

lemma parallel_failed:
  "failed (parallel f g s) \<Longrightarrow> failed (f s) \<and> failed (g s)"
  by (auto simp: parallel_def failed_def image_def intro!: bexI)

lemma no_fail_parallel[wp]:
  "\<lbrakk> no_fail P f \<or> no_fail Q g \<rbrakk> \<Longrightarrow> no_fail (P and Q) (parallel f g)"
  by (auto simp: no_fail_def dest!: parallel_failed)

lemma no_fail_env_steps[wp,simp]:
  "no_fail \<top> env_steps"
  by (wpsimp simp: env_steps_def)

end
