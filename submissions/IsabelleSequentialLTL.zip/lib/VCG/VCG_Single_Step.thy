(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Single_Step
  imports
    VCG_No_Trace
    VCG_No_Div
begin

definition single_step :: "('a,'s) tmonad \<Rightarrow> bool" where
  "single_step f = (\<forall>res s. res \<in> f s \<longrightarrow> res = Failed
                    \<or> (\<exists>st. res = Diverged <(Proc,st)>)
                    \<or> (\<exists>rv st. res = Result [(Proc,st)] rv))"

lemmas single_stepD = single_step_def[THEN iffD1, rule_format]

lemma single_step_bindl:
  "\<lbrakk> single_step f; \<And>x. no_trace \<top> (g x) \<rbrakk> \<Longrightarrow> single_step (f >>= (\<lambda>rv. g rv))"
  apply (clarsimp simp: no_trace_def diverged_def no_div_def single_step_def bind_def2 tappend_def2
                 split: tmres.splits)
  apply (case_tac x; clarsimp)
   apply fastforce
  apply (case_tac xa; fastforce)
  done

lemma single_step_bindr:
  "\<lbrakk> no_trace \<top> f; no_div \<top> f; \<And>x. single_step (g x) \<rbrakk> \<Longrightarrow> single_step (f >>= (\<lambda>rv. g rv))"
  apply (clarsimp simp: no_trace_def diverged_def no_div_def single_step_def bind_def2 tappend_def2
                 split: tmres.splits)
  apply (case_tac x; clarsimp)
  apply (case_tac xa; clarsimp)
   apply fastforce
  apply blast
  done

lemma single_step_bind:
  "\<lbrakk> single_step f \<and> (\<forall>x. no_trace \<top> (g x)) \<or>
     no_trace \<top> f \<and> no_div \<top> f \<and> (\<forall>x. single_step (g x)) \<rbrakk>
     \<Longrightarrow> single_step (f >>= (\<lambda>rv. g rv))"
  by (erule disjE; clarsimp simp: single_step_bindl single_step_bindr)

lemma single_step_get[simp, wp]:
  "single_step get"
  by (simp add: single_step_def get_def)

lemma single_step_put[simp, wp]:
  "single_step (put s)"
  by (simp add: single_step_def put_def)

lemma single_step_modify[simp, wp]:
  "single_step (modify f)"
  by (simp add: single_step_def modify_def)

lemma single_step_gets[simp, wp]:
  "single_step (gets f)"
  unfolding gets_def
  by (wpsimp | rule single_step_bind)+

named_theorems single_step_wps


lemma single_step_atom[single_step_wps]:
  "\<lbrakk> single_step f; \<And>st. \<lbrace>P st\<rbrace> f \<lbrace>\<lambda>_ s. R (st,Proc,s)\<rbrace> \<rbrakk>
     \<Longrightarrow> \<lbrace>\<lambda>s. P s s\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>\<A>(R)\<rbrace>\<^sup>*"
  apply (clarsimp simp: validf_def)
  apply (drule runList_tmres, clarsimp)
  apply (drule (1) single_stepD)
  apply (clarsimp)
  apply (erule_tac x=s in meta_allE)
  apply (drule post_by_hoare, fastforce, erule in_mres, rule refl)
  apply (clarsimp simp: ltl_semantics)
  done

lemma single_step_until[single_step_wps]:
  "\<lbrakk> single_step f; \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>F\<rbrace>\<^sup>* \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>G \<U> F\<rbrace>\<^sup>*"
  apply (rule validfI)
  apply (frule (3) validfD)
  apply (drule runList_tmres, clarsimp)
  apply (drule (1) single_stepD, clarsimp)
  apply (fastforce simp: ltl_semantics)
  done

lemma single_step_finally[single_step_wps]:
  "\<lbrakk> single_step f; \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>F\<rbrace>\<^sup>* \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>\<diamond>F\<rbrace>\<^sup>*"
  apply (rule validfI)
  apply (frule (3) validfD)
  apply (drule runList_tmres, clarsimp)
  apply (drule (1) single_stepD, clarsimp)
  apply (fastforce simp: ltl_semantics)
  done

lemma single_step_globally[single_step_wps]:
  "\<lbrakk> single_step f; \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>G\<rbrace>\<^sup>* \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>\<box>G\<rbrace>\<^sup>*"
  apply (rule validfI)
  apply (frule (3) validfD)
  apply (drule runList_tmres, clarsimp)
  apply (drule (1) single_stepD, clarsimp)
  apply (fastforce simp: ltl_semantics)
  done


(* FIXME ryanb: move *)
lemma validf_vcg_conj_lift:
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. P s \<and> P' s\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q \<and>\<^sub>l Q'\<rbrace>\<^sup>*"
  unfolding validf_def by (auto simp: ltl_semantics)

(* FIXME ryanb: move *)
lemma validf_vcg_disj_lift:
  "\<lbrakk> \<lbrace>P\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q\<rbrace>\<^sup>*; \<lbrace>P'\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q'\<rbrace>\<^sup>* \<rbrakk> \<Longrightarrow> \<lbrace>\<lambda>s. P s \<or> P' s\<rbrace>,\<lbrace>F\<rbrace> f \<lbrace>Q \<or>\<^sub>l Q'\<rbrace>\<^sup>*"
  unfolding validf_def by (auto simp: ltl_semantics)

(* FIXME ryanb: move *)
lemma validf_False:
  "\<lbrace>\<bottom>\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>F\<rbrace>\<^sup>*"
  by (simp add: validf_def)

lemma single_step_release[single_step_wps]:
  "\<lbrakk> single_step f; \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>G\<rbrace>\<^sup>* \<rbrakk>
     \<Longrightarrow> \<lbrace>P\<rbrace>,\<lbrace>A\<rbrace> f \<lbrace>F \<R> G\<rbrace>\<^sup>*"
  unfolding LTL_Release_def
  apply (rule hoare_pre)
   apply (rule validf_vcg_disj_lift)
    apply (rule single_step_wps)
     apply simp
    apply (rule validf_vcg_conj_lift)
     apply assumption
    apply (rule validf_False)
   apply (rule single_step_wps; assumption)
  apply simp
  done


lemmas [single_step_wps] =
    validf_validl2[OF single_step_atom]
    validf_validl2[OF single_step_until]
    validf_validl2[OF single_step_release]
    validf_validl2[OF single_step_finally]
    validf_validl2[OF single_step_globally]


lemmas [single_step_wps] =
  validl2_weaken_asm[where F'=True\<^sub>l, simplified, OF
    validl2_conj_elim[OF single_step_atom valid_valid2]]
  validl2_weaken_asm[where F'=True\<^sub>l, simplified, OF
    validl2_conj_elim[OF single_step_until valid_valid2]]
  validl2_weaken_asm[where F'=True\<^sub>l, simplified, OF
    validl2_conj_elim[OF single_step_finally valid_valid2]]
  validl2_weaken_asm[where F'=True\<^sub>l, simplified, OF
    validl2_conj_elim[OF single_step_globally valid_valid2]]

end
