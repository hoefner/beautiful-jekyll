(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_No_Div
imports VCG_Valid
begin

definition diverged :: "(('s, 'a) tmres) set \<Rightarrow> bool" where
  "diverged r \<equiv> \<exists>ts. Diverged ts \<in> r"

definition no_div :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> bool" where
  "no_div P m \<equiv> \<forall>s. P s \<longrightarrow> \<not> diverged (m s)"

lemma diverged_simps[simp]:
  "diverged {x} = (\<exists>ts. x = Diverged ts)"
  "diverged (r \<union> r') = (diverged r \<or> diverged r')"
  "\<not> diverged {}"
  by (auto simp: diverged_def)

lemma no_div_pre[wp_pre]:
  "\<lbrakk> no_div P f; \<And>s. Q s \<Longrightarrow> P s\<rbrakk> \<Longrightarrow> no_div Q f"
  by (simp add: no_div_def)

lemma wpc_helper_no_div_final:
  "no_div Q f \<Longrightarrow> wpc_helper (P, P', P'') (Q, Q', Q'') (no_div P f)"
  by (clarsimp simp: wpc_helper_def elim!: no_div_pre)

wpc_setup "\<lambda>m. no_div P m" wpc_helper_no_div_final


bundle no_pre = hoare_pre [wp_pre del] no_div_pre [wp_pre del]

bundle classic_wp_pre =
  hoare_pre [wp_pre del]
  all_classic_wp_combs[wp_comb del]
  all_classic_wp_combs[wp_comb]


lemma no_divD:
  "\<lbrakk> no_div P m; P s \<rbrakk> \<Longrightarrow> \<not> diverged (m s)"
  by (simp add: no_div_def)

lemma no_div_return[simp, wp]:
  "no_div \<top> (return x)"
  by (simp add: return_def no_div_def)

lemma no_div_bind[wp]:
  "\<lbrakk> no_div P f; \<And>x. no_div (R x) (g x); \<lbrace>Q\<rbrace> f \<lbrace>R\<rbrace> \<rbrakk>
     \<Longrightarrow> no_div (P and Q) (f >>= (\<lambda>rv. g rv))"
  apply (clarsimp simp: no_div_def bind_def2 image_Un image_image
                        in_image_constant diverged_def)
  apply (clarsimp split: tmres.splits)
  apply (drule (1) post_by_hoare, erule in_mres, fastforce)
  apply (clarsimp simp: tappend_def2 split: tmres.splits)
  done

lemma no_div_get[simp, wp]:
  "no_div \<top> get"
  by (simp add: get_def no_div_def)

lemma no_div_put[simp, wp]:
  "no_div \<top> (put s)"
  by (simp add: put_def no_div_def)

lemma no_div_modify[wp,simp]:
  "no_div \<top> (modify f)"
  by (simp add: modify_def no_div_def)

lemma no_div_gets_simp[simp]:
  "no_div P (gets f)"
  by (wpsimp simp: gets_def)

lemma no_div_gets[wp]:
  "no_div \<top> (gets f)"
  by simp

lemma no_div_select[wp,simp]:
  "no_div \<top> (select S)"
  by (simp add: no_div_def select_def image_def diverged_def)

lemma no_div_alt[wp]:
  "\<lbrakk> no_div P f; no_div Q g \<rbrakk> \<Longrightarrow> no_div (P and Q) (f \<^bold>+ g)"
  by (auto simp: no_div_def choice_def)

lemma no_div_when[wp]:
  "(P \<Longrightarrow> no_div Q f) \<Longrightarrow> no_div (if P then Q else \<top>) (when P f)"
  by (simp add: when_def)

lemma no_div_unless[wp]:
  "(\<not>P \<Longrightarrow> no_div Q f) \<Longrightarrow> no_div (if P then \<top> else Q) (unless P f)"
  by (simp add: unless_def when_def)

lemma no_div_fail[simp, wp]:
  "no_div \<top> fail"
  by (simp add: fail_def no_div_def)

lemma no_div_assert[simp, wp]:
  "no_div \<top> (assert P)"
  by (simp add: assert_def)

lemma no_div_assert_opt[simp, wp]:
  "no_div \<top> (assert_opt P)"
  by (simp add: assert_opt_def split: option.splits)

lemma no_div_case_option[wp]:
  assumes f: "no_div P f"
  assumes g: "\<And>x. no_div (Q x) (g x)"
  shows "no_div (if x = None then P else Q (the x)) (case_option f g x)"
  by (clarsimp simp add: f g)

lemma no_div_if[wp]:
  "\<lbrakk> P \<Longrightarrow> no_div Q f; \<not>P \<Longrightarrow> no_div R g \<rbrakk> \<Longrightarrow> no_div (if P then Q else R) (if P then f else g)"
  by simp

lemma no_div_apply[wp]:
  "no_div P (f (g x)) \<Longrightarrow> no_div P (f $ g x)"
  by simp

lemma no_div_undefined[simp, wp]:
  "no_div \<bottom> undefined"
  by (simp add: no_div_def)

lemma no_div_assume_pre:
  "(\<And>s. P s \<Longrightarrow> no_div P f) \<Longrightarrow> no_div P f"
  by (simp add: no_div_def)

lemma no_div_liftM[wp]:
  "no_div P m \<Longrightarrow> no_div P (liftM f m)"
  unfolding liftM_def
  by wpsimp

lemma no_div_pre_and:
  "no_div P f \<Longrightarrow> no_div (P and Q) f"
  by (erule no_div_pre) simp

lemma no_div_spec:
  "\<lbrakk> \<And>s. no_div (((=) s) and P) f \<rbrakk> \<Longrightarrow> no_div P f"
  by (simp add: no_div_def)

lemma no_div_spec_pre:
  "\<lbrakk> no_div (((=) s) and P') f; \<And>s. P s \<Longrightarrow> P' s \<rbrakk> \<Longrightarrow> no_div (((=) s) and P) f"
  by (erule no_div_pre, simp)

lemma no_div_gets_the[wp]:
  "no_div \<top> (gets_the f)"
  unfolding gets_the_def
  by wpsimp

lemma no_div_False[simp]:
  "no_div (\<lambda>_. False) X"
  by (clarsimp simp: no_div_def)

lemma no_div_gets_map[wp]:
  "no_div \<top> (gets_map f p)"
  unfolding gets_map_def by wpsimp

lemma no_div_or:
  "\<lbrakk>no_div P a; no_div Q a\<rbrakk> \<Longrightarrow> no_div (P or Q) a"
  by (clarsimp simp: no_div_def)

lemma no_div_state_assert[wp]:
  "no_div P (state_assert P)"
  unfolding state_assert_def
  by wpsimp

lemma no_div_condition[wp]:
  "\<lbrakk>no_div Q A; no_div R B\<rbrakk> \<Longrightarrow> no_div (\<lambda>s. (C s \<longrightarrow> Q s) \<and> (\<not> C s \<longrightarrow> R s)) (condition C A B)"
  unfolding condition_def no_div_def
  by clarsimp

lemma no_div_ex_lift:
  "(\<And>x. no_div (P x) f) \<Longrightarrow> no_div (\<lambda>s. \<exists>x. P x s) f"
  by (fastforce simp: no_div_def)

lemma no_div_grab_asm:
  "(G \<Longrightarrow> no_div P f) \<Longrightarrow> no_div (\<lambda>s. G \<and> P s) f"
  by (cases G; clarsimp)

lemma no_div_put_elem[wp]:
  "no_div \<top> (put_elem x)"
  by (simp add: put_elem_def no_div_def)

lemma no_div_put_list[wp]:
  "no_div \<top> (put_list xs)"
  by (simp add: put_list_def no_div_def)

lemma parallel_diverged:
  "diverged (parallel f g s) \<Longrightarrow> diverged (f s) \<and> diverged (g s)"
  by (auto simp: parallel_def diverged_def image_def intro!: bexI)

lemma no_div_parallel[wp]:
  "\<lbrakk> no_div P f \<or> no_div Q g \<rbrakk> \<Longrightarrow> no_div (P and Q) (parallel f g)"
  by (auto simp: no_div_def dest!: parallel_diverged)

lemma no_divE:
  "\<lbrakk> Diverged ts \<in> f s; no_div P f; P s \<rbrakk>
     \<Longrightarrow> R"
  by (simp add: no_div_def diverged_def)

end
