(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Examples
imports
  VCG_Toplevel
begin

record state =
  count :: nat

lemma
  fixes n
  defines "P \<equiv> \<lambda>(s,a,s'). count s = n \<and> count s' = Suc n"
      and "Q \<equiv> \<lambda>(s,a,s'). count s = n \<and> count s' = n"
      and "R \<equiv> \<lambda>(s,a,s'). a = Env \<longrightarrow> count s = n \<longrightarrow> count s' = n"
  shows
    "\<lbrace>\<lambda>s. count s = n\<rbrace>,\<lbrace>\<box>\<A>(R)\<rbrace>
     do
       cnt <- gets count;
       env_steps;
       modify (\<lambda>s. s\<lparr>count := cnt + 1\<rparr>)
     od
     \<lbrace>\<A>(Q) \<U> \<A>(P)\<rbrace>\<^sup>*"
  apply ltl_wpr
   apply ltl_wpr
    apply (wp single_step_wps)
   apply (simp only: R_def)
   apply (rule rely_env_steps)
   apply (rule validl2_globally_induct, clarify)
   apply (simp only: P_def Q_def, clarify)
   apply (simp add: P_def Q_def)
  apply (wp single_step_wps)
  apply (simp add: P_def Q_def)
  done

end
