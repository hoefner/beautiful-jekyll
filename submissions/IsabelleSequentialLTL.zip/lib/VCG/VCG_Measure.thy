(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_Measure
imports
  VCG_Setup
begin

type_synonym 's measure = "'s \<Rightarrow> enat"

abbreviation measure_mono :: "'s measure \<Rightarrow> 's \<Rightarrow> 's \<Rightarrow> bool" where
  "measure_mono m s s' \<equiv> (\<forall>n. m s = Suc n \<longrightarrow> m s' \<le> Suc n) \<and>
                          (m s' = \<infinity> \<longrightarrow> m s = \<infinity>)"

abbreviation measure_progress :: "'s measure \<Rightarrow> 's \<Rightarrow> 's \<Rightarrow> bool" where
  "measure_progress m s s' \<equiv> \<forall>n. m s = Suc n \<longrightarrow> m s' \<le> n"

abbreviation measurable :: "'s measure \<Rightarrow> 's \<Rightarrow> bool" where
  "measurable m s \<equiv> m s \<noteq> \<infinity>"

lemma measure_mono_defined:
  assumes mono: "(ts,0) \<tturnstile> \<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')"
    and measurable: "(ts,0) \<tturnstile> \<A>(\<lambda>(s,a,s'). measurable mf s)"
    and connected: "sconnected ts"
  shows "(ts,0) \<tturnstile> \<box>\<A>(\<lambda>(s,a,s'). measurable mf s)"
proof (induct rule: ltli_globally_induct)
  case 1
  then show ?case
    using measurable .
next
  case (2 j)
  then show ?case
    apply (insert connected mono, clarsimp)
    apply (drule_tac i=j in sconnectedD')
    apply (frule_tac i=j in ltl_globallyD(3); clarsimp?)
    apply (drule_tac i="Suc j" in ltl_globallyD(3); clarsimp?)
    apply (clarsimp simp: ltli_atom_def)
    done
qed

lemma measure_ltl:
  fixes mf :: "'s measure"
  assumes mono: "(ts,0) \<tturnstile> \<box>\<A>(\<lambda>(s,a,s'). measure_mono mf s s')"
  and progress: "(ts,0) \<tturnstile> \<box>\<diamond>\<A>(\<lambda>(s,a,s'). measure_progress mf s s')"
  and measurable: "(ts,0) \<tturnstile> \<A>(\<lambda>(s,a,s'). measurable mf s)"
  and connected: "sconnected ts"
  shows "(ts,0) \<tturnstile> \<box>\<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"

proof (rule ltl_globallyI)
  fix i
  obtain mi where "mf (zfst (ts !- i)) = mi"
    by simp
  then show "(ts,i) \<tturnstile> \<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
  proof (induct mi arbitrary: i rule: enat_less_induct)
    case (1 mi)
    assume ih: "\<forall>m<mi. \<forall>i. mf (zfst (ts !- i)) = m \<longrightarrow> (ts, i) \<tturnstile> \<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
      and mi: "mf (zfst (ts !- i)) = mi"
    {
      assume "mi = 0"
      then have "(ts,i) \<tturnstile> \<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
        using mi by (fastforce simp: ltl_semantics)
    }
    moreover {
      assume "\<exists>n. mi = Suc n"
      then obtain n where n: "mi = Suc n"
        by clarsimp
      obtain j' where ij': "i \<le> j'" and j': "(ts,j') \<tturnstile> \<A>(\<lambda>(s,a,s'). measure_progress mf s s')"
        using bot_nat_0.extremum ltl_finallyE(3) ltli_globally_def progress by blast
      then obtain j where ij: "i \<le> j"
        and j: "(ts,j) \<tturnstile> \<A>(\<lambda>(s,a,s'). \<forall>n. mf s = Suc n \<longrightarrow> mf s' \<le> n)"
        and k: "\<forall>k. i \<le> k \<and> k < j \<longrightarrow> \<not> (ts,k) \<tturnstile> \<A>(\<lambda>(s,a,s'). measure_progress mf s s')"
        using ex_least_nat_ge[where P="\<lambda>j'. (ts, j') \<tturnstile> \<A>(\<lambda>(s,a,s'). measure_progress mf s s')", OF j' ij']
        by auto
      obtain m where m: "mf (zsnd (ts !- j)) = m"
        by simp
      have sj: "mf (zfst (ts !- Suc j)) = m"
        using sconnectedD[OF connected] m by simp
      have all_between: "\<forall>k. i + k \<le> j \<longrightarrow> (ts,i+k) \<tturnstile> \<A>(\<lambda>(s,a,s'). mf s = eSuc n)"
        apply (intro allI)
        apply (induct_tac k)
         apply (simp add: "1.prems" ltli_atom_def n split_beta eSuc_enat)
        apply clarsimp
        apply (rename_tac k)
        apply (subgoal_tac "(ts, i + k) \<tturnstile> \<A>(\<lambda>(s,a,s'). mf s' = eSuc n)")
         apply (simp add: sconnectedD[OF connected] ltli_atom_def split_beta)
        apply (insert k)
        apply (erule_tac x="i + k" in allE)
        apply (drule mp)
         apply clarsimp
        apply (insert mono)
        apply (erule_tac i="i + k" in ltl_globallyE(3))
         apply clarsimp
        apply (clarsimp simp: ltl_semantics)
        by (metis Suc_ile_eq linorder_not_le nle_le)
      have mn: "m \<le> n"
        apply (insert all_between)
        apply (erule_tac x="j - i" in allE)
        apply (clarsimp simp: ij)
        using m j by (fastforce simp: ltl_semantics  eSuc_enat)
      have "(ts, Suc j) \<tturnstile> \<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
        apply (insert ih)
        apply (erule_tac x=m in allE)
        apply (simp add: le_imp_less_Suc mn n)
        using Suc_ile_eq linorder_not_le mn sj by blast
      then have "(ts,i) \<tturnstile> \<diamond>\<A>(\<lambda>(s,a,s'). mf s = 0)"
        by (meson Suc_leD ij le_trans ltli_finally_def)
    }
    ultimately show ?case
      apply (case_tac mi)
      using enat_0 list_decode.cases apply blast
      apply clarsimp
      apply (insert mi measure_mono_defined[OF mono measurable connected])
      apply (erule_tac i=i in ltl_globallyE(3); clarsimp simp: ltl_semantics)
      done
  qed
qed


end
