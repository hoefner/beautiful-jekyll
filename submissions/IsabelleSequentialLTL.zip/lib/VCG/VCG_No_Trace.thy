(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory VCG_No_Trace
imports VCG_Valid
begin

definition no_trace :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> bool" where
  "no_trace P f = (\<forall>s. P s \<longrightarrow> (\<forall>res. res \<in> f s
     \<longrightarrow> res = Failed \<or> res = Diverged <> \<or> (\<exists>rv. res = Result [] rv)))"

lemma no_trace_pre[wp_pre]:
  "\<lbrakk> no_trace P f; \<And>s. Q s \<Longrightarrow> P s\<rbrakk> \<Longrightarrow> no_trace Q f"
  by (auto simp: no_trace_def)

lemma wpc_helper_no_trace_final:
  "no_trace Q f \<Longrightarrow> wpc_helper (P, P', P'') (Q, Q', Q'') (no_trace P f)"
  by (clarsimp simp: wpc_helper_def elim!: no_trace_pre)

wpc_setup "\<lambda>m. no_trace P m" wpc_helper_no_trace_final


bundle no_pre = hoare_pre [wp_pre del] no_trace_pre [wp_pre del]

bundle classic_wp_pre =
  hoare_pre [wp_pre del]
  all_classic_wp_combs[wp_comb del]
  all_classic_wp_combs[wp_comb]


lemmas no_traceD = no_trace_def[THEN iffD1, rule_format]

lemma no_trace_bind[wp]:
  "\<lbrakk> no_trace P f; \<And>x. no_trace (R x) (g x); \<lbrace>Q\<rbrace> f \<lbrace>R\<rbrace> \<rbrakk>
     \<Longrightarrow> no_trace (P and Q) (f >>= (\<lambda>rv. g rv))"
  apply (clarsimp simp: no_trace_def bind_def2 image_Un image_image
                        in_image_constant)
  apply (clarsimp split: tmres.splits)
   apply fastforce
  by (metis in_mres tappend_nil tmres.distinct(3) tmres.distinct(5) tmres.inject(2) use_valid)

lemma no_trace_get[simp, wp]:
  "no_trace \<bottom> get"
  by (simp add: no_trace_def get_def)

lemma no_trace_put[simp, wp]:
  "no_trace \<bottom> (put s)"
  by (simp add: no_trace_def put_def)

lemma no_trace_modify[simp, wp]:
  "no_trace \<bottom> (modify f)"
  by (simp add: no_trace_def modify_def)

lemma no_trace_return[simp, wp]:
  "no_trace \<top> (return x)"
  by (simp add: return_def no_trace_def)

lemma no_trace_fail[simp, wp]:
  "no_trace \<top> fail"
  by (simp add: no_trace_def fail_def)

lemma no_trace_select[simp, wp]:
  "no_trace \<top> (select S)"
  by (clarsimp simp add: no_trace_def select_def)

lemma no_trace_gets[simp, wp]:
  "no_trace \<bottom> (gets f)"
  unfolding gets_def
  by (rule no_trace_pre) wpsimp+

lemma no_trace_assert[simp, wp]:
  "no_trace \<top> (assert P)"
  by (simp add: assert_def)

lemma no_trace_case_option[wp]:
  assumes f: "no_trace P f"
  assumes g: "\<And>x. no_trace (Q x) (g x)"
  shows "no_trace (if x = None then P else Q (the x)) (case_option f g x)"
  by (clarsimp simp add: f g)

lemma no_trace_assert_opt[simp, wp]:
  "no_trace \<top> (assert_opt P)"
  by (simp add: assert_opt_def split: option.splits)

lemma no_trace_alt[wp]:
  "\<lbrakk> no_trace P f; no_trace Q g \<rbrakk> \<Longrightarrow> no_trace (P and Q) (f \<^bold>+ g)"
  by (auto simp: no_trace_def choice_def)

lemma no_trace_when[wp]:
  "(P \<Longrightarrow> no_trace Q f) \<Longrightarrow> no_trace (if P then Q else \<top>) (when P f)"
  by (simp add: when_def)

lemma no_trace_unless[wp]:
  "(\<not>P \<Longrightarrow> no_trace Q f) \<Longrightarrow> no_trace (if P then \<top> else Q) (unless P f)"
  by (simp add: unless_def when_def)

lemma no_trace_if[wp]:
  "\<lbrakk> P \<Longrightarrow> no_trace Q f; \<not>P \<Longrightarrow> no_trace R g \<rbrakk> \<Longrightarrow> no_trace (if P then Q else R) (if P then f else g)"
  by simp

lemma no_trace_apply[wp]:
  "no_trace P (f (g x)) \<Longrightarrow> no_trace P (f $ g x)"
  by simp

lemma no_trace_liftM[wp]:
  "no_trace P m \<Longrightarrow> no_trace P (liftM f m)"
  unfolding liftM_def
  by wpsimp

lemma no_trace_undefined[simp, wp]:
  "no_trace \<bottom> undefined"
  by (simp add: no_trace_def)

lemma no_trace_assume_pre:
  "(\<And>s. P s \<Longrightarrow> no_trace P f) \<Longrightarrow> no_trace P f"
  by (simp add: no_trace_def)

lemma no_trace_pre_and:
  "no_trace P f \<Longrightarrow> no_trace (P and Q) f"
  by (erule no_trace_pre) simp

lemma no_trace_spec:
  "\<lbrakk> \<And>s. no_trace (((=) s) and P) f \<rbrakk> \<Longrightarrow> no_trace P f"
  by (simp add: no_trace_def)

lemma no_trace_spec_pre:
  "\<lbrakk> no_trace (((=) s) and P') f; \<And>s. P s \<Longrightarrow> P' s \<rbrakk> \<Longrightarrow> no_trace (((=) s) and P) f"
  by (erule no_trace_pre, simp)

lemma no_trace_False[simp]:
  "no_trace (\<lambda>_. False) X"
  by (clarsimp simp: no_trace_def)

lemma no_trace_or:
  "\<lbrakk>no_trace P a; no_trace Q a\<rbrakk> \<Longrightarrow> no_trace (P or Q) a"
  by (clarsimp simp: no_trace_def)

lemma no_trace_condition[wp]:
  "\<lbrakk>no_trace Q A; no_trace R B\<rbrakk> \<Longrightarrow> no_trace (\<lambda>s. (C s \<longrightarrow> Q s) \<and> (\<not> C s \<longrightarrow> R s)) (condition C A B)"
  unfolding condition_def no_trace_def
  by clarsimp

lemma no_trace_ex_lift:
  "(\<And>x. no_trace (P x) f) \<Longrightarrow> no_trace (\<lambda>s. \<exists>x. P x s) f"
  by (fastforce simp: no_trace_def)

lemma no_trace_grab_asm:
  "(G \<Longrightarrow> no_trace P f) \<Longrightarrow> no_trace (\<lambda>s. G \<and> P s) f"
  by (cases G; clarsimp)

lemma no_trace_parallel[wp]:
  "\<lbrakk> no_trace P f \<or> no_trace Q g \<rbrakk> \<Longrightarrow> no_trace (P and Q) (parallel f g)"
  apply (clarsimp simp: no_trace_def parallel_def)
  apply (case_tac res; clarsimp)
   apply (metis (no_types, lifting) llength_eq_0 lmap_eq_LNil lnull_def lzip_eq_LNil_conv tmres.distinct(1) tmres.distinct(5) tmres.inject(1))
  apply fastforce
  done

end
