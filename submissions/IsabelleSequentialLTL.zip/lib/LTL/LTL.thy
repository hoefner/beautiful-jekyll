(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory LTL
imports LTL.LTL_Setup
begin

datatype 'a ltl\<^sub>0 =
  LTL_Atom\<^sub>0 'a ("\<A>\<^sub>0'(_')")
| LTL_Conj\<^sub>0 "'a ltl\<^sub>0" "'a ltl\<^sub>0" ("_ \<and>\<^sub>0 _" [86,85] 85)
| LTL_Not\<^sub>0 "'a ltl\<^sub>0" ("\<not>\<^sub>0_" [89] 89)
| LTL_Next\<^sub>0 "'a ltl\<^sub>0" ("\<circle>\<^sub>0_" [89] 89)
| LTL_Until\<^sub>0 "'a ltl\<^sub>0" "'a ltl\<^sub>0" ("_ \<U>\<^sub>0 _" [88,87] 87)

fun ltl\<^sub>0_semantics :: "'a llist \<times> nat \<Rightarrow> ('a \<Rightarrow> bool) ltl\<^sub>0 \<Rightarrow> bool"
  ("_ \<Turnstile>\<^sub>0 _" [80,80] 80) where
  "(ts,i) \<Turnstile>\<^sub>0 \<A>\<^sub>0(P)  = P (lhd (ldrop i ts))"
| "(ts,i) \<Turnstile>\<^sub>0 P \<and>\<^sub>0 Q = ((ts,i) \<Turnstile>\<^sub>0 P \<and> (ts,i) \<Turnstile>\<^sub>0 Q)"
| "(ts,i) \<Turnstile>\<^sub>0 \<not>\<^sub>0P    = (\<not>(ts,i) \<Turnstile>\<^sub>0 P)"
| "(ts,i) \<Turnstile>\<^sub>0 \<circle>\<^sub>0P    = (Suc i < llength ts \<and> (ts,Suc i) \<Turnstile>\<^sub>0 P)"
| "(ts,i) \<Turnstile>\<^sub>0 P \<U>\<^sub>0 Q = (\<exists>j. i \<le> j \<and> j < llength ts \<and> (ts,j) \<Turnstile>\<^sub>0 Q
                         \<and> (\<forall>k. i \<le> k \<and> k < j \<longrightarrow> (ts,k) \<Turnstile>\<^sub>0 P))"


functor map_ltl\<^sub>0
  by (auto simp: ltl\<^sub>0.map_id0 ltl\<^sub>0.map_comp o_def)

definition ltl\<^sub>0_eq ::
  "('a \<Rightarrow> bool) ltl\<^sub>0 \<Rightarrow> ('a \<Rightarrow> bool) ltl\<^sub>0 \<Rightarrow> bool" where
  "ltl\<^sub>0_eq P Q \<equiv> \<forall>ts i. (ts,i) \<Turnstile>\<^sub>0 P = (ts,i) \<Turnstile>\<^sub>0 Q"

quotient_type 'a ltl = "('a \<Rightarrow> bool) ltl\<^sub>0" / "ltl\<^sub>0_eq"
 by (auto simp: equivpI reflp_def symp_def transp_def ltl\<^sub>0_eq_def)

lift_definition LTL_Atom :: "('a \<Rightarrow> bool) \<Rightarrow> 'a ltl" ("\<A>'(_')") is "LTL_Atom\<^sub>0" .

lift_definition LTL_Conj ::  "'a ltl \<Rightarrow> 'a ltl \<Rightarrow> 'a ltl" ("_ \<and>\<^sub>l _" [86,85] 85) is "LTL_Conj\<^sub>0"
  by (simp add: ltl\<^sub>0_eq_def)

lift_definition LTL_Not ::  "'a ltl \<Rightarrow> 'a ltl" ("\<not>\<^sub>l_" [89] 89) is "LTL_Not\<^sub>0"
  by (simp add: ltl\<^sub>0_eq_def)

lift_definition LTL_Next ::  "'a ltl \<Rightarrow> 'a ltl" ("\<circle>_" [89] 89) is "LTL_Next\<^sub>0"
  by (simp add: ltl\<^sub>0_eq_def)

lift_definition ltl_semantics ::  "'a llist \<times> nat \<Rightarrow> 'a ltl \<Rightarrow> bool"
  ("_ \<Turnstile> _" [80,80] 80) is "ltl\<^sub>0_semantics"
  by (clarsimp simp: ltl\<^sub>0_eq_def)

lemma ltl_eq:
  "(P = Q) = (\<forall>ts n. (ts,n) \<Turnstile> P = (ts,n) \<Turnstile> Q)"
  by transfer (simp add: ltl\<^sub>0_eq_def)


named_theorems ltl_semantics

lemma
  shows ltl_atom_def[ltl_semantics]:
    "(ts,i) \<Turnstile> \<A>(f) = f (lhd (ldrop i ts))"
  and ltl_not_def[ltl_semantics]:
    "(ts,i) \<Turnstile> \<not>\<^sub>l P = (\<not>(ts,i) \<Turnstile> P)"
  and ltl_conj_def[ltl_semantics]:
    "(ts,i) \<Turnstile> P \<and>\<^sub>l Q = ((ts,i) \<Turnstile> P \<and> (ts,i) \<Turnstile> Q)"
  and ltl_next_def[ltl_semantics]:
    "(ts,i) \<Turnstile> \<circle>P = (Suc i < llength ts \<and> (ts,Suc i) \<Turnstile> P)"
  by (transfer, simp)+

lift_definition LTL_Until ::  "'a ltl \<Rightarrow> 'a ltl \<Rightarrow> 'a ltl"
  ("_ \<U> _" [88,87] 87) is "LTL_Until\<^sub>0"
  by (simp add: ltl\<^sub>0_eq_def)

lemma ltl_until_def[ltl_semantics]:
  "(ts,i) \<Turnstile> P \<U> Q = (\<exists>j. i \<le> j \<and> j < llength ts \<and> (ts,j) \<Turnstile> Q \<and>
                          (\<forall>k. i \<le> k \<and> k < j \<longrightarrow> (ts,k) \<Turnstile> P))"
 by (transfer, simp)

lemma ltl_eqI:
  "\<lbrakk> \<And>ts n. (ts,n) \<Turnstile> P = (ts,n) \<Turnstile> Q \<rbrakk> \<Longrightarrow> P = Q"
  by (simp add: ltl_eq)


definition LTL_Disj ("_ \<or>\<^sub>l _" [84,83] 83) where
  "P \<or>\<^sub>l Q \<equiv> \<not>\<^sub>l (\<not>\<^sub>lP \<and>\<^sub>l \<not>\<^sub>lQ)"

definition LTL_Implies ("_ \<longrightarrow>\<^sub>l _" [82,81] 81) where
  "P \<longrightarrow>\<^sub>l Q \<equiv> \<not>\<^sub>lP \<or>\<^sub>l Q"

definition LTL_Finally ("\<diamond>_" [89] 89) where
  "\<diamond>P \<equiv> \<A>(\<top>) \<U> P"

definition LTL_Globally ("\<box>_" [89] 89) where
  "\<box>P \<equiv> \<not>\<^sub>l\<diamond>\<not>\<^sub>lP"

definition LTL_Weak_Next ("\<ominus>_" [89] 89) where
  "\<ominus>P = (\<not>\<^sub>l\<circle>\<A>(\<top>) \<or>\<^sub>l \<circle>P)"

definition LTL_Release ("_ \<R> _" [88,87] 87) where
  "P \<R> Q \<equiv> (Q \<U> (Q \<and>\<^sub>l P)) \<or>\<^sub>l \<box>Q"


lemma
  shows ltl_disj_def[ltl_semantics]:
    "(ts,i) \<Turnstile> P \<or>\<^sub>l Q = ((ts,i) \<Turnstile> P \<or> (ts,i) \<Turnstile> Q)"
  and ltl_imp_def[ltl_semantics]:
    "(ts,i) \<Turnstile> P \<longrightarrow>\<^sub>l Q = ((ts,i) \<Turnstile> P \<longrightarrow> (ts,i) \<Turnstile> Q)"
  and ltl_finally_def[ltl_semantics]:
    "(ts,i) \<Turnstile> \<diamond>P = (\<exists>j. i \<le> j \<and> j < llength ts \<and> (ts,j) \<Turnstile> P)"
  and ltl_globally_def[ltl_semantics]:
    "(ts,i) \<Turnstile> \<box>P = (\<forall>j. i \<le> j \<and> j < llength ts \<longrightarrow> (ts,j) \<Turnstile> P)"
  and ltl_weak_next_def[ltl_semantics]:
    "(ts,i) \<Turnstile> \<ominus>P = (Suc i < llength ts \<longrightarrow> (ts, Suc i) \<Turnstile> P)"
  and ltl_release_def[ltl_semantics]:
    "(ts,i) \<Turnstile> P \<R> Q = (\<forall>j. i \<le> j \<and> j < llength ts \<and> (ts, j) \<Turnstile> \<not>\<^sub>lQ
                            \<longrightarrow> (\<exists>k. i \<le> k \<and> k < j \<and> (ts, k) \<Turnstile> P))"
  unfolding LTL_Disj_def LTL_Implies_def LTL_Finally_def LTL_Globally_def
            LTL_Weak_Next_def LTL_Release_def
  apply (auto simp: ltl_semantics)[5]
  apply (rule iffI)
   apply (clarsimp simp: LTL_Release_def ltl_semantics)
   apply (metis linorder_less_linear)
  apply (case_tac "\<exists>j. i \<le> j \<and> enat j < llength ts \<and> (ts, j) \<Turnstile> \<not>\<^sub>l Q")
   apply (erule exE)
   apply (erule conjE)
   apply (drule_tac n=j in ex_least_nat_ge, assumption) back
   apply clarsimp
   apply (clarsimp simp: ltl_semantics)
   apply (smt (verit, del_insts) enat_ord_simps(2) order_less_trans)
  apply (clarsimp simp: ltl_semantics)
  done

end
