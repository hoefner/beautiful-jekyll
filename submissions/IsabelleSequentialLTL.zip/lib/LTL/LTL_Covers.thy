theory LTL_Covers
  imports
    LTL_Cover
    LTL_Cover_Finite
    LTL_Cover_Weak
begin

(*****************************************************************)

named_theorems bcovers_intros
named_theorems pcovers_intros
named_theorems covers_intros

lemmas bcovers_atom[bcovers_intros] =
  LTL_Cover.bcovers_atom
  LTL_Cover_Finite.bcovers_atom
  LTL_Cover_Weak.bcovers_atom

lemmas bcovers_conj[bcovers_intros] =
  LTL_Cover.bcovers_conj
  LTL_Cover_Finite.bcovers_conj
  LTL_Cover_Weak.bcovers_conj

lemmas bcovers_disj =
  LTL_Cover.bcovers_disj
  LTL_Cover_Finite.bcovers_disj
  LTL_Cover_Weak.bcovers_disj

lemmas bcovers_disjI1 =
  LTL_Cover.bcovers_disjI1
  LTL_Cover_Finite.bcovers_disjI1
  LTL_Cover_Weak.bcovers_disjI1

lemmas bcovers_disjI2 =
  LTL_Cover.bcovers_disjI2
  LTL_Cover_Finite.bcovers_disjI2
  LTL_Cover_Weak.bcovers_disjI2

lemmas bcovers_globally[bcovers_intros] =
  LTL_Cover.bcovers_globally
  LTL_Cover_Finite.bcovers_globally
  LTL_Cover_Weak.bcovers_globally

lemmas bcovers_finally[bcovers_intros] =
  LTL_Cover.bcovers_finally
  LTL_Cover_Finite.bcovers_finally
  LTL_Cover_Weak.bcovers_finally

lemmas bcovers_until[bcovers_intros] =
  LTL_Cover.bcovers_until
  LTL_Cover_Finite.bcovers_until
  LTL_Cover_Weak.bcovers_until

lemmas bcovers_release[bcovers_intros] =
  LTL_Cover.bcovers_release
  LTL_Cover_Finite.bcovers_release
  LTL_Cover_Weak.bcovers_release

lemmas bcovers_next[pcovers_intros] =
  LTL_Cover.bcovers_next
  LTL_Cover_Finite.bcovers_next
  LTL_Cover_Weak.bcovers_next

lemmas bcovers_weak_next[pcovers_intros] =
  LTL_Cover.bcovers_weak_next
  LTL_Cover_Finite.bcovers_weak_next
  LTL_Cover_Weak.bcovers_weak_next


lemmas pcovers_atom[pcovers_intros] =
  LTL_Cover.pcovers_atom
  LTL_Cover_Finite.pcovers_atom
  LTL_Cover_Weak.pcovers_atom

lemmas pcovers_conj[pcovers_intros] =
  LTL_Cover.pcovers_conj
  LTL_Cover_Finite.pcovers_conj
  LTL_Cover_Weak.pcovers_conj

lemmas pcovers_disj[pcovers_intros] =
  LTL_Cover.pcovers_disj
  LTL_Cover_Finite.pcovers_disj
  LTL_Cover_Weak.pcovers_disj

lemmas pcovers_globally[pcovers_intros] =
  LTL_Cover.pcovers_globally
  LTL_Cover_Finite.pcovers_globally
  LTL_Cover_Weak.pcovers_globally

lemmas pcovers_finally[pcovers_intros] =
  LTL_Cover.pcovers_finally
  LTL_Cover_Finite.pcovers_finally
  LTL_Cover_Weak.pcovers_finally

lemmas pcovers_until[pcovers_intros] =
  LTL_Cover.pcovers_until
  LTL_Cover_Finite.pcovers_until
  LTL_Cover_Weak.pcovers_until

lemmas pcovers_release[pcovers_intros] =
  LTL_Cover.pcovers_release
  LTL_Cover_Finite.pcovers_release
  LTL_Cover_Weak.pcovers_release

lemmas pcovers_next[pcovers_intros] =
  LTL_Cover.pcovers_next
  LTL_Cover_Finite.pcovers_next
  LTL_Cover_Weak.pcovers_next

lemmas pcovers_weak_next[pcovers_intros] =
  LTL_Cover.pcovers_weak_next
  LTL_Cover_Finite.pcovers_weak_next
  LTL_Cover_Weak.pcovers_weak_next


lemmas covers_atom[covers_intros] =
  LTL_Cover.covers_atom
  LTL_Cover_Finite.covers_atom
  LTL_Cover_Weak.covers_atom

lemmas covers_conj[covers_intros] =
  LTL_Cover.covers_conj
  LTL_Cover_Finite.covers_conj
  LTL_Cover_Weak.covers_conj

lemmas covers_disj[covers_intros] =
  LTL_Cover.covers_disj
  LTL_Cover_Finite.covers_disj
  LTL_Cover_Weak.covers_disj

lemmas covers_globally[covers_intros] =
  LTL_Cover.covers_globally
  LTL_Cover_Finite.covers_globally
  LTL_Cover_Weak.covers_globally

lemmas covers_finally[covers_intros] =
  LTL_Cover.covers_finally
  LTL_Cover_Finite.covers_finally
  LTL_Cover_Weak.covers_finally

lemmas covers_until[covers_intros] =
  LTL_Cover.covers_until
  LTL_Cover_Finite.covers_until
  LTL_Cover_Weak.covers_until

lemmas covers_release[covers_intros] =
  LTL_Cover.covers_release
  LTL_Cover_Finite.covers_release
  LTL_Cover_Weak.covers_release

lemmas covers_next[pcovers_intros] =
  LTL_Cover.covers_next
  LTL_Cover_Finite.covers_next
  LTL_Cover_Weak.covers_next

lemmas covers_weak_next[pcovers_intros] =
  LTL_Cover.covers_weak_next
  LTL_Cover_Finite.covers_weak_next
  LTL_Cover_Weak.covers_weak_next

lemmas bcovers_natom[bcovers_intros] = bcovers_atom[where P="not P" for P, folded ltl_not_atom]
lemmas pcovers_natom[pcovers_intros] = pcovers_atom[where P="not P" for P, folded ltl_not_atom]
lemmas covers_natom[covers_intros] = covers_atom[where P="not P" for P, folded ltl_not_atom]

named_theorems prules
declare bcovers_intros[prules] pcovers_intros[prules] covers_intros[prules]

named_theorems plist_defs
lemmas [plist_defs] =
  LTL_Cover.conj_iff_def
  LTL_Cover.finally_iff_def
  LTL_Cover.globally_iff_def
  LTL_Cover.until_iff_def
  LTL_Cover.release_iff_def
  LTL_Cover_Finite.conj_iff_def
  LTL_Cover_Finite.finally_iff_def
  LTL_Cover_Finite.globally_iff_def
  LTL_Cover_Finite.until_iff_def
  LTL_Cover_Finite.release_iff_def
  LTL_Cover_Weak.conj_iff_def
  LTL_Cover_Weak.finally_iff_def
  LTL_Cover_Weak.globally_iff_def
  LTL_Cover_Weak.until_iff_def
  LTL_Cover_Weak.release_iff_def

lemmas coversI =
  LTL_Cover.coversI
  LTL_Cover_Finite.coversI
  LTL_Cover_Weak.coversI

lemmas coversD1 =
  LTL_Cover.coversD1
  LTL_Cover_Finite.coversD1
  LTL_Cover_Weak.coversD1

lemmas coversD2 =
  LTL_Cover.coversD2
  LTL_Cover_Finite.coversD2
  LTL_Cover_Weak.coversD2

lemmas pcoversI =
  LTL_Cover.pcoversI
  LTL_Cover_Finite.pcoversI
  LTL_Cover_Weak.pcoversI

lemmas pcoversE =
  LTL_Cover.pcoversE
  LTL_Cover_Finite.pcoversE
  LTL_Cover_Weak.pcoversE

lemmas bcoversI =
  LTL_Cover.bcoversI
  LTL_Cover_Finite.bcoversI
  LTL_Cover_Weak.bcoversI

lemmas bcoversE =
  LTL_Cover.bcoversE
  LTL_Cover_Finite.bcoversE
  LTL_Cover_Weak.bcoversE

lemmas bcovers_defs =
  LTL_Cover.ltl_bcover_def
  LTL_Cover_Finite.ltl_bcover_def
  LTL_Cover_Weak.ltl_bcover_def

lemmas pcovers_defs =
  LTL_Cover.ltl_pcover_def
  LTL_Cover_Finite.ltl_pcover_def
  LTL_Cover_Weak.ltl_pcover_def

lemmas covers_defs =
  LTL_Cover.ltl_cover_def
  LTL_Cover_Finite.ltl_cover_def
  LTL_Cover_Weak.ltl_cover_def

lemmas bcovers_weaken =
  LTL_Cover.bcovers_weaken
  LTL_Cover_Finite.bcovers_weaken
  LTL_Cover_Weak.bcovers_weaken

lemmas pcovers_weaken =
  LTL_Cover.pcovers_weaken
  LTL_Cover_Finite.pcovers_weaken
  LTL_Cover_Weak.pcovers_weaken

lemmas covers_weaken =
  LTL_Cover.covers_weaken
  LTL_Cover_Finite.covers_weaken
  LTL_Cover_Weak.covers_weaken

lemmas covers_subst =
  LTL_Cover.covers_subst
  LTL_Cover_Finite.covers_subst
  LTL_Cover_Weak.covers_subst

lemmas covers_triv =
  LTL_Cover.covers_triv
  LTL_Cover_Finite.covers_triv
  LTL_Cover_Weak.covers_triv

lemmas pcovers_subst =
  LTL_Cover.pcovers_subst
  LTL_Cover_Finite.pcovers_subst
  LTL_Cover_Weak.pcovers_subst

lemmas pcovers_triv =
  LTL_Cover.pcovers_triv
  LTL_Cover_Finite.pcovers_triv
  LTL_Cover_Weak.pcovers_triv

lemmas pcovers_False =
  LTL_Cover.pcovers_False
  LTL_Cover_Finite.pcovers_False
  LTL_Cover_Weak.pcovers_False

lemmas bcovers_weaken' =
  LTL_Cover.bcovers_weaken'
  LTL_Cover_Finite.bcovers_weaken'
  LTL_Cover_Weak.bcovers_weaken'

lemmas bcovers_append =
  LTL_Cover.bcovers_append
  LTL_Cover_Finite.bcovers_append
  LTL_Cover_Weak.bcovers_append

lemmas bcovers_appendD1 =
  LTL_Cover.bcovers_appendD1
  LTL_Cover_Finite.bcovers_appendD1
  LTL_Cover_Weak.bcovers_appendD1

lemmas bcovers_appendD2 =
  LTL_Cover.bcovers_appendD2
  LTL_Cover_Finite.bcovers_appendD2
  LTL_Cover_Weak.bcovers_appendD2

lemmas bcovers_subst =
  LTL_Cover.bcovers_subst
  LTL_Cover_Finite.bcovers_subst
  LTL_Cover_Weak.bcovers_subst

lemmas bcovers_triv =
  LTL_Cover.bcovers_triv
  LTL_Cover_Finite.bcovers_triv
  LTL_Cover_Weak.bcovers_triv

lemmas bcovers_False =
  LTL_Cover.bcovers_False
  LTL_Cover_Finite.bcovers_False
  LTL_Cover_Weak.bcovers_False

(*****************************************************************)

(* FIXME ryanb: delete if unused *)
lemma pcoversW_pcoversF:
  "fs pcovers\<^sup>+ F \<Longrightarrow> (null\<^sub>l,F)#(F,null\<^sub>l)#fs pcovers\<^sup>* F"
  apply (rule LTL_Cover_Finite.pcoversI)
  apply (case_tac "lnull xs", clarsimp simp: ltl_semantics lnull_def)
  apply (case_tac "lnull ys", clarsimp simp: ltl_semantics lnull_def)
  apply (erule (3) LTL_Cover_Weak.pcoversE)
  apply fastforce
  done

(* FIXME ryanb: delete if unused *)
lemma covers_map_finite:
  "fs covers\<^sup>* F \<Longrightarrow> (map (\<lambda>(L,R). (L \<and>\<^sub>l finite\<^sub>l, R)) fs) covers\<^sup>* F"
  by (auto simp: LTL_Cover_Finite.ltl_cover_def split_def ltl_semantics)

(*****************************************************************)

definition until_iff where
  "until_iff gs fs G F \<equiv>
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs] @
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps), G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]"

definition until_iff' where
  "until_iff' gs fs G F \<equiv>
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L',R') \<leftarrow> fs] @
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps), G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]"

lemma bcovers_altI:
  "fs bcovers\<^sup>+ F \<and> ((\<forall>(L,R) \<in> set fs. (\<forall>ys. (<>,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R \<longrightarrow> (ys,0) \<Turnstile> F))) \<Longrightarrow> fs bcovers\<^sup>* F"
  apply (rule bcoversI)
  apply (case_tac "lnull xs"; case_tac "lnull ys"; clarsimp simp: lnull_def)
  by (fastforce elim: bcoversE simp: enat_0)+

lemma bcovers_alt_globally:
  "gs bcovers\<^sup>+ G \<Longrightarrow> (LTL_Cover_Weak.globally_iff gs G) bcovers\<^sup>* (\<box>G)"
  apply (rule bcovers_altI)
  apply (clarsimp simp:)
  apply (drule LTL_Cover_Weak.bcovers_globally, clarsimp)
  apply (clarsimp simp: LTL_Cover_Weak.globally_iff_def)
  done

lemma bcovers_alt_finally:
  "fs bcovers\<^sup>+ F \<Longrightarrow> (LTL_Cover_Weak.finally_iff fs F) bcovers\<^sup>* \<diamond>F"
  apply (rule bcovers_altI)
  apply (clarsimp simp:)
  apply (drule LTL_Cover_Weak.bcovers_finally, clarsimp)
  apply (auto simp: LTL_Cover_Weak.finally_iff_def ltl_semantics)
  done

lemma bcovers_alt_until:
  "\<lbrakk> gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> until_iff gs fs G F bcovers\<^sup>* G \<U> F"
  apply (rule bcovers_altI)
  apply (clarsimp simp:)
  apply (drule (1) LTL_Cover_Weak.bcovers_until)
  apply (rule conjI)
   apply (erule bcovers_weaken)
   apply (clarsimp simp: until_iff_def LTL_Cover_Weak.until_iff_def)
   apply (elim disjE; elim bexE)
    apply (case_tac x)
     apply (fastforce simp: ltl_semantics)
    apply (rule_tac x="(L,R)" in bexI, clarsimp, fastforce)
   apply (rule_tac x="(L,R)" in bexI, clarsimp, fastforce)
  apply (auto simp: until_iff_def ltl_semantics)
  done

lemma bcovers_alt_until':
  "\<lbrakk> True\<^sub>l \<in> set (map snd gs); gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> until_iff' gs fs G F bcovers\<^sup>* G \<U> F"
  apply (drule (1) bcovers_alt_until)
  apply (erule bcovers_weaken)
  apply (rule_tac x="(L,R)" in bexI; fastforce simp: until_iff_def until_iff'_def)
  done

lemma bcovers_until':
  "\<lbrakk> True\<^sub>l \<in> set (map snd gs); gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> until_iff' gs fs G F bcovers\<^sup>+ G \<U> F"
  apply (drule (1) bcovers_until)
  apply (erule bcovers_weaken)
  apply (rule_tac x="(L,R)" in bexI; fastforce simp: LTL_Cover_Weak.until_iff_def until_iff'_def)
  done

lemma bcovers_alt_release:
  "\<lbrakk> gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> release_iff fs gs F G bcovers\<^sup>* F \<R> G"
  apply (rule bcovers_altI)
  apply (clarsimp simp:)
  apply (drule (1) LTL_Cover_Weak.bcovers_release, clarsimp)
  apply (auto simp: release_iff_def ltl_semantics)
  done

(*****************************************************************)

lemma pcovers_altI:
  "fs pcovers\<^sup>+ F \<and> (\<forall>ys. (ys, 0) \<Turnstile> F \<longrightarrow> (\<exists>(L, R)\<in>set fs. (<>, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R)) \<Longrightarrow> fs pcovers\<^sup>* F"
  apply (clarsimp simp: pcovers_defs)
  by (metis lappend_code(1) llist.collapse(1))

lemma pcovers_nil_iff:
  "[] pcovers\<^sup>+ F = (\<forall>xs. \<not>lnull xs \<longrightarrow> \<not>(xs,0) \<Turnstile> F)"
   apply (auto simp: pcovers_defs)
  by (metis lappend_code(1) lappend_snocL1_conv_LCons2 lfinite_LCons lfinite_LNil not_lnull_conv)


lemma pcovers_alt_globally:
  "gs pcovers\<^sup>+ G \<Longrightarrow> (LTL_Cover_Finite.globally_iff gs G) pcovers\<^sup>* (\<box>G)"
  apply (rule pcovers_altI)
  apply (drule pcovers_globally)
  apply (rule conjI)
    apply (erule pcovers_weaken)
   apply (fastforce simp: plist_defs)
  apply (clarsimp simp: plist_defs ltl_semantics)
  using nil_in_pow_list by force

lemma lnull_globally[simp]:
  "(<>, 0) \<Turnstile> \<box>P"
  by (simp add: ltl_semantics)

lemma pcovers_alt_globally':
  "\<lbrakk> True\<^sub>l \<in> set (map snd gs); gs pcovers\<^sup>+ G \<rbrakk> \<Longrightarrow> (globally_iff gs G) pcovers\<^sup>* (\<box>G)"
  apply (rule pcovers_altI)
  apply (drule pcovers_globally)
  apply clarsimp
  apply (drule one_in_pow_list)
  apply (clarsimp simp: plist_defs ltl_conj_def)
  apply (rule rev_bexI, fastforce)
  apply simp
  done

lemma
  "[(\<box>(\<Or>\<^sub>l map fst ps), \<box>G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> [[]]] = TODO"
  apply simp
  oops

lemma pcovers_alt_finally:
  "fs pcovers\<^sup>+ F \<Longrightarrow> (finally_iff fs F) pcovers\<^sup>* (\<diamond>F)"
  apply (rule pcovers_altI)
  apply (drule pcovers_finally)
  apply (clarsimp simp: plist_defs ltl_semantics)
  done


lemma pcovers_weaken':
  "\<lbrakk> fs pcovers\<^sup>+ F; \<And>xs ys L R. \<lbrakk> lfinite xs; \<not>lnull xs; (L,R) \<in> set fs; (xs,0) \<Turnstile> L \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l; (ys,0) \<Turnstile> R \<rbrakk>
                                 \<Longrightarrow> \<exists>(L',R') \<in> set fs'. (xs,0) \<Turnstile> L' \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l \<and> (ys,0) \<Turnstile> R' \<rbrakk>
     \<Longrightarrow> fs' pcovers\<^sup>+ F"
  apply (auto simp: pcovers_defs split_def ltl_semantics)
  by (metis le_zero_eq llength_eq_0 prod.collapse zero_enat_def)


lemma pow_list_nil:
  "pow_list gs = [] # filter ((\<noteq>) []) (pow_list gs)"
  by (induct gs; clarsimp)

lemma set_until_iff:
  "set (until_iff gs fs G F) =
     \<comment> \<open>Immediate satisfaction\<close>
     set ([(L' \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l, R'). (L',R') \<leftarrow> fs]) \<union>
     \<comment> \<open>Satisfaction on LHS\<close>
     set ([((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L',R') \<leftarrow> fs]) \<union>
     \<comment> \<open>Satisfaction on RHS\<close>
     set ([(\<box>(\<Or>\<^sub>l map fst ps), G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []])"
  apply (unfold until_iff_def)
  apply (subst pow_list_nil)
  apply (simp add: False_Until_F)
  apply auto
  done

lemma bexI1:
  "\<exists>x \<in> X. P x \<Longrightarrow> \<exists>x \<in> (X \<union> Y). P x"
  by blast

lemma bexI2:
  "\<exists>x \<in> Y. P x \<Longrightarrow> \<exists>x \<in> (X \<union> Y). P x"
  by blast

lemma pcovers_until_helper:
  "\<lbrakk> gs pcovers\<^sup>+ G; fs pcovers\<^sup>+ F \<rbrakk>
  \<Longrightarrow> until_iff gs fs G F pcovers\<^sup>+ G \<U> F"
  apply (drule (1) pcovers_until)
  apply (erule pcovers_weaken)
  apply (clarsimp simp: plist_defs)
  apply (elim disjE)
  apply (subst set_until_iff)
    apply (rule bexI1)+
    apply clarsimp
    apply (erule rev_bexI; clarsimp simp: ltl_semantics enat_0)
   apply (subst set_until_iff)
   apply (rule bexI1)
   apply (rule bexI2)
   apply clarsimp
   apply (rule_tac x=x in bexI)
    apply (erule rev_bexI)
    apply (clarsimp simp: ltl_semantics)
   apply clarsimp
  apply (subst set_until_iff)
  apply (rule bexI2)
  apply clarsimp
  apply (rule_tac x=x in bexI)
   apply (clarsimp simp: ltl_semantics)
   apply clarsimp
  done

lemma
  "\<lbrakk>gs pcovers\<^sup>+ G; fs pcovers\<^sup>+ F; gs \<noteq> []\<rbrakk>
  \<Longrightarrow> until_iff gs fs G F pcovers\<^sup>* G \<U> F"
  apply (rule pcovers_altI)
  apply (drule (1) pcovers_until_helper)
  apply clarsimp
  apply (subst set_until_iff)
  apply (rule bexI2)
  apply clarsimp
  oops

lemma
  "\<lbrakk>gs pcovers\<^sup>+ G; fs pcovers\<^sup>+ F\<rbrakk>
  \<Longrightarrow> LTL_Cover_Weak.until_iff gs fs G F pcovers\<^sup>* G \<U> F"
  apply (rule pcovers_altI)
  apply (drule (1) pcovers_until)
  apply clarsimp
  apply (subst plist_defs)
  apply (clarsimp simp: split_def)
  apply (clarsimp simp: plist_defs)
  oops

lemma \<comment> \<open>sanity check\<close>
  "[(\<box>\<A>(C), \<box>\<A>(C))] pcovers\<^sup>* \<box>\<A>(C)"
  apply (rule pcovers_subst)
   apply (rule pcovers_alt_globally'[rotated])
    apply (rule pcovers_atom)
   apply simp
  apply (simp add: plist_defs)
  done

(*****************************************************************)

(* FIXME ryanb: add weak/strong variants of the bind rules *)

definition until_iffL where
  "until_iffL gs fs G F \<equiv>
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs]"

definition until_iffL' where
  "until_iffL' gs fs G F \<equiv>
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L',R') \<leftarrow> fs]"

definition until_iffR where
  "until_iffR gs fs G F \<equiv>
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps), G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]"

named_theorems bcoversL
named_theorems bcoversR

lemma bcovers_alt_untilL'[bcoversL]:
  "\<lbrakk> True\<^sub>l \<in> set (map snd gs); gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> until_iffL' gs fs G F bcovers\<^sup>* G \<U> F"
  apply (drule (2) bcovers_alt_until'[rotated])
  apply (unfold until_iff'_def until_iffL'_def)
  apply (erule bcovers_appendD1)
  done

lemma bcovers_alt_untilL[bcoversL]:
  "\<lbrakk> gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> until_iffL gs fs G F bcovers\<^sup>* G \<U> F"
  apply (drule (1) bcovers_alt_until)
  apply (unfold until_iff_def until_iffL_def)
  apply (erule bcovers_appendD1)
  done

lemma bcovers_alt_untilR[bcoversR]:
  "\<lbrakk> gs bcovers\<^sup>+ G; fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> until_iffR gs fs G F bcovers\<^sup>* G \<U> F"
  apply (drule (1) bcovers_alt_until)
  apply (unfold until_iff_def until_iffR_def)
  apply (erule bcovers_appendD2)
  done

definition finally_iffL where
  "finally_iffL fs F \<equiv> [(\<diamond>L, R). (L,R) \<leftarrow> fs]"

definition finally_iffR where
  "finally_iffR fs F \<equiv> [(True\<^sub>l,\<diamond>F) ]"

lemma bcovers_alt_finallyL[bcoversL]:
  "fs bcovers\<^sup>+ F \<Longrightarrow> (finally_iffL fs F) bcovers\<^sup>* \<diamond>F"
  apply (drule bcovers_alt_finally)
  apply (unfold finally_iff_def finally_iffL_def)
  apply (rule bcovers_appendD2)
  apply (subst append_Cons)
  apply (subst append_Nil)
  apply simp
  done

lemma bcovers_alt_finallyR[bcoversR]:
  "fs bcovers\<^sup>+ F \<Longrightarrow> (finally_iffR fs F) bcovers\<^sup>* \<diamond>F"
  apply (drule bcovers_alt_finally)
  apply (unfold finally_iff_def finally_iffR_def)
  apply (rule bcovers_appendD1)
  apply simp
  done

declare bcovers_atom[bcoversL]
declare bcovers_globally[bcoversL]
declare bcovers_globally[bcoversR]

(*****************************************************************)

(* FIXME ryanb: move *)
lemma bcovers_True:
  "[(True\<^sub>l,True\<^sub>l)] bcovers True\<^sub>l"
  "[(True\<^sub>l,True\<^sub>l)] bcovers\<^sup>+ True\<^sub>l"
  "[(True\<^sub>l,True\<^sub>l)] bcovers\<^sup>* True\<^sub>l"
  by (auto intro: bcoversI)

(* FIXME ryanb: move *)
lemma pcovers_True:
  "[(True\<^sub>l,True\<^sub>l)] pcovers True\<^sub>l"
  "[(True\<^sub>l,True\<^sub>l)] pcovers\<^sup>+ True\<^sub>l"
  "[(True\<^sub>l,True\<^sub>l)] pcovers\<^sup>* True\<^sub>l"
  by (auto intro: pcoversI)


named_theorems ptac_triv
lemmas [ptac_triv] =
  bcovers_triv
  pcovers_triv
  covers_triv

named_theorems ptac_unsafe
lemmas [ptac_unsafe] =
  bcovers_alt_until'
  bcovers_until'
  pcovers_alt_globally'

named_theorems ptac_safe
lemmas [ptac_safe] =
  bcovers_alt_until
  bcovers_alt_release
  bcovers_alt_finally
  bcovers_alt_globally
  pcovers_alt_globally
  pcovers_alt_finally
  bcovers_True
  pcovers_True
  prules
  bcovers_disj
  bcovers_disjI1
  bcovers_disjI2

named_theorems ptac_simps
lemmas [ptac_simps] =
  until_iff_def
  until_iff'_def
  until_iffL_def
  until_iffL'_def
  until_iffR_def
  finally_iffL_def
  finally_iffR_def
  plist_defs

named_theorems ptac_subst
lemmas [ptac_subst] =
  bcovers_subst
  pcovers_subst
  covers_subst

named_theorems ptac_wp
lemmas [ptac_wp] =
  bcovers_weaken
  pcovers_weaken
  covers_weaken

method partition_tactic declares ptac_safe ptac_unsafe ptac_simps =
   solves \<open>(erule ptac_triv)
           | (rule ptac_unsafe; (partition_tactic | solves \<open>clarsimp simp: ptac_simps\<close>))
           | (rule ptac_safe; partition_tactic)
           | rule bcovers_False\<close>

method ptac declares ptac_simps ptac_subst ptac_wp =
  ( (rule ptac_subst, partition_tactic, solves \<open>(clarsimp simp: ptac_simps)?; rule refl\<close>)
    | (rule ptac_wp, rule ptac_subst, partition_tactic, solves \<open>(clarsimp simp: ptac_simps)?; rule refl\<close>
      , (solves clarsimp)?)
  )[1]


lemma \<comment> \<open>deleteme: test\<close>
  "[(\<box>\<A>(P), \<box>\<A>(P))] bcovers\<^sup>+ \<box>\<A>(P)"
  by ptac

lemma \<comment> \<open>deleteme: test\<close>
  "[(\<A>(G) \<U> \<A>(F), True\<^sub>l), (\<box>\<A>(G), \<A>(G) \<U> \<A>(F))] bcovers\<^sup>* \<A>(G) \<U> \<A>(F)"
  by ptac


method partition_tacticL declares bcoversL =
   solves \<open>(rule bcoversL; (partition_tactic | solves \<open>clarsimp simp: ptac_simps\<close>))\<close>

method ptacL declares ptac_simps ptac_subst ptac_wp =
  ( (rule ptac_subst, partition_tacticL, solves \<open>clarsimp simp: ptac_simps; rule refl\<close>)
    | (rule ptac_wp, rule ptac_subst, partition_tacticL, solves \<open>clarsimp simp: ptac_simps; rule refl\<close>
      , (solves clarsimp)?)
  )[1]

method partition_tacticR declares bcoversR =
   solves \<open>(rule bcoversR; (partition_tactic | solves \<open>clarsimp simp: ptac_simps\<close>))\<close>

method ptacR declares ptac_simps ptac_subst ptac_wp =
  ( (rule ptac_subst, partition_tacticR, solves \<open>clarsimp simp: ptac_simps; rule refl\<close>)
    | (rule ptac_wp, rule ptac_subst, partition_tacticR, solves \<open>clarsimp simp: ptac_simps; rule refl\<close>
      , (solves clarsimp)?)
  )[1]

lemma \<comment> \<open>deleteme: test\<close>
  "[(\<A>(G) \<U> \<A>(F), True\<^sub>l)] bcovers\<^sup>* \<A>(G) \<U> \<A>(F)"
  by ptacL

lemma \<comment> \<open>deleteme: test\<close>
  "[(\<box>\<A>(G), \<A>(G) \<U> \<A>(F))] bcovers\<^sup>* \<A>(G) \<U> \<A>(F)"
  by ptacR

lemma \<comment> \<open>deleteme: test\<close>
  "[(\<diamond>\<A>(F), True\<^sub>l)] bcovers\<^sup>* \<diamond>\<A>(F)"
  by ptacL

lemma \<comment> \<open>deleteme: test\<close>
  "[(True\<^sub>l, \<diamond>\<A>(F))] bcovers\<^sup>* \<diamond>\<A>(F)"
  by ptacR

end
