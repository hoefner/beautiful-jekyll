(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory LTL_Setup
imports
  Trace.Trace_Toplevel
  Eisbach_Tools.Eisbach_Methods
  Coinductive.Coinductive_List
begin

lemmas less_def = less_eq [symmetric]
lemmas le_def = not_less [symmetric, where ?'a = nat]

lemma ex_least_nat_ge:
  "\<lbrakk> P (n :: nat); m \<le> n \<rbrakk>
     \<Longrightarrow> \<exists>i. m \<le> i \<and> i \<le> n \<and> P i \<and> (\<forall>j. m \<le> j \<and> j < i \<longrightarrow> \<not> P j)"
  by (induct n rule: nat_less_induct) (metis linorder_not_less)

lemma ex_greatest_nat_le:
  "\<lbrakk> P (n :: nat); n \<le> m \<rbrakk>
     \<Longrightarrow> \<exists>i. n \<le> i \<and> i \<le> m \<and> P i \<and> (\<forall>j. i < j \<and> j \<le> m \<longrightarrow> \<not> P j)"
  apply (induct m; clarsimp)
  apply (case_tac "n = Suc m", fastforce)
  apply (case_tac "P (Suc m)"; clarsimp)
   apply (rule_tac x="Suc m" in exI, clarsimp)
  apply (rule_tac x="i" in exI, fastforce simp: le_Suc_eq)
  done

end