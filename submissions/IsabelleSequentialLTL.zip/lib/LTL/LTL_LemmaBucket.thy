(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory LTL_LemmaBucket
imports
  LTL_Drop
begin

\<comment> \<open>Equality lemmas\<close>

lemma ltl_not_not:
  "\<not>\<^sub>l\<not>\<^sub>lP = P"
  by (auto simp: ltl_eq ltl_semantics)

lemma dual_until:
  "\<not>\<^sub>l(P \<U> Q) = \<not>\<^sub>lP \<R> \<not>\<^sub>lQ"
  by (auto intro: ltl_eqI simp: ltl_semantics)

lemma dual_release:
  "\<not>\<^sub>l(P \<R> Q) = \<not>\<^sub>lP \<U> \<not>\<^sub>lQ"
  by (metis ltl_not_not dual_until)

lemma dual_globally:
  "\<not>\<^sub>l\<box>P = \<diamond>\<not>\<^sub>lP"
  by (auto simp: ltl_eq ltl_semantics)

lemma dual_finally:
  "\<not>\<^sub>l\<diamond>P = \<box>\<not>\<^sub>lP"
  by (auto simp: ltl_eq ltl_semantics)

(* FIXME ryanb: less redundancy *)
named_theorems ltl_nnf

lemma [ltl_nnf]:
  "\<not>\<^sub>l\<not>\<^sub>lP = P"
  "\<not>\<^sub>l(P \<and>\<^sub>l Q) = \<not>\<^sub>lP \<or>\<^sub>l \<not>\<^sub>lQ"
  "\<not>\<^sub>l(P \<or>\<^sub>l Q) = \<not>\<^sub>lP \<and>\<^sub>l \<not>\<^sub>lQ"
  "\<not>\<^sub>l(P \<longrightarrow>\<^sub>l Q) = P \<and>\<^sub>l \<not>\<^sub>lQ"
  "\<not>\<^sub>l\<circle>P = \<ominus>\<not>\<^sub>lP"
  "\<not>\<^sub>l\<ominus>P = \<circle>\<not>\<^sub>lP"
  "\<not>\<^sub>l\<diamond>P = \<box>\<not>\<^sub>lP"
  "\<not>\<^sub>l\<box>P = \<diamond>\<not>\<^sub>lP"
  "\<not>\<^sub>l(P \<U> Q) = \<not>\<^sub>lP \<R> \<not>\<^sub>lQ"
  "\<not>\<^sub>l(P \<R> Q) = \<not>\<^sub>lP \<U> \<not>\<^sub>lQ"
  by (auto simp: dual_until dual_release ltl_eq ltl_semantics)

lemma ltl_conj_absorb:
  "P \<and>\<^sub>l P = P"
  by (fastforce simp: ltl_eq ltl_semantics)

lemma ltl_conj_commute:
  "P \<and>\<^sub>l Q = Q \<and>\<^sub>l P"
  by (fastforce simp: ltl_eq ltl_semantics)

lemma ltl_conj_left_commute:
  "P \<and>\<^sub>l Q \<and>\<^sub>l R = Q \<and>\<^sub>l P \<and>\<^sub>l R"
  by (fastforce simp: ltl_eq ltl_semantics)

lemma ltl_conj_assoc:
  "(P \<and>\<^sub>l Q) \<and>\<^sub>l R = P \<and>\<^sub>l Q \<and>\<^sub>l R"
  by (fastforce simp: ltl_eq ltl_semantics)

lemmas ltl_conj_ac = ltl_conj_commute ltl_conj_left_commute ltl_conj_assoc

lemma ltl_disj_absorb:
  "P \<or>\<^sub>l P = P"
  by (fastforce simp: ltl_eq ltl_semantics)

lemma ltl_disj_commute:
  "P \<or>\<^sub>l Q = Q \<or>\<^sub>l P"
  by (fastforce simp: ltl_eq ltl_semantics)

lemma ltl_disj_left_commute:
  "P \<or>\<^sub>l Q \<or>\<^sub>l R = Q \<or>\<^sub>l P \<or>\<^sub>l R"
  by (fastforce simp: ltl_eq ltl_semantics)

lemma ltl_disj_assoc:
  "(P \<or>\<^sub>l Q) \<or>\<^sub>l R = P \<or>\<^sub>l Q \<or>\<^sub>l R"
  by (fastforce simp: ltl_eq ltl_semantics)

lemmas ltl_disj_ac = ltl_disj_commute ltl_disj_left_commute ltl_disj_assoc

lemma ltl_imp_conv_disj:
  "P \<longrightarrow>\<^sub>l Q = \<not>\<^sub>lP \<or>\<^sub>l Q"
  by (auto simp: ltl_eq ltl_semantics)

lemma ltl_disj_imp:
  "P \<or>\<^sub>l Q = \<not>\<^sub>lP \<longrightarrow>\<^sub>l Q"
  by (auto simp: ltl_eq ltl_semantics)

lemma ltl_not_atom:
  "\<not>\<^sub>l\<A>(P) = \<A>(not P)"
  by (rule ltl_eqI, simp add: ltl_semantics)

lemmas ltl_atom_not = ltl_not_atom[symmetric]


\<comment> \<open>Deduction rules\<close>

(* FIXME ryanb: reduce boilerplating *)

named_theorems ltl_intros
named_theorems ltl_elims

lemma ltl_globallyI':
  "\<lbrakk> \<And>i. \<lbrakk> n \<le> i; enat i < llength ts \<rbrakk> \<Longrightarrow> (ts,i) \<Turnstile> P \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> \<box>P"
  by (auto simp: ltl_semantics)

lemmas ltl_globallyI[ltl_intros] =
  ltl_globallyI'
  ltl_globallyI'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_globallyI'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_globallyD':
  "\<lbrakk> (ts,n) \<Turnstile> \<box>P; n \<le> i; i < llength ts \<rbrakk>
     \<Longrightarrow> (ts,i) \<Turnstile> P"
  by (fastforce simp: ltl_semantics)

lemmas ltl_globallyD =
  ltl_globallyD'
  ltl_globallyD'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_globallyD'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemmas ltl_globallyE = ltl_globallyD[elim_format]

lemma ltl_finallyI':
  "\<lbrakk> n \<le> i; i < llength ts; (ts,i) \<Turnstile> P \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> \<diamond>P"
  by (fastforce simp: ltl_semantics)

lemmas ltl_finallyI =
  ltl_finallyI'
  ltl_finallyI'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_finallyI'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_finallyE':
  "\<lbrakk> (ts,n) \<Turnstile> \<diamond>P; \<And>i. \<lbrakk> n \<le> i; i < llength ts; (ts,i) \<Turnstile> P \<rbrakk> \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  by (fastforce simp: ltl_semantics)

lemmas ltl_finallyE[ltl_elims] =
  ltl_finallyE'
  ltl_finallyE'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_finallyE'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_conjI':
  "\<lbrakk> (ts,n) \<Turnstile> P; (ts,n) \<Turnstile> Q \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> P \<and>\<^sub>l Q"
  by (fastforce simp: ltl_semantics)

lemmas ltl_conjI[ltl_intros] =
  ltl_conjI'
  ltl_conjI'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_conjI'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_conjE':
  "\<lbrakk> (ts,n) \<Turnstile> P \<and>\<^sub>l Q; \<lbrakk> (ts,n) \<Turnstile> P; (ts,n) \<Turnstile> Q \<rbrakk> \<Longrightarrow>R \<rbrakk>
     \<Longrightarrow> R"
  by (fastforce simp: ltl_semantics)

lemmas ltl_conjE[ltl_elims] =
  ltl_conjE'
  ltl_conjE'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_conjE'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_disjI1':
  "\<lbrakk> (ts,n) \<Turnstile> \<not>\<^sub>lQ \<Longrightarrow> (ts,n) \<Turnstile> P \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> P \<or>\<^sub>l Q"
  by (fastforce simp: ltl_semantics)

lemmas ltl_disjI1 =
  ltl_disjI1'
  ltl_disjI1'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_disjI1'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_disjI2':
  "\<lbrakk> (ts,n) \<Turnstile> \<not>\<^sub>lP \<Longrightarrow> (ts,n) \<Turnstile> Q \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> P \<or>\<^sub>l Q"
  by (fastforce simp: ltl_semantics)

lemmas ltl_disjI2 =
  ltl_disjI2'
  ltl_disjI2'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_disjI2'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_disjE':
  "\<lbrakk> (ts,n) \<Turnstile> P \<or>\<^sub>l Q; (ts,n) \<Turnstile> P \<Longrightarrow> R; (ts,n) \<Turnstile> Q \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  by (fastforce simp: ltl_semantics)

lemmas ltl_disjE =
  ltl_disjE'
  ltl_disjE'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_disjE'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_impI':
  "\<lbrakk> (ts,n) \<Turnstile> P \<Longrightarrow> (ts,n) \<Turnstile> Q \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> P \<longrightarrow>\<^sub>l Q"
  by (fastforce simp: ltl_semantics)

lemmas ltl_impI[ltl_intros] =
  ltl_impI'
  ltl_impI'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_impI'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_impE':
  "\<lbrakk> (ts,n) \<Turnstile> P \<longrightarrow>\<^sub>l Q; (ts,n) \<Turnstile> P; (ts,n) \<Turnstile> Q \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  by (fastforce simp: ltl_semantics)

lemmas ltl_impE =
  ltl_impE'
  ltl_impE'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_impE'[where ts="llist_of_stream ts" for ts, simplified from_ltl]


\<comment> \<open>Misc\<close>

lemma finally_imp_not_until:
  "(ts,n) \<Turnstile> \<diamond>L \<Longrightarrow> (ts,n) \<Turnstile> \<not>\<^sub>lL \<U> L"
  apply (clarsimp simp: ltl_semantics)
  apply (drule (1) ex_least_nat_ge[where P="\<lambda>j. (ts, j) \<Turnstile> L"])
  apply (fastforce simp: order_le_less_subst2)
  done

lemma until_implies_finally:
  "(ts,n) \<Turnstile> P \<U> Q \<Longrightarrow> (ts,n) \<Turnstile> \<diamond>Q"
  by (fastforce simp: ltl_semantics)

lemma finally_now:
  "\<lbrakk> (ts,n) \<Turnstile> P; n < llength ts \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> \<diamond>P"
  by (fastforce simp: ltl_semantics)

lemma until_now:
  "\<lbrakk> (ts,n) \<Turnstile> Q; n < llength ts \<rbrakk>
     \<Longrightarrow> (ts,n) \<Turnstile> P \<U> Q"
  by (fastforce simp: ltl_semantics)

lemma until_def2:
  "(ts,i) \<Turnstile> P \<U> Q = (\<exists>j. i \<le> j \<and> j < llength ts \<and> (\<forall>k. i + k < j \<longrightarrow> (ts,i + k) \<Turnstile> P) \<and> (ts,j) \<Turnstile> Q)"
  by (auto simp: ltl_semantics dest: le_Suc_ex)

lemma ltl_untilE:
  assumes "(ts,n) \<Turnstile> P \<U> Q"
  and "\<And>i. \<lbrakk> n \<le> i; i < llength ts; (ts,i) \<Turnstile> Q; \<forall>j. n \<le> j \<and> j < i \<longrightarrow> (ts,j) \<Turnstile> P \<rbrakk> \<Longrightarrow> R"
  shows R
  using assms by (fastforce simp: ltl_semantics)

lemma ltl_globally_globally[simp]:
  "\<box>\<box>P = \<box>P"
  by (fastforce intro: ltl_eqI simp: ltl_semantics)

lemma release_later:
  "\<lbrakk> (ts,i) \<Turnstile> Q \<R> P; \<forall>j < i. (ts,j) \<Turnstile> P \<rbrakk>
     \<Longrightarrow> (ts,0) \<Turnstile> Q \<R> P"
  by (auto simp: ltl_semantics le_def)

lemma release_later':
  "\<lbrakk> (xs,0) \<Turnstile> Q \<R> P; \<forall>j < i. \<not>(xs,j) \<Turnstile> Q \<rbrakk>
     \<Longrightarrow> (xs,i) \<Turnstile> Q \<R> P"
  by (auto simp: ltl_semantics le_def)

lemma release_init:
  "\<lbrakk> (ts,i) \<Turnstile> Q \<R> P; i < llength ts \<rbrakk> \<Longrightarrow> (ts,i) \<Turnstile> P"
  by (auto simp: ltl_semantics)

lemma globally_release:
  "\<box>(Q \<R> R) = \<box>R"
  apply (auto intro!: ltl_eqI ltl_intros)
  using ltl_globallyD release_init apply fastforce
  by (clarsimp simp: LTL_Release_def ltl_semantics)

(* FIXME ryanb: move *)
declare ltl_conjE[elim!]
declare ltl_impI[intro!]

thm ltl_release_def
thm ltl_until_def

lemma ltl_releaseD:
  assumes "(ts,n) \<Turnstile> Q \<R> P"
  shows "\<forall>j. n \<le> j \<and> enat j < llength ts \<and> (ts, j) \<Turnstile> \<not>\<^sub>lP
               \<longrightarrow> (\<exists>k \<ge> n. k < j \<and> (ts, k) \<Turnstile> Q)"
  using assms by (fastforce simp: ltl_semantics)

lemmas ltl_releaseE = ltl_releaseD[elim_format]

lemma ltl_untilI:
  assumes "(ts,j) \<Turnstile> Q"
  and "i \<le> j" and "j < llength ts"
  and "\<And>k. \<lbrakk> i \<le> j; j < llength ts; i \<le> k; k < j \<rbrakk> \<Longrightarrow> (ts,k) \<Turnstile> P"
  shows "(ts,i) \<Turnstile> P \<U> Q"
  using assms ltl_until_def by blast

lemma ltl_releaseI:
  assumes "\<And>j. \<lbrakk> n \<le> j; enat j < llength ts; (ts, j) \<Turnstile> \<not>\<^sub>l P;
                 \<forall>k. n \<le> k \<and> k < j \<longrightarrow> (ts, k) \<Turnstile> P \<rbrakk>
                 \<Longrightarrow> \<exists>k. n \<le> k \<and> k < j \<and> (ts, k) \<Turnstile> Q"
  shows "(ts,n) \<Turnstile> Q \<R> P"
  apply (insert assms)
  apply (subst ltl_release_def)
  apply (simp add: ltl_release_def imp_conjL)
  apply (rule allI)
  apply (rule impI)
  subgoal for j
    apply (induct "j-n" arbitrary: n j rule: nat_less_induct)
    apply (clarsimp simp: ltl_semantics)
    apply (smt (verit, del_insts) enat_ord_simps(2) le_add_diff_inverse2 less_diff_conv2 order.strict_trans)
    done
  done

lemma ltl_next_LNil:
  "(<>, i) \<Turnstile> \<circle>C = False"
  by (simp add: ltl_next_def)

lemma ltl_next_LCons:
  "(x ## xs, i) \<Turnstile> \<circle>C = (i < llength xs \<and> (xs,i) \<Turnstile> C)"
  apply (clarsimp simp: ltl_next_def)
  by (metis Suc_ile_eq eSuc_enat ldrop_eSuc_LCons ltl_drop_alt)

lemma ltl_weak_next_LNil:
  "(<>, i) \<Turnstile> \<ominus>C"
  by (simp add: ltl_weak_next_def)

lemma ltl_weak_next_LCons:
  "(x ## xs, i) \<Turnstile> \<ominus>C = (i < llength xs \<longrightarrow> (xs,i) \<Turnstile> C)"
  apply (clarsimp simp: ltl_weak_next_def)
  by (metis LTL_Drop.ltl_ldrop Suc_ile_eq cancel_comm_monoid_add_class.diff_cancel dual_order.refl ldrop_enat ldropn_Suc_LCons)


lemma ltl_globally_induct:
  assumes base: "i < llength ts \<Longrightarrow> (ts, i) \<Turnstile> G"
  and ih: "\<And>j. \<lbrakk> i + j < llength ts \<Longrightarrow> (ts, i + j) \<Turnstile> G;
                 i + Suc j < llength ts \<rbrakk>
                 \<Longrightarrow> (ts, i + Suc j) \<Turnstile> G"
  shows "(ts,i) \<Turnstile> \<box>G"
  apply (rule ltl_globallyI)
  apply (clarsimp simp: le_iff_add)
  subgoal for j using assms by (induct j; clarsimp)
  done

lemma ltli_globally_induct:
  assumes base: "(ts, i) \<tturnstile> G"
  and ih: "\<And>j. \<lbrakk> (ts, i + j) \<tturnstile> G \<rbrakk> \<Longrightarrow> (ts, i + Suc j) \<tturnstile> G"
  shows "(ts,i) \<tturnstile> \<box>G"
  using ltl_globally_induct[where ts="llist_of_stream ts" for ts, simplified from_ltl, OF base ih]
  by auto

abbreviation LTL_Meta_Implies ("_ \<Longrightarrow>\<^sub>l _" [81,80] 80) where
  "LTL_Meta_Implies P Q \<equiv> (\<And>ts i. (ts,i) \<Turnstile> P \<Longrightarrow> (ts,i) \<Turnstile> Q)"

lemma globally_implies_release:
  "\<box>P \<Longrightarrow>\<^sub>l Q \<R> P"
  by (simp add: LTL_Release_def ltl_disj_def)

lemma ltl_swap:
  "\<lbrakk> tr \<Turnstile> \<not>\<^sub>lR; tr' \<Turnstile> P \<Longrightarrow> tr \<Turnstile> R\<rbrakk> \<Longrightarrow> tr' \<Turnstile> \<not>\<^sub>lP"
  by (metis ltl_not_def surj_pair)


lemma ltl_dnf:
  "(P \<and>\<^sub>l (Q \<or>\<^sub>l R)) = ((P\<and>\<^sub>lQ) \<or>\<^sub>l (P\<and>\<^sub>lR))"
  "((Q \<or>\<^sub>l R) \<and>\<^sub>l P) = ((Q\<and>\<^sub>lP) \<or>\<^sub>l (R\<and>\<^sub>lP))"
  "(P \<and>\<^sub>l Q) = (Q \<and>\<^sub>l P)"
  "(P \<or>\<^sub>l Q) = (Q \<or>\<^sub>l P)"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma ltl_cnf:
  "(P \<or>\<^sub>l (Q \<and>\<^sub>l R)) = ((P\<or>\<^sub>lQ) \<and>\<^sub>l (P\<or>\<^sub>lR))"
  "((Q \<and>\<^sub>l R) \<or>\<^sub>l P) = ((Q\<or>\<^sub>lP) \<and>\<^sub>l (R\<or>\<^sub>lP))"
  "(P \<or>\<^sub>l Q) = (Q \<or>\<^sub>l P)"
  "(P \<and>\<^sub>l Q) = (Q \<and>\<^sub>l P)"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma ltl_demorgan_absorbs[simp]:
  "(P \<or>\<^sub>l Q) \<and>\<^sub>l P = P"
  "(P \<or>\<^sub>l Q) \<and>\<^sub>l Q = Q"
  "P \<and>\<^sub>l (P \<or>\<^sub>l Q) = P"
  "Q \<and>\<^sub>l (P \<or>\<^sub>l Q) = Q"
  "(P \<and>\<^sub>l Q) \<or>\<^sub>l P = P"
  "(P \<and>\<^sub>l Q) \<or>\<^sub>l Q = Q"
  "P \<or>\<^sub>l (P \<and>\<^sub>l Q) = P"
  "Q \<or>\<^sub>l (P \<and>\<^sub>l Q) = Q"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma until_absorb_globally:
  "\<box>G \<U> F \<and>\<^sub>l \<box>G = \<box>G \<and>\<^sub>l \<diamond>F"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

end