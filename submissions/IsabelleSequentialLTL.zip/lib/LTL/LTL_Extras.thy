(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory LTL_Extras
imports
  LTL_LemmaBucket
begin

definition LTL_True ("True\<^sub>l") where
  "True\<^sub>l \<equiv> \<box>\<A>(\<top>)"

definition LTL_False ("False\<^sub>l") where
  "False\<^sub>l \<equiv> \<not>\<^sub>lTrue\<^sub>l"

lemma ltl_true_def[simp]: "(xs,i) \<Turnstile> True\<^sub>l"
  and ltl_false_def[simp]: "\<not>(xs,i) \<Turnstile> False\<^sub>l"
  unfolding LTL_True_def LTL_False_def
  by (auto simp: ltl_semantics)

lemma [ltl_nnf]:
  "\<not>\<^sub>lTrue\<^sub>l = False\<^sub>l"
  "\<not>\<^sub>lFalse\<^sub>l = True\<^sub>l"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma ltl_true_simps[simp]:
  "P \<and>\<^sub>l True\<^sub>l = P"
  "True\<^sub>l \<and>\<^sub>l P = P"
  "P \<or>\<^sub>l True\<^sub>l = True\<^sub>l"
  "True\<^sub>l \<or>\<^sub>l P = True\<^sub>l"
  "True\<^sub>l \<longrightarrow>\<^sub>l P = P"
  "P \<longrightarrow>\<^sub>l True\<^sub>l = True\<^sub>l"
  "\<box>True\<^sub>l = True\<^sub>l"
  by (auto intro: ltl_eqI simp: ltl_semantics)

lemma ltl_false_simps[simp]:
  "P \<and>\<^sub>l False\<^sub>l = False\<^sub>l"
  "False\<^sub>l \<and>\<^sub>l P = False\<^sub>l"
  "P \<or>\<^sub>l False\<^sub>l = P"
  "False\<^sub>l \<or>\<^sub>l P = P"
  "False\<^sub>l \<longrightarrow>\<^sub>l P = True\<^sub>l"
  "P \<longrightarrow>\<^sub>l False\<^sub>l = \<not>\<^sub>lP"
  by (auto intro!: ltl_eqI simp: ltl_semantics)


(* FIXME ryanb: use lifting *)
lemma ltlf_TrueI[simp]:
  "(xs,i) \<turnstile> True\<^sub>l"
  by (auto simp: LTL_True_def ltl_semantics)

(* FIXME ryanb: use lifting *)
lemma ltl_TrueI[simp]:
  "(xs,i) \<tturnstile> True\<^sub>l"
  by (auto simp: LTL_True_def ltl_semantics)

lemma ltl_finally_def2:
  "\<diamond>P = True\<^sub>l \<U> P"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma ltl_globally_def2:
  "\<box>G = (False\<^sub>l \<R> G)"
  by (auto intro!: ltl_eqI simp: ltl_semantics)


definition LTL_Null ("null\<^sub>l") where
  "null\<^sub>l \<equiv> \<not>\<^sub>l\<diamond>True\<^sub>l"

definition LTL_One ("one\<^sub>l") where
  "one\<^sub>l \<equiv> \<diamond>\<A>(\<top>) \<and>\<^sub>l \<ominus>\<A>(\<bottom>)"

lemma ltl_null_def[ltl_semantics]: "(ts,n) \<Turnstile> null\<^sub>l = (llength ts \<le> n)"
  and ltl_one_def[ltl_semantics]: "(ts,n) \<Turnstile> one\<^sub>l = (llength ts = Suc n)"
  apply (auto simp: LTL_Null_def LTL_One_def ltl_semantics enat_0_iff)
  using order_subst1 apply fastforce
  by (metis Suc_ile_eq enat_ord_simps(1) order_le_imp_less_or_eq order_le_less_trans)


definition LTL_Finite ("finite\<^sub>l") where
  "LTL_Finite \<equiv> \<box>\<diamond>\<ominus>False\<^sub>l"

abbreviation LTL_Infinite ("infinite\<^sub>l") where
  "infinite\<^sub>l \<equiv> \<not>\<^sub>lfinite\<^sub>l"

lemma ltl_finite_def[ltl_semantics]: "(ts,n) \<Turnstile> finite\<^sub>l = lfinite ts"
  and ltl_infinite_def: "(ts,n) \<Turnstile> infinite\<^sub>l = (\<not>lfinite ts)"
proof -
  show "(ts, n) \<Turnstile> finite\<^sub>l = lfinite ts"
    apply (rule iffI)
     apply (clarsimp simp: LTL_Finite_def ltl_semantics)
     apply (meson enat_iless lfinite_conv_llength_enat linorder_less_linear order_refl)
    apply (induct ts rule: lfinite.induct)
     apply (clarsimp simp: LTL_Finite_def ltl_semantics)
    apply (clarsimp simp: LTL_Finite_def ltl_semantics)
    apply (metis eSuc_enat enat_ord_simps(1) iless_Suc_eq order_less_le)
    done
  then show "(ts,n) \<Turnstile> infinite\<^sub>l = (\<not>lfinite ts)"
    by (simp add: ltl_semantics)
qed


fun ltl_defined :: "nat \<Rightarrow> 'a ltl" where
  "ltl_defined 0 = (\<diamond>True\<^sub>l)"
| "ltl_defined (Suc n) = \<circle>(ltl_defined n)"

lemma ltl_defined_def[ltl_semantics]:
  "(ts,i) \<Turnstile> ltl_defined n = (n < llength (ldrop i ts))"
  apply (induct n arbitrary: ts i)
   apply (fastforce simp: ltl_semantics enat_0 leD order_subst1)
  apply (case_tac i; case_tac ts; case_tac "lfinite (ltl ts)")
  by (auto simp add: ltl_next_LNil ltl_next_LCons ldrop_enat lfinite_conv_llength_enat)


definition LTL_Opt ::  "'a ltl \<Rightarrow> 'a ltl" ("_?" [90] 89) where
  "P? \<equiv> P \<or>\<^sub>l null\<^sub>l"

definition LTL_The ::  "'a ltl \<Rightarrow> 'a ltl" ("_!" [90] 89) where
  "P! \<equiv> P \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l"

lemma ltl_opt_def[ltl_semantics]:
  "(ts,n) \<Turnstile> P? = (n < llength ts \<longrightarrow> (ts,n) \<Turnstile> P)"
  by (metis LTL_Opt_def linorder_not_le lnull_ldrop ltl_drop_alt ltl_null_def ltl_disj_def)

lemma ltlf_opt_def[ltl_semantics]:
  "(ts,n) \<turnstile> P? = (n < length ts \<longrightarrow> (ts,n) \<turnstile> P)"
  using ltl_opt_def[where ts="llist_of ts" for ts, simplified from_ltl]
  by auto

lemma ltl_the_def[ltl_semantics]:
  "(ts,n) \<Turnstile> P! = (n < llength ts \<and> (ts,n) \<Turnstile> P)"
  by (metis LTL_The_def linorder_not_less ltl_null_def ltl_conj_def ltl_not_def)

lemma ltlf_the_def[ltl_semantics]:
  "(ts,n) \<turnstile> P! = (n < length ts \<and> (ts,n) \<turnstile> P)"
  using ltl_the_def[where ts="llist_of ts" for ts, simplified from_ltl]
  by auto


fun stutter_closed where
  "stutter_closed (LTL_Atom\<^sub>0 P) = True"
| "stutter_closed (LTL_Conj\<^sub>0 P Q) = (stutter_closed P \<and> stutter_closed Q)"
| "stutter_closed (LTL_Not\<^sub>0 P) = stutter_closed P"
| "stutter_closed (LTL_Next\<^sub>0 P) = False"
| "stutter_closed (LTL_Until\<^sub>0 P Q) = (stutter_closed P \<and> stutter_closed Q)"

lemma llast_lappend:
  "lfinite xs \<Longrightarrow> llast (xs @@ <x>) = x"
  by simp

lemma
  "stutter_closed P
\<Longrightarrow> ts = xs@@<y>
\<Longrightarrow> i < llength ts
\<Longrightarrow> (ts,i) \<Turnstile>\<^sub>0 P = (ts@@<llast ts>,i) \<Turnstile>\<^sub>0 P"
  apply (case_tac "lfinite ts")
   prefer 2
  apply (simp add: lappend_inf)
  apply (induct ts i P arbitrary: xs y rule: ltl\<^sub>0_semantics_induct)
      apply clarsimp
      apply (simp add: lnth_lappend)
     apply (solves clarsimp)+
  apply (rule iffI)
   apply clarsimp
  apply (smt (verit, ccfv_SIG) enat_ord_simps(2) enat_trans_less_add1 order_less_imp_le order_less_le_subst2)
  apply (clarsimp simp: lappend_assoc)
  apply (case_tac "j < llength xs + eSuc 0")
   apply (smt (verit, ccfv_SIG) enat_ord_simps(2) enat_trans_less_add1 order_less_imp_le order_less_le_subst2)
  apply (clarsimp simp: not_less)
  apply (frule lfinite_ex_list, clarsimp)
  apply (clarsimp simp: add.commute eSuc_enat eSuc_plus)
  apply (prop_tac "j = Suc (length ys)")
   apply linarith
  apply clarsimp
  apply (prop_tac "(<y, y>, Suc 0) \<Turnstile>\<^sub>0 Q")
  apply (smt (z3) LTL_Drop.ltl_drop_append One_nat_def add.commute eSuc_enat enat_ord_simps(2) lessI llength_LCons llength_LNil ltl_semantics.abs_eq one_eSuc one_enat_def plus_1_eq_Suc)
  apply (rule_tac x="(length ys)" in exI)
  apply auto[1]
  apply (subgoal_tac "(<y>, 0) \<Turnstile>\<^sub>0 Q")
  apply (smt (verit, ccfv_threshold) LTL_Drop.ltl_drop_append add.commute add.right_neutral enat_ord_simps(2) lessI lfinite_llist_of llength_LCons llength_LNil llength_llist_of ltl_semantics.abs_eq one_eSuc one_enat_def plus_1_eq_Suc plus_enat_simps(1))
  apply (erule_tac x="length ys" in meta_allE)
  apply (erule_tac x="llist_of ys" in meta_allE)
  apply (erule_tac x="y" in meta_allE)
  apply clarsimp
  by (metis Extended_Nat.eSuc_mono add_nonneg_eq_0_iff enat_0 ldrop_eSuc_LCons le_numeral_extra(3) llength_LCons llength_LNil ltl_drop ltl_semantics.abs_eq one_eSuc one_enat_def plus_1_eSuc(1) plus_1_eq_Suc zero_less_one)


lemma ltl_not_null:
  "\<not>\<^sub>lnull\<^sub>l = \<diamond>True\<^sub>l"
  by (simp add: LTL_Null_def ltl_not_not)

abbreviation (input) LTL_Atom_Left ("\<A>\<^sup>L/'(_')") where
  "\<A>\<^sup>L(P) \<equiv> \<A>(\<lambda>(s,a,s'). P s)"

abbreviation (input) LTL_Atom_Right ("\<A>\<^sup>R/'(_')") where
  "\<A>\<^sup>R(P) \<equiv> \<A>(\<lambda>(s,a,s'). P s')"

lemma lconnected_atoms:
  "\<lbrakk> lconnected ts; Suc i < llength ts \<rbrakk> \<Longrightarrow>
     (ts,i) \<Turnstile> \<A>\<^sup>R(P) = (ts,Suc i) \<Turnstile> \<A>\<^sup>L(P)"
  apply (clarsimp simp: ltl_semantics lconnected_def split_def)
  by (metis Suc_ile_eq ldrop_enat lhd_ldropn order_less_imp_le)


(* FIXME ryanb: move or remove *)
definition LTL_Strong_Until ("_ \<M> _" [88,87] 87) where
  "P \<M> Q \<equiv> P \<U> (P \<and>\<^sub>l Q)"

definition LTL_Weak_Until ("_ \<W> _" [88,87] 87) where
  "P \<W> Q \<equiv> (P \<U> Q) \<or>\<^sub>l \<box>P"


definition LTL_Leadsto ("_ \<leadsto> _" [84,84] 83) where
  "P \<leadsto> Q \<equiv> \<box>(P \<longrightarrow>\<^sub>l \<diamond>Q)"

lemma ltl_leadsto_def[ltl_semantics]:
    "(ts,i) \<Turnstile> P \<leadsto> Q = (\<forall>j. i \<le> j \<and> j < llength ts \<and> (ts,j) \<Turnstile> P
                          \<longrightarrow> (\<exists>k. j \<le> k \<and> k < llength ts \<and> (ts,k) \<Turnstile> Q))"
  by (auto simp: LTL_Leadsto_def ltl_semantics)

lemma ltl_leadstoI':
  "(\<And>i. \<lbrakk> n \<le> i; i < llength ts; (ts,i) \<Turnstile> P \<rbrakk> \<Longrightarrow> (ts,i) \<Turnstile> \<diamond>Q)
     \<Longrightarrow> (ts,n) \<Turnstile> P \<leadsto> Q"
  by (fastforce simp: ltl_semantics)

lemmas ltl_leadstoI[ltl_intros] =
  ltl_leadstoI'
  ltl_leadstoI'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_leadstoI'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma ltl_leadstoE':
  "\<lbrakk> (ts,n) \<Turnstile> P \<leadsto> Q; n \<le> i; i < llength ts; (ts,i) \<Turnstile> P \<longrightarrow>\<^sub>l \<diamond>Q \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  by (fastforce simp: ltl_semantics)

lemmas ltl_leadstoE =
  ltl_leadstoE'
  ltl_leadstoE'[where ts="llist_of ts" for ts, simplified from_ltl]
  ltl_leadstoE'[where ts="llist_of_stream ts" for ts, simplified from_ltl]

lemma null_finite[simp]:
  "null\<^sub>l \<and>\<^sub>l finite\<^sub>l = null\<^sub>l"
  "finite\<^sub>l \<and>\<^sub>l null\<^sub>l = null\<^sub>l"
   apply (auto intro!: ltl_eqI simp: ltl_semantics)
  using enat_ile lfinite_conv_llength_enat by blast+

lemma False_Until_F:
  "False\<^sub>l \<U> F = (F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l)"
  apply (auto intro!: ltl_eqI simp: ltl_semantics)
    apply auto[1]
   apply (metis leD order_le_imp_less_or_eq order_refl)
  by (metis leD linorder_le_less_linear order_refl)

lemma globally_false_null[simp]:
  "\<box>False\<^sub>l = null\<^sub>l"
  by (simp add: LTL_False_def LTL_Globally_def LTL_Null_def ltl_not_not)

lemma G_null[simp]:
  "\<box>null\<^sub>l = null\<^sub>l"
  apply (auto intro!: ltl_eqI simp: ltl_semantics LTL_Null_def)
  by blast

lemma G_or_null[simp]:
  "\<box>(P \<or>\<^sub>l null\<^sub>l) = \<box>P"
  apply (auto intro!: ltl_eqI simp: ltl_semantics LTL_Null_def)
  by blast

lemma G_and_null[simp]:
  "\<box>(P \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l) = \<box>P"
  by (auto intro!: ltl_eqI simp: ltl_semantics LTL_Null_def)

lemma until_null_False[simp]:
  "P \<U> null\<^sub>l = False\<^sub>l"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma finally_null_False[simp]:
  "\<diamond>null\<^sub>l = False\<^sub>l"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma False_Until_The:
  "False\<^sub>l \<U> F = F!"
  unfolding LTL_The_def
  apply (auto intro!: ltl_eqI simp: ltl_semantics)
    apply auto[1]
   apply (metis leD order_le_imp_less_or_eq order_refl)
  by (metis leD linorder_le_less_linear order_refl)

lemma dual_the[ltl_nnf]: "\<not>\<^sub>l F! = (\<not>\<^sub>lF)?"
  and dual_opt[ltl_nnf]: "\<not>\<^sub>l F? = (\<not>\<^sub>lF)!"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma ltl_optD:
  "\<lbrakk> (ts,n) \<Turnstile> F?; n < llength ts \<rbrakk> \<Longrightarrow> (ts,n) \<Turnstile> F"
  using ltl_opt_def by blast

lemma ltl_theI:
  "\<lbrakk> (ts,n) \<Turnstile> F; n < llength ts \<rbrakk> \<Longrightarrow> (ts,n) \<Turnstile> F!"
  using ltl_the_def by blast

(**********************************************)

lemma next_conj:
  "\<circle>(P \<and>\<^sub>l Q) = \<circle>P \<and>\<^sub>l \<circle>Q"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma next_disj:
  "\<circle>(P \<or>\<^sub>l Q) = \<circle>P \<or>\<^sub>l \<circle>Q"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma next_the:
  "\<circle>P! = \<circle>P"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma weak_next_the:
  "\<ominus>P! = \<ominus>P"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

lemma weak_next_opt:
  "\<ominus>P? = \<ominus>P"
  by (auto intro!: ltl_eqI simp: ltl_semantics)

end
