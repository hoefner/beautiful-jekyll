theory LTL_Cover_Pre
imports LTL_Extras LTL_Lattice
begin

primrec pow_list :: "'a list \<Rightarrow> 'a list list" where
  "pow_list [] = [[]]"
| "pow_list (x#xs) = (pow_list xs) @ map ((#) x) (pow_list xs)"

lemma
  "set (pow_list []) = {[]}"
  "set (pow_list [a]) = {[], [a]}"
  "set (pow_list [a,b]) = {[], [a], [b], [a,b]}"
  "set (pow_list [a,b,c]) = {[], [a], [b], [c], [a,b], [a,c], [b,c], [a,b,c]}"
  by auto

lemma pow_list_un:
  "\<lbrakk> xs \<in> set (pow_list ps); ys \<in> set (pow_list ps) \<rbrakk>
     \<Longrightarrow> \<exists>zs \<in> set (pow_list ps). set zs = set xs \<union> set ys"
  apply (induct ps arbitrary: xs ys; clarsimp?)
  apply (elim disjE; clarsimp?)
  by (metis Un_iff imageI list.simps(15))+

lemma in_set_pow_list:
  "\<lbrakk> xs \<in> set (pow_list ps); x \<in> set xs \<rbrakk>
     \<Longrightarrow> x \<in> set ps"
  by (induct ps arbitrary: x xs; auto)

lemma nil_in_pow_list:
  "[] \<in> set (pow_list ps)"
  by (induct ps; clarsimp)

lemma one_in_pow_list:
  "x \<in> set ps \<Longrightarrow> [x] \<in> set (pow_list ps)"
  apply (induct ps arbitrary: x; clarsimp)
  using nil_in_pow_list by blast


lemma ltldropD:
  "\<lbrakk> (ldrop i xs @@ ys, 0) \<Turnstile> F; i < llength xs \<rbrakk>
  \<Longrightarrow> (xs @@ ys, the_enat i) \<Turnstile> F"
  apply (case_tac i; clarsimp)
  using ltl_drop_alt by fastforce

declare enat_the_enat[simp]

lemma [simp]:
  "(n :: enat) < m \<Longrightarrow> n \<noteq> \<infinity>"
  by (cases n; simp)

lemma [simp]:
  "i < llength xs \<Longrightarrow> (k < the_enat i) = (k < i)"
  by (metis enat_ord_simps(2) enat_ord_simps(6) enat_the_enat)

lemma ldrop_simps:
  "i < llength xs \<Longrightarrow> (ldrop i xs @@ ys, 0) \<Turnstile> F = (xs @@ ys, i) \<Turnstile> F"
  "i < llength xs \<Longrightarrow> (ldrop i xs, 0) \<Turnstile> F = (xs, i) \<Turnstile> F"
   apply (metis ldrop_less_length ltl_drop_alt)
  apply (metis ltl_drop_alt)
  done

lemma ltldropI:
  "\<lbrakk> i < llength xs; (ldrop i xs, 0) \<Turnstile> F \<rbrakk> \<Longrightarrow> (xs, i) \<Turnstile> F"
  by (simp add: ldrop_simps)


lemma until_cases:
 "(xs @@ ys, 0) \<Turnstile> G \<U> F \<longleftrightarrow>
    (\<exists>i :: nat < llength xs. (ldrop i xs @@ ys, 0) \<Turnstile> F \<and> (\<forall>j < i. (xs @@ ys, j) \<Turnstile> G)) \<or>
    ((\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G) \<and> lfinite xs \<and>  (ys,0) \<Turnstile> G \<U> F)"
  apply (rule iffI)
   apply (erule ltl_untilE)
   apply (case_tac "i < llength xs")
    apply (rule disjI1)
    apply (smt (verit, del_insts) bot_nat_0.extremum ldrop_less_length less_enatE ltl_drop_alt order.strict_trans)
   apply (rule disjI2)
   apply (intro conjI; clarsimp)
     apply (meson enat_ord_simps(2) linorder_not_le order_less_le_trans)
    apply (metis lappend_inf llength_lappend)
   apply (clarsimp simp: not_less)
   apply (rule_tac j="i - the_enat (llength xs)" in ltl_untilI; clarsimp?)
     apply (metis enat_ile enat_ord_simps(1) le_add_diff_inverse ltl_drop_alt' the_enat.simps)
    apply (metis enat.simps(2) ldrop_enat ldropn_eq_LNil length_list_of_conv_the_enat lfinite_LNil lfinite_ldrop llength_lappend ltl_drop_append' ltl_not_def ltl_opt_def)
   apply (metis add.commute enat_ile less_diff_conv ltl_drop_alt' the_enat.simps)
  apply (erule disjE)
   apply clarsimp
   apply (fastforce intro: ltl_untilI dest!: ltldropD)
  apply clarsimp
  apply (drule lfinite_ex_list, clarsimp)
  apply (erule ltl_untilE, clarsimp)
  apply (rule_tac j="i + the_enat (llength xs)" in ltl_untilI; clarsimp?)
    apply (metis add.commute ltl_drop_append)
   apply (metis add.commute enat_less_enat_plusI2)
  by (metis LTL_Drop.ltl_ldrop ldrop_llength le_def less_diff_conv2 lfinite_llist_of llength_llist_of)

lemma finally_cases:
  "(xs @@ ys, 0) \<Turnstile> \<diamond>F \<longleftrightarrow> (\<exists>i :: nat < llength xs. (ldrop i xs @@ ys, 0) \<Turnstile> F) \<or>
                           (lfinite xs \<and> (ys,0) \<Turnstile> \<diamond>F)"
  unfolding LTL_Finally_def
  apply (subst until_cases)
  apply (auto simp: ltl_semantics)
  done

lemma globally_cases:
  "(xs @@ ys, 0) \<Turnstile> \<box>G \<longleftrightarrow>
   (\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G) \<and> (lfinite xs \<longrightarrow> (ys,0) \<Turnstile> \<box>G)"
  apply (subst simp_thms(2)[symmetric])
  apply (clarsimp simp: ltl_not_def[symmetric] ltl_nnf)
  apply (subst finally_cases[where F="\<not>\<^sub>lG" and xs=xs and ys=ys])
  apply (auto simp: ldrop_simps)
  done

lemma release_cases:
 "(xs @@ ys, 0) \<Turnstile> F \<R> G \<longleftrightarrow>
     (\<exists>i :: nat < llength xs. (ldrop i xs @@ ys, 0) \<Turnstile> F \<and> (\<forall>j \<le> i. (xs @@ ys, j) \<Turnstile> G)) \<or>
    ((\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G) \<and> (lfinite xs \<longrightarrow> (ys,0) \<Turnstile> F \<R> G))"
  apply (unfold LTL_Release_def)
  apply (unfold ltl_disj_def)
  apply (unfold until_cases globally_cases)
  apply (subst disj_assoc)
  apply (rule disj_cong)
   apply (auto simp: ltl_semantics ldrop_simps)[1]
  using ldrop_simps(1) le_neq_implies_less apply blast
  apply (auto simp: ltl_semantics)
  done

end