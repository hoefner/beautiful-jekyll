(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

(* FIXME ryanb: rename *)
theory LTL_Drop
  imports LTL_Lifting
begin

lemma ltl_drop':
  "(xs, i + j) \<Turnstile> F = (ldrop (enat i) xs, j) \<Turnstile> F"
  apply (induct xs "i + j" F arbitrary: i j rule: ltl_semantics_induct)
      apply (clarsimp simp: ltl_semantics)
      apply (metis add.commute enat_ile le_iff_add plus_enat_simps(1) the_enat.simps)
     apply (auto simp: ltl_semantics)[1]
    apply (auto simp: ltl_semantics)[1]
   apply (auto simp: ltl_semantics)[1]
      apply (metis add.commute add_Suc_right ldrop_eq_LNil ldrop_ldrop linorder_not_le plus_enat_simps(1))
     apply (metis add_Suc_right)
    apply (metis add.commute add_Suc_right ldrop_eq_LNil ldrop_ldrop linorder_not_le plus_enat_simps(1))
   apply (metis add_Suc_right)
  apply (rename_tac m n)
  apply (case_tac m; clarsimp)
  using enat_0 apply auto[1]
  apply (rename_tac m)
  apply (rule iffI)
   apply (clarsimp simp: ltl_semantics)
   apply (rule_tac x="j - Suc m" in exI)
   apply (intro conjI; clarsimp?)
      apply linarith
     apply (metis add.commute add_Suc_right add_leD2 ldrop_eq_LNil ldrop_ldrop le_add_diff_inverse linorder_not_le plus_enat_simps(1))
  apply (metis add_Suc add_leD1 le_add_diff_inverse)
  apply (smt (verit, ccfv_threshold) add.commute add_Suc less_diff_conv nat_add_left_cancel_le)
 apply (clarsimp simp: ltl_semantics)
  apply (rule_tac x="m + Suc j" in exI)
  apply (intro conjI; clarsimp?)
  apply (metis add.commute add_Suc_right ldrop_eq_LNil ldrop_ldrop linorder_not_le plus_enat_simps(1))
  apply (metis add_Suc)
  apply (smt (verit) add.assoc add_Suc add_less_cancel_left le_iff_add)
  done

(* FIXME ryanb: rename *)
lemma ltl_drop:
  "(ldrop i xs, j) \<Turnstile> F = (xs, i + j) \<Turnstile> F"
  using ltl_drop' by blast

lemma ltl_drop_alt:
  "(xs, j) \<Turnstile> F = (ldrop j xs, 0) \<Turnstile> F"
  by (simp add: ltl_drop)

lemma ldrop_lappend_miracle:
  "enat n = llength xs \<Longrightarrow> ldrop n (xs @@ ys) = ys"
  by (metis add_0 add_diff_cancel_right' dual_order.refl ldrop_enat ldropn_0 ldropn_lappend2 the_enat.simps)

lemma ltl_drop_append:
  "(llist_of xs @@ ys, length xs + j) \<Turnstile> F = (ys, j) \<Turnstile> F"
  by (metis ltl_drop ldrop_lappend_miracle llength_llist_of)

lemma ltl_appendE:
  "\<lbrakk> llength xs = enat len; len \<le> n; (ys, n - the_enat (llength xs)) \<Turnstile> F \<rbrakk> \<Longrightarrow>
     (xs @@ ys, n) \<Turnstile> F"
  by (metis ldrop_lappend_miracle le_add_diff_inverse ltl_drop' plus_enat_simps(1) the_enat.simps)

(* FIXME ryanb: standardise, cleanup *)

lemma llist_of_stream_sdrop[simp]:
  "llist_of_stream (sdrop i ts) = ldrop i (llist_of_stream ts)"
  apply (induct i)
  using zero_enat_def apply force
  by (metis ldrop_eSuc_ltl ldrop_enat ltl_ldrop ltl_llist_of_stream sdrop_simps(2))

lemma ltl_sdrop:
  "(sdrop i ts, j) \<tturnstile> P \<Longrightarrow> (ts, i + j) \<tturnstile> P"
  using from_ltl
  by (metis llist_of_stream_sdrop ltl_drop plus_enat_simps(1))

lemma ltl_sdrop':
  "(ts, i) \<tturnstile> P \<Longrightarrow> (sdrop i ts, 0) \<tturnstile> P"
  using from_ltl
  by (metis llist_of_stream_sdrop ltl_drop_alt)

(* FIXME ryanb: move *)
lemma ltlf_drop:
  "(drop i xs, j) \<turnstile> F = (xs, i + j) \<turnstile> F"
  apply (simp add: ltlf_semantics_def ldrop_llist_of[symmetric])
  apply (rule ltl_drop)
  done

(* FIXME ryanb: move *)
lemma ltl_add_prefix:
  "\<lbrakk> (ys, n) \<Turnstile> F; llength xs = enat m \<rbrakk>
     \<Longrightarrow> (xs @@ ys, m + n) \<Turnstile> F"
  by (metis enat_add_mono ldrop_lappend_miracle llength_lappend ltl_drop)

(* FIXME ryanb: move *)
lemma ltl_drop_alt':
  "\<lbrakk> llength xs = enat m; (xs @@ ys, m + n) \<Turnstile> F \<rbrakk> \<Longrightarrow> (ys, n) \<Turnstile> F"
  by (metis enat_add_mono ldrop_lappend_miracle llength_lappend ltl_drop)

(* FIXME ryanb: move *)
lemma ldrop_less_length[simp]:
  "n < llength xs
   \<Longrightarrow> ldrop n (xs @@ ys) = ldrop n xs @@ ys"
  by (meson ldrop_lappend)

(* FIXME ryanb: move *)
lemma ldrop_le_length[simp]:
  "enat n \<le> llength xs
   \<Longrightarrow> ldrop n (xs @@ ys) = ldrop n xs @@ ys"
  by (metis lappend_lnull1 ldrop_lappend ldrop_lappend_miracle lnull_ldrop order_le_imp_less_or_eq)

(* FIXME ryanb: move *)
lemma lfinite_ex_list:
  "lfinite xs \<Longrightarrow> \<exists>ys. xs = llist_of ys"
  by (metis llist_of_list_of)

(* FIXME ryanb: move *)
lemma ldrop_llength:
  "lfinite xs \<Longrightarrow> ldrop (llength xs) (xs @@ ys) = ys"
  by (metis ldrop_lappend_miracle length_list_of)

(* FIXME ryanb: move *)
lemma enat_trans_less_add1[simp]:
  "(x :: enat) < y
    \<Longrightarrow> x < y + z"
  using enat_le_plus_same order_less_le_trans by blast

(* FIXME ryanb: move *)
lemma ldrop_lappend':
  "ldrop n (xs @@ ys) = ldrop n xs @@ ldrop (n - llength xs) ys"
  apply (case_tac "llength xs")
   prefer 2
   apply clarsimp
  apply (metis lappend_inf lappend_lnull2 ldrop_lappend linorder_not_le llength_eq_infty_conv_lfinite lnull_ldrop)
  apply (case_tac n; clarsimp)
  by (metis diff_is_0_eq enat_ord_simps(2) lappend.code ldrop_0 ldrop_enat ldrop_eq_LNil ldrop_lappend ldropn_lappend2 linorder_not_le llist.simps(4) nle_le the_enat.simps zero_enat_def)

(* FIXME ryanb: use as the canonical form *)
lemma ltl_ldrop:
  "j \<le> i \<Longrightarrow> (xs, i) \<Turnstile> F = (ldrop j xs, i - j) \<Turnstile> F"
  by (simp add: ltl_drop)

lemma ltl_ldrop':
  "\<lbrakk> (xs, i) \<Turnstile> F; n \<le> i; ys = ldrop (i - n) xs \<rbrakk> \<Longrightarrow> (ys, n) \<Turnstile> F"
  by (simp add: ltl_drop)

lemma ltl_drop_append':
  "\<lbrakk> lfinite xs; llength xs \<le> n \<rbrakk>
     \<Longrightarrow> (xs @@ ys, n) \<Turnstile> F = (ys, n - length (list_of xs)) \<Turnstile> F"
  apply (rule trans[OF ltl_ldrop[where j="length (list_of xs)"]])
  using llength_eq_infty_conv_lfinite
  by (fastforce simp: lappend_lnull1 length_list_of_conv_the_enat)+

lemma ltl_drop_appendD:
  "\<lbrakk> (xs @@ ys, n) \<Turnstile> F; lfinite xs; llength xs \<le> n \<rbrakk>
     \<Longrightarrow> (ys, n - length (list_of xs)) \<Turnstile> F"
  by (simp add: ltl_drop_append')

lemma ltl_drop_appendI:
  "\<lbrakk> (ys, n - length (list_of xs)) \<Turnstile> F; lfinite xs; llength xs \<le> n; n < llength xs + llength ys \<rbrakk>
     \<Longrightarrow> (xs @@ ys, n) \<Turnstile> F"
  by (simp add: ltl_drop_append')

end