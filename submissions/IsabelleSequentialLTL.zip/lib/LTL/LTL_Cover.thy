theory LTL_Cover
  imports LTL_Cover_Pre
begin

text \<open>Combine two covers @{term gs} and @{term fs} via conjunction.\<close>
definition conj_iff where
  "conj_iff xs ys \<equiv> [(L \<and>\<^sub>l L', R \<and>\<^sub>l R'). (L,R) \<leftarrow> xs, (L',R') \<leftarrow> ys]"

text \<open>Given a cover @{term gs} for @{term G}, compute a cover for @{term "\<box>G"}.\<close>
definition globally_iff where
  "globally_iff gs G \<equiv>
     (\<not>\<^sub>lfinite\<^sub>l \<and>\<^sub>l \<box>G, True\<^sub>l) #
     [(\<box>(\<Or>\<^sub>l map fst ps), \<box>G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs]"

text \<open>Given a cover @{term fs} for @{term F}, compute a cover for @{term "\<diamond>F"}.\<close>
definition finally_iff where
  "finally_iff fs F \<equiv> (finite\<^sub>l,\<diamond>F) # [(\<diamond>L, R). (L,R) \<leftarrow> fs]"

text \<open>Given a cover @{term gs} for @{term G} and @{term fs} for @{term F},
      compute a cover for @{term "G \<U> F"}.\<close>
definition until_iff where
  "until_iff gs fs G F \<equiv>
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs] @
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps) \<and>\<^sub>l finite\<^sub>l, G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs]"

text \<open>Given a cover @{term fs} for @{term F} and @{term gs} for @{term G},
      compute a cover for @{term "F \<R> G"}.\<close>
definition release_iff where
  "release_iff fs gs F G \<equiv>
     \<comment> \<open>Infinite LHS\<close>
     (F \<R> G \<and>\<^sub>l \<not>\<^sub>lfinite\<^sub>l, True\<^sub>l) #
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> ((\<Or>\<^sub>l map fst ps) \<and>\<^sub>l L'), (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs] @
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps), F \<R> G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs]"

definition ltl_cover (infixl "covers" 60) where
  "fs covers F \<equiv> \<forall>xs ys. (xs@@ys,0) \<Turnstile> F \<longleftrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R)"

definition ltl_pcover (infixl "pcovers" 60) where
  "fs pcovers F \<equiv> \<forall>xs ys. (xs@@ys,0) \<Turnstile> F \<longrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R)"

definition ltl_bcover (infixl "bcovers" 60) where
  "fs bcovers F \<equiv> \<forall>xs ys. (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R) \<longrightarrow> (xs@@ys,0) \<Turnstile> F"

lemma covers_iff:
  "fs covers F \<longleftrightarrow> fs pcovers F \<and> fs bcovers F"
  by (fastforce simp: ltl_cover_def ltl_pcover_def ltl_bcover_def split_def)

lemma coversI:
  "\<lbrakk> fs pcovers F; fs bcovers F \<rbrakk>
     \<Longrightarrow> fs covers F"
  by (simp add: covers_iff)

lemma coversD:
  "\<lbrakk> fs covers F \<rbrakk>
     \<Longrightarrow> fs pcovers F \<and> fs bcovers F"
  by (simp add: covers_iff)

lemma coversD1:
  "\<lbrakk> fs covers F \<rbrakk>
     \<Longrightarrow> fs pcovers F"
  by (simp add: covers_iff)

lemma coversD2:
  "\<lbrakk> fs covers F \<rbrakk>
     \<Longrightarrow> fs bcovers F"
  by (simp add: covers_iff)

lemma pcoversI:
  "\<lbrakk> \<And>xs ys. (xs@@ys,0) \<Turnstile> F \<Longrightarrow> \<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R \<rbrakk>
     \<Longrightarrow> fs pcovers F"
  by (auto simp: ltl_pcover_def)

lemma pcoversE:
  "\<lbrakk> fs pcovers F; (xs@@ys,0) \<Turnstile> F;
     \<And>L R. \<lbrakk> (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk> \<Longrightarrow> P \<rbrakk>
     \<Longrightarrow> P"
  by (auto simp: ltl_pcover_def)

lemma bcoversI:
  "\<lbrakk> \<And>xs ys L R. \<lbrakk> (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk> \<Longrightarrow> (xs@@ys,0) \<Turnstile> F \<rbrakk>
     \<Longrightarrow> fs bcovers F"
  by (auto simp: ltl_bcover_def)

lemma bcoversE:
  "\<lbrakk> fs bcovers F; (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R; (xs@@ys,0) \<Turnstile> F \<Longrightarrow> P \<rbrakk>
     \<Longrightarrow> P"
  by (auto simp: ltl_bcover_def)

lemma pcovers_weaken:
  "\<lbrakk> fs pcovers F; \<And>xs ys L R. \<lbrakk> (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk>
                                 \<Longrightarrow> \<exists>(L',R') \<in> set fs'. (xs,0) \<Turnstile> L' \<and> (ys,0) \<Turnstile> R' \<rbrakk>
     \<Longrightarrow> fs' pcovers F"
  by (fastforce simp: ltl_pcover_def split_def)

lemma pcovers_subst:
  "\<lbrakk> fs' pcovers F; fs' = fs \<rbrakk>
     \<Longrightarrow> fs pcovers F"
  by simp

lemma pcovers_triv:
  "fs pcovers F \<Longrightarrow> fs pcovers F"
  by simp

lemma pcovers_False:
  "fs pcovers False\<^sub>l"
  by (simp add: ltl_pcover_def)

lemma bcovers_weaken:
  "\<lbrakk> fs bcovers F; \<And>xs ys L R. \<lbrakk> (L,R) \<in> set fs'; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk>
                                 \<Longrightarrow> \<exists>(L',R') \<in> set fs. (xs,0) \<Turnstile> L' \<and> (ys,0) \<Turnstile> R' \<rbrakk>
     \<Longrightarrow> fs' bcovers F"
  by (fastforce simp: ltl_bcover_def split_def)

lemma bcovers_weaken':
  "\<lbrakk> fs bcovers F'; F' \<Longrightarrow>\<^sub>l F \<rbrakk>
     \<Longrightarrow> fs bcovers F"
  by (simp add: ltl_bcover_def)

lemma bcovers_append:
  "\<lbrakk> xs bcovers F; ys bcovers F \<rbrakk>
     \<Longrightarrow> xs @ ys bcovers F"
  by (fastforce simp: ltl_bcover_def)

lemma bcovers_appendD1:
  "\<lbrakk> xs @ ys bcovers F \<rbrakk>
     \<Longrightarrow> xs bcovers F"
  by (fastforce simp: ltl_bcover_def)

lemma bcovers_appendD2:
  "\<lbrakk> xs @ ys bcovers F \<rbrakk>
     \<Longrightarrow> ys bcovers F"
  by (fastforce simp: ltl_bcover_def)

lemma bcovers_subst:
  "\<lbrakk> fs' bcovers F; fs' = fs \<rbrakk>
     \<Longrightarrow> fs bcovers F"
  by simp

lemma bcovers_triv:
  "fs bcovers F \<Longrightarrow> fs bcovers F"
  by simp

lemma bcovers_False:
  "[(False\<^sub>l,False\<^sub>l)] bcovers F"
  by (simp add: ltl_bcover_def)

lemma covers_weaken:
  "\<lbrakk> fs covers F; \<And>xs ys. (\<exists>(L,R) \<in> set fs'. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R)
                     \<longleftrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R) \<rbrakk>
     \<Longrightarrow> fs' covers F"
  by (fastforce simp: ltl_cover_def split_def)

lemma covers_subst:
  "\<lbrakk> fs' covers F; fs' = fs \<rbrakk>
     \<Longrightarrow> fs covers F"
  by simp

lemma covers_triv:
  "fs covers F \<Longrightarrow> fs covers F"
  by simp

text \<open>Atom\<close>

lemma pcovers_atom:
  "[(\<A>(P) \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l, True\<^sub>l), (null\<^sub>l, \<A>(P))] pcovers \<A>(P)"
  apply (rule pcoversI)
  apply (case_tac xs; case_tac ys; clarsimp simp: ltl_semantics enat_0)
  done

lemma bcovers_atom:
  "[(\<A>(P) \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l, True\<^sub>l), (null\<^sub>l, \<A>(P))] bcovers \<A>(P)"
  apply (rule bcoversI)
  apply (case_tac xs; case_tac ys; auto simp: ltl_semantics enat_0)
  done

lemma covers_atom:
  "[(\<A>(P) \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l, True\<^sub>l), (null\<^sub>l, \<A>(P))] covers \<A>(P)"
  using pcovers_atom bcovers_atom covers_iff by blast


text \<open>Conjunction\<close>

lemma pcovers_conj:
  "\<lbrakk> fs pcovers F; gs pcovers G \<rbrakk>
     \<Longrightarrow> (conj_iff fs gs) pcovers (F \<and>\<^sub>l G)"
  by (fastforce intro: pcoversI elim: pcoversE simp: conj_iff_def ltl_semantics)

lemma bcovers_conj:
  "\<lbrakk> fs bcovers F; gs bcovers G \<rbrakk>
     \<Longrightarrow> (conj_iff fs gs) bcovers (F \<and>\<^sub>l G)"
  by (fastforce intro: bcoversI elim: bcoversE simp: conj_iff_def ltl_semantics)

lemma covers_conj:
  "\<lbrakk> fs covers F; gs covers G \<rbrakk>
     \<Longrightarrow> conj_iff fs gs covers (F \<and>\<^sub>l G)"
  using pcovers_conj bcovers_conj covers_iff by blast


text \<open>Disjunction\<close>

lemma pcovers_disj:
  "\<lbrakk> fs pcovers F; gs pcovers G \<rbrakk>
     \<Longrightarrow> fs@gs pcovers (F \<or>\<^sub>l G)"
  by (fastforce intro: pcoversI elim: pcoversE ltl_disjE)

lemma bcovers_disj:
  "\<lbrakk> fs bcovers F; gs bcovers G \<rbrakk>
     \<Longrightarrow> fs@gs bcovers (F \<or>\<^sub>l G)"
  by (fastforce elim: bcoversE intro: bcoversI ltl_disjI1 ltl_disjI2)

lemma bcovers_disjI1:
  "\<lbrakk> fs bcovers F \<rbrakk> \<Longrightarrow> fs bcovers (F \<or>\<^sub>l G)"
  by (fastforce elim: bcoversE intro: bcoversI ltl_disjI1 ltl_disjI2)

lemma bcovers_disjI2:
  "\<lbrakk> gs bcovers G \<rbrakk> \<Longrightarrow> gs bcovers (F \<or>\<^sub>l G)"
  by (fastforce elim: bcoversE intro: bcoversI ltl_disjI1 ltl_disjI2)

lemma covers_disj:
  "\<lbrakk> fs covers F; gs covers G \<rbrakk>
     \<Longrightarrow> fs@gs covers (F \<or>\<^sub>l G)"
  using pcovers_disj bcovers_disj covers_iff by blast


text \<open>Next\<close>

lemma pcovers_next:
  assumes "fs pcovers F"
  shows
  "[(one\<^sub>l,F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l),(null\<^sub>l,\<circle>F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] pcovers \<circle>F"
  apply (rule pcoversI)
  apply (case_tac xs, clarsimp simp: ltl_semantics enat_0)
  apply (case_tac "ltl xs")
   apply (clarsimp simp: ltl_semantics enat_0 split_def)
  apply (metis One_nat_def Suc_ile_eq llength_LNil llist.collapse(1) ltl_weak_next_LCons ltl_weak_next_def not_one_le_zero one_eSuc one_enat_def)
  apply simp
  apply (rule disjI2)+
  apply (clarsimp simp: ltl_next_LCons enat_0 split_def)
  by (metis assms lappend_code(2) split_pairs pcoversE)

lemma bcovers_next:
  assumes "fs bcovers F"
  shows
  "[(one\<^sub>l,F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l),(null\<^sub>l,\<circle>F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] bcovers \<circle>F"
  apply (rule bcoversI)
  apply clarsimp
  apply (case_tac xs)
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff)
  apply (case_tac "ltl xs")
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff enat_0)
   apply (metis Suc_ile_eq enat_0 gr_zeroI ldrop_eSuc_LCons llength_eq_0 ltl_drop_alt)
  apply (elim disjE)
    apply (clarsimp simp: ltl_semantics enat_0_iff)
    apply (metis One_nat_def eSuc_inject one_eSuc one_enat_def zero_ne_eSuc)
   apply (clarsimp simp: ltl_semantics enat_0)
  apply (clarsimp simp: ltl_next_LCons enat_0)
  using assms by (fastforce elim: bcoversE)

lemma covers_next:
  assumes "fs covers F"
  shows "[(one\<^sub>l,F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l),(null\<^sub>l,\<circle>F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] covers \<circle>F"
  using pcovers_next bcovers_next covers_iff assms by blast

lemma pcovers_weak_next:
  assumes "fs pcovers F"
  shows
  "[(one\<^sub>l,null\<^sub>l),(one\<^sub>l,F),(null\<^sub>l,\<ominus>F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] pcovers \<ominus>F"
  apply (rule pcoversI)
  apply (case_tac xs, clarsimp simp: ltl_semantics enat_0)
  apply (case_tac "ltl xs")
   apply (clarsimp simp: ltl_semantics enat_0 split_def)
   apply (metis One_nat_def Suc_ile_eq enat_0 ldrop_eSuc_LCons llength_eq_0 ltl_drop_alt one_eSuc one_enat_def zero_less_iff_neq_zero)
  apply simp
  apply (rule disjI2)+
  apply (clarsimp simp: ltl_weak_next_LCons enat_0 split_def)
  by (metis assms enat_0_iff(1) gr_implies_not_zero lappend_code(2) linorder_cases llength_eq_0 llist.disc(2) ltl_next_LCons pcoversE split_pairs)

lemma bcovers_weak_next:
  assumes "fs bcovers F"
  shows
   "[(one\<^sub>l,null\<^sub>l),(one\<^sub>l,F),(null\<^sub>l,\<ominus>F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] bcovers \<ominus>F"
  apply (rule bcoversI)
  apply clarsimp
  apply (case_tac xs)
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff)
  apply (case_tac "ltl xs")
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff enat_0)
   apply (metis Suc_ile_eq enat_0 gr_zeroI ldrop_eSuc_LCons llength_eq_0 ltl_drop_alt)
  apply (elim disjE)
     apply (clarsimp simp: ltl_semantics enat_0_iff)
     apply (metis One_nat_def eSuc_inject one_eSuc one_enat_def zero_ne_eSuc)
    apply (clarsimp simp: ltl_semantics enat_0)
    apply (metis One_nat_def eSuc_inject one_eSuc one_enat_def zero_ne_eSuc)
   apply (clarsimp simp: enat_0 ltl_semantics)
  apply (clarsimp simp: ltl_weak_next_LCons enat_0 ltl_next_LCons)
  using assms by (fastforce elim: bcoversE)

lemma covers_weak_next:
  assumes "fs covers F"
  shows
   "[(one\<^sub>l,null\<^sub>l),(one\<^sub>l,F),(null\<^sub>l,\<ominus>F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] covers \<ominus>F"
  using pcovers_weak_next bcovers_weak_next covers_iff assms by blast


text \<open>Finally\<close>

lemma pcovers_finally:
  "fs pcovers F \<Longrightarrow> finally_iff fs F pcovers \<diamond>F"
  apply (rule pcoversI)
  apply (clarsimp simp: finally_cases)
  apply (erule disjE)
   apply clarsimp
   apply (clarsimp simp: finally_iff_def split_def)
   apply (erule (1) pcoversE)
   apply (drule (1) bspec, clarsimp)
   apply (metis finally_cases lappend_LNil2)
  apply (clarsimp simp: finally_iff_def ltl_finite_def)
  done

lemma bcovers_finally:
  "fs bcovers F \<Longrightarrow> finally_iff fs F bcovers \<diamond>F"
  apply (rule bcoversI)
  apply (clarsimp simp: finally_cases)
  apply (clarsimp simp: finally_iff_def)
  apply (erule disjE; clarsimp simp: ltl_finite_def)
  by (meson bcoversE ltl_drop_alt ltl_finallyE)

lemma covers_finally:
  "fs covers F \<Longrightarrow> (finally_iff fs F) covers (\<diamond>F)"
  using pcovers_finally bcovers_finally covers_iff by blast


text \<open>Globally\<close>

lemma helper_globally':
  assumes gs: "gs pcovers G"
  and G: "\<forall>i < llength xs. (xs @@ ys, i) \<Turnstile> G"
  shows "\<exists>lrs. set lrs \<subseteq> set gs \<and> (xs,0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst lrs)
                                \<and> (ys,0) \<Turnstile> (\<And>\<^sub>l map snd lrs)"
proof -
  have LR: "\<forall>n < llength xs. \<exists>LR \<in> set gs. (xs,n) \<Turnstile> fst LR \<and> (ys,0) \<Turnstile> snd LR"
    apply (insert G)
    apply (erule all_forward, clarsimp)
    by (metis LTL_Cover_Pre.ldrop_simps(1) fst_conv gs ltldropI pcoversE snd_conv)
  define lrs where lrs_def: "lrs = filter (\<lambda>lr. (ys,0) \<Turnstile> snd lr) gs"
  have "set lrs \<subseteq> set gs"
    by (simp add: lrs_def)
  have [simp]: "map snd (filter (\<lambda>lr. (ys, 0) \<Turnstile> snd lr) gs) = filter (\<lambda>r. (ys, 0) \<Turnstile> r) (map snd gs)"
    by (induct gs; clarsimp)
  have ys: "(ys,0) \<Turnstile> \<And>\<^sub>l map snd lrs"
    apply (simp add: lrs_def)
    apply (induct gs; clarsimp simp: ltl_semantics)
    done
  have xs: "\<forall>n < llength xs. \<exists>lr \<in> set lrs. (xs,n) \<Turnstile> fst lr"
    apply (insert LR)
    apply (erule all_forward)
    apply clarsimp
    apply (subgoal_tac "(a, b) \<in> set lrs")
    apply (metis fst_conv)
    apply (clarsimp simp: lrs_def)
    done
  show ?thesis
    apply (rule_tac x=lrs in exI)
    apply (intro conjI)
    apply (simp add: \<open>set lrs \<subseteq> set gs\<close>)
     apply (rule ltl_globallyI)
     apply (insert xs)[1]
     apply (erule_tac x=i in allE)
     apply clarsimp
    apply (metis ltl_supD set_zip_leftD zip_map_fst_snd)
    apply (simp add: ys)
    done
qed

lemma pow_list_subseteq:
  "set xs \<subseteq> set ys
\<Longrightarrow> \<exists>ps \<in> set (pow_list ys). set ps = set xs"
  apply (induct xs arbitrary: ys; clarsimp simp: nil_in_pow_list)
  by (metis Un_insert_left append.simps(1) list.set(2) one_in_pow_list pow_list_un set_append)

lemma helper_globally:
  "\<lbrakk> gs pcovers G; \<forall>i < llength xs. (xs @@ ys, i) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>LR \<in> set (pow_list gs). (xs,0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst LR)
                                \<and> (ys,0) \<Turnstile> (\<And>\<^sub>l map snd LR)"
  apply (frule (1) helper_globally', clarsimp)
  apply (prop_tac "\<exists>LR\<in>set (pow_list gs). set LR = set lrs")
   apply (rule pow_list_subseteq, clarsimp)
  apply clarsimp
  apply (erule_tac x=LR in rev_bexI)
  apply (rule conjI)
  apply (simp add: ltl_sup_def ltl_globally_def)
  by (simp add: ltl_inf_def)

lemma pcovers_globally:
  assumes A: "gs pcovers G"
  shows "(globally_iff gs G) pcovers (\<box>G)"
proof (rule pcoversI)
  fix xs ys
  assume xsys: "(xs @@ ys, 0) \<Turnstile> \<box>G"
  then show "\<exists>(L, R)\<in>set (globally_iff gs G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  proof (cases "lfinite xs")
    case True then have finite: "lfinite xs" .
    have xs: "\<forall>i < llength xs. (xs @@ ys, i) \<Turnstile> G"
      and ys: "(ys, 0) \<Turnstile> \<box>G"
      using globally_cases finite xsys by auto
    have "\<exists>LR\<in>set (pow_list gs).
            (xs,0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst LR) \<and>
            (ys,0) \<Turnstile> \<box>G \<and>\<^sub>l (\<And>\<^sub>l map snd LR)"
      using finite helper_globally xs ys A ltl_conj_def by metis
    then show ?thesis
      by (simp add: globally_iff_def)
  next
    case False
    then show ?thesis
      using xsys A by (auto simp: globally_iff_def lappend_inf ltl_semantics)
  qed
qed

lemma bcovers_globally:
  assumes A: "gs bcovers G"
  shows "(globally_iff gs G) bcovers (\<box>G)"
proof (rule bcoversI)
  fix xs ys L R
  assume LR: "(L,R) \<in> set (globally_iff gs G)"
    and L: "(xs, 0) \<Turnstile> L"
    and R: "(ys, 0) \<Turnstile> R"
  then show "(xs @@ ys, 0) \<Turnstile> \<box>G"
    apply (clarsimp simp: globally_iff_def)
    apply (erule disjE)
     apply (metis lappend_inf ltl_finite_def ltl_conjE ltl_not_def)
    apply (clarsimp simp: image_iff)
    apply (rule ltl_globallyI)
    apply (case_tac "i < llength xs")
     apply (erule (2) ltl_globallyE)
     apply (clarsimp simp: ltl_inf_def ltl_sup_def)
     apply (drule (1) bspec, clarsimp)
     apply (drule (1) in_set_pow_list)
     apply (subst (asm) ltl_drop_alt)
     apply (drule_tac n=0 and i=i in ltl_ldrop'[OF _ _ refl], clarsimp)
     apply (erule (2) bcoversE[OF A])
     apply (clarsimp simp: enat_0)
    using ltl_drop_alt apply fastforce
    by (metis enat_ile enat_ord_simps(1) ldrop_llength lfinite_conv_llength_enat ltl_drop_alt ltl_globallyD not_le_imp_less)
qed

lemma covers_globally:
  "gs covers G \<Longrightarrow> (globally_iff gs G) covers (\<box>G)"
  using pcovers_globally bcovers_globally covers_iff by blast


text \<open>Until\<close>

lemma helper_until':
  assumes gs: "gs pcovers G"
  assumes ps: "fs pcovers F"
  assumes i: "enat i < llength xs"
  assumes F: "(ldrop i xs @@ ys, 0) \<Turnstile> F"
  assumes G: "\<forall>j < i. (xs @@ ys, j) \<Turnstile> G"
  shows "\<exists>lrs LR'. set lrs \<subseteq> set gs \<and> LR' \<in> set fs \<and>
                  (xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> (fst LR') \<and>
                  (ys,0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l snd LR'"
proof -
  obtain LR' where LR':
    "LR' \<in> set fs \<and> (ldrop i xs, 0) \<Turnstile> fst LR' \<and> (ys,0) \<Turnstile> snd LR'"
    by (metis F fst_conv pcoversE ps snd_conv)
  have LR: "\<forall>n < i. \<exists>LR \<in> set gs. (xs,n) \<Turnstile> fst LR \<and> (ys,0) \<Turnstile> snd LR"
    apply (insert i G)
    apply (erule all_forward, clarsimp)
    apply (insert gs)
    apply (erule pcoversE)
     apply (subst ldrop_simps; fastforce?)
    using dual_order.strict_trans enat_ord_simps(2) apply blast
    by (metis fst_conv ltl_drop_alt snd_conv)
  define lrs where lrs_def: "lrs = filter (\<lambda>lr. (ys,0) \<Turnstile> snd lr) gs"
  have "set lrs \<subseteq> set gs"
    by (simp add: lrs_def)
  have [simp]: "map snd (filter (\<lambda>lr. (ys, 0) \<Turnstile> snd lr) gs) = filter (\<lambda>r. (ys, 0) \<Turnstile> r) (map snd gs)"
    by (induct gs; clarsimp)
  have ys: "(ys,0) \<Turnstile> \<And>\<^sub>l map snd lrs"
    apply (simp add: lrs_def)
    apply (induct gs; clarsimp simp: ltl_semantics)
    done
  have xs: "\<forall>n < i. \<exists>lr \<in> set lrs. (xs,n) \<Turnstile> fst lr"
    apply (insert LR)
    apply (erule all_forward)
    apply clarsimp
    apply (subgoal_tac "(a, b) \<in> set lrs")
    apply (metis fst_conv)
    apply (clarsimp simp: lrs_def)
    done
  show ?thesis
    apply (rule_tac x=lrs in exI)
    apply (rule_tac x=LR' in exI)
    apply (insert LR')
    apply clarsimp
    apply (intro conjI)
      apply (simp add: \<open>set lrs \<subseteq> set gs\<close>)
     apply (insert xs i)[1]
     apply (clarsimp simp: ltl_semantics)
     apply (rule_tac x=i in exI)
     apply clarsimp
     apply (rule conjI)
    using ltldropI apply blast
     apply clarsimp
     apply (metis ltl_sup_def prod.collapse set_zip_leftD zip_map_fst_snd)
    by (simp add: ltl_conj_def ys)
qed

lemma helper_until:
  "\<lbrakk> gs pcovers G; fs pcovers F;
     enat i < llength xs; (ldrop i xs @@ ys, 0) \<Turnstile> F; \<forall>j < i. (xs @@ ys, j) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>lrs\<in>set (pow_list gs). \<exists>LR\<in>set fs.
          (xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> (fst LR) \<and>
          (ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l snd LR"
  apply (frule (4) helper_until', clarsimp)
  apply (prop_tac "\<exists>LR\<in>set (pow_list gs). set LR = set lrs")
   apply (rule pow_list_subseteq, clarsimp)
  apply clarsimp
  apply (erule_tac x=LR in rev_bexI)
  apply (erule rev_bexI)
  apply (simp add: ltl_sup_def ltl_inf_def ltl_semantics)
  done

lemma pcovers_until:
  assumes pcoversG: "gs pcovers G"
  assumes pcoversF: "fs pcovers F"
  shows "(until_iff gs fs G F) pcovers (G \<U> F)"
proof (rule pcoversI)
  fix xs ys
  assume GUF: "(xs @@ ys, 0) \<Turnstile> G \<U> F"
  moreover show "\<exists>(L, R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  proof (cases "lfinite xs")
    case True
    {
      fix i :: nat
      assume "i < llength xs"
        and "(ldrop i xs @@ ys, 0) \<Turnstile> F"
        and "(\<forall>j < i. (xs @@ ys, j) \<Turnstile> G)"
      then have "\<exists>(L,R)\<in>set [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using True helper_until finite pcoversG pcoversF by (simp add: split_def)
      then have "\<exists>(L,R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        by (fastforce simp: until_iff_def split_def)
    }
    moreover {
      assume "(\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G)"
        and "(ys,0) \<Turnstile> G \<U> F"
      then have "\<exists>(L, R)\<in>set [(\<box>(\<Or>\<^sub>l map fst ps) \<and>\<^sub>l finite\<^sub>l, G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using True helper_globally[OF pcoversG]
        by (auto simp: split_def ltl_semantics)
      then have "\<exists>(L, R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        unfolding until_iff_def
        apply clarsimp
        by (metis (no_types, lifting) Un_iff \<open>\<exists>(L, R) \<in>set (map (\<lambda>ps. (\<box>(\<Or>\<^sub>l map fst ps) \<and>\<^sub>l finite\<^sub>l, G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps))) (pow_list gs)). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R\<close> list.set_map)
    }
    ultimately show ?thesis
      using GUF[unfolded until_cases] by fastforce
  next
    case False
    obtain i where "(ldrop (enat i) xs @@ ys, 0) \<Turnstile> F"
      and "(\<forall>j < i. (xs @@ ys, j) \<Turnstile> G)"
      by (metis False calculation until_cases)
    moreover have "i < llength xs"
      using False by (simp add: not_lfinite_llength)
    ultimately have "\<exists>(L,R)\<in>set [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
      using helper_until finite pcoversG pcoversF by (simp add: split_def)
    then show "\<exists>(L,R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
      by (fastforce simp: until_iff_def split_def)
  qed
qed

lemma bcovers_until:
  assumes Gbcovers: "gs bcovers G"
  assumes Fbcovers: "fs bcovers F"
  shows "(until_iff gs fs G F) bcovers (G \<U> F)"
proof (rule bcoversI)
  fix xs ys L R
  assume LR: "(L,R) \<in> set (until_iff gs fs G F)"
    and L: "(xs, 0) \<Turnstile> L"
    and R: "(ys, 0) \<Turnstile> R"
  {
    assume "L = G \<U> F \<and>\<^sub>l \<not>\<^sub>lfinite\<^sub>l" and "R = True\<^sub>l"
    then have "(xs @@ ys, 0) \<Turnstile> G \<U> F"
      by (metis L lappend_inf ltl_finite_def ltl_conjE ltl_not_def)
  }
  moreover {
    fix ps L' R'
    assume ps: "ps \<in> set (pow_list gs)"
      and LR': "(L',R') \<in> set fs"
      and L_def: "L = (\<Or>\<^sub>l map fst ps) \<U> L'"
      and R_def: "R = (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'"
    obtain i :: nat where i: "i < llength xs"
      and L': "(ldrop i xs, 0) \<Turnstile> L'"
      and j: "\<forall>j<i. (xs, j) \<Turnstile> \<Or>\<^sub>l map fst ps"
      using L L_def ltl_untilE by (auto elim: ltl_untilE simp: ldrop_simps)
    have "(xs @@ ys, i) \<Turnstile> F"
      using bcoversE[OF Fbcovers LR' L'] i R R_def by (auto simp: ldrop_simps)
    moreover have "\<forall>k < i. (xs @@ ys, k) \<Turnstile> G"
      using i j R Gbcovers
      apply (clarsimp simp: R_def ltl_sup_def)
      apply (erule_tac x=k in allE, clarsimp)
      apply (erule (1) bcoversE[OF _ in_set_pow_list[OF ps]])
      using ltl_drop_alt apply fastforce
       apply (fastforce simp: ltl_inf_def)
      apply (fastforce simp: ldrop_simps order_less_subst2)
      done
    ultimately have "(xs @@ ys, 0) \<Turnstile> G \<U> F"
      by (simp add: i ltl_untilI)
  }
  moreover {
    fix ps
    assume ps: "ps \<in> set (pow_list gs)"
      and L_def: "L = \<box>(\<Or>\<^sub>l map fst ps) \<and>\<^sub>l finite\<^sub>l"
      and R_def: "R = G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)"
    then have "\<forall>k < llength xs. (xs @@ ys, k) \<Turnstile> G"
      using L R Gbcovers apply (clarsimp simp: L_def R_def)
      apply (erule_tac i=k in ltl_globallyE(1); clarsimp?)
      apply (clarsimp simp: ltl_inf_def ltl_sup_def)
      apply (frule in_set_pow_list[OF ps])
      using ltl_drop_alt by (fastforce elim!: bcoversE)
    then have "(xs @@ ys, 0) \<Turnstile> G \<U> F"
      using L L_def R R_def ltl_finite_def until_cases by blast
  }
  ultimately show "(xs @@ ys, 0) \<Turnstile> G \<U> F"
    using LR by (fastforce simp: until_iff_def split_def image_iff)
qed

lemma covers_until:
  assumes pcoversG: "gs covers G"
  assumes pcoversF: "fs covers F"
  shows "(until_iff gs fs G F) covers (G \<U> F)"
  using assms pcovers_until bcovers_until covers_iff by blast


text \<open>Release\<close>

lemma helper_release:
  "\<lbrakk> fs pcovers F; gs pcovers G;
     enat i < llength xs; (ldrop i xs @@ ys, 0) \<Turnstile> F; \<forall>j \<le> i. (xs @@ ys, j) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>lrs\<in>set (pow_list gs). \<exists>LR'\<in>set fs.
          (xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> ((\<Or>\<^sub>l map fst lrs) \<and>\<^sub>l fst LR') \<and>
          (ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l snd LR'"
  apply (frule (3) helper_until[where F="G \<and>\<^sub>l F" and G=G and ys=ys, OF _ pcovers_conj])
    apply (auto simp: ltl_semantics ldrop_simps)[2]
  apply (clarsimp simp: conj_iff_def)
  apply (drule pow_list_un, erule one_in_pow_list, clarsimp)
  apply (rule rev_bexI, assumption)+
  apply clarsimp
  apply (clarsimp simp: ltl_semantics ltl_sup_def ltl_inf_def)
  apply blast
  done

lemma pcovers_release:
  assumes pcoversG: "gs pcovers G"
  assumes pcoversF: "fs pcovers F"
  shows "(release_iff fs gs F G) pcovers (F \<R> G)"
proof (rule pcoversI)
  fix xs ys
  assume FRG: "(xs @@ ys, 0) \<Turnstile> F \<R> G"
  moreover show "\<exists>(L, R)\<in>set (release_iff fs gs F G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  proof (cases "lfinite xs")
    case True
    {
      fix i :: nat
      assume "i < llength xs"
        and "(ldrop i xs @@ ys, 0) \<Turnstile> F"
        and "(\<forall>j \<le> i. (xs @@ ys, j) \<Turnstile> G)"
      then have "\<exists>(L,R)\<in>set [((\<Or>\<^sub>l map fst ps) \<U> ((\<Or>\<^sub>l map fst ps) \<and>\<^sub>l L'), (\<And>\<^sub>l map snd ps)\<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, (L',R') \<leftarrow> fs]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using True finite pcoversG pcoversF by (fastforce simp: split_def intro!: helper_release)
      then have "\<exists>(L,R)\<in>set (release_iff fs gs F G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        by (fastforce simp: release_iff_def split_def)
    }
    moreover {
      assume "(\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G)"
         and "(ys,0) \<Turnstile> F \<R> G"
      then have "\<exists>(L, R)\<in>set [(\<box>(\<Or>\<^sub>l map fst ps), F \<R> G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using helper_globally[OF pcoversG]
        by (auto simp: split_def ltl_semantics)
      then have "\<exists>(L, R)\<in>set (release_iff fs gs F G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        unfolding release_iff_def
        apply clarsimp
        apply (drule bspec, fastforce)
        apply (clarsimp simp: split_def ltl_semantics)
        done
    }
    ultimately show ?thesis
      using FRG[unfolded release_cases] True by blast
   next
    case False
    then show ?thesis
      using FRG by (auto simp: release_iff_def lappend_inf ltl_semantics)
  qed
qed

lemma bcovers_release:
  assumes Gbcovers: "gs bcovers G"
  assumes Fbcovers: "fs bcovers F"
  shows "(release_iff fs gs F G) bcovers (F \<R> G)"
proof (rule bcoversI)
  fix xs ys L R
  assume LR: "(L,R) \<in> set (release_iff fs gs F G)"
    and L: "(xs, 0) \<Turnstile> L"
    and R: "(ys, 0) \<Turnstile> R"
  {
    assume "L = F \<R> G \<and>\<^sub>l \<not>\<^sub>lfinite\<^sub>l" and "R = True\<^sub>l"
    then have "(xs @@ ys, 0) \<Turnstile> F \<R> G"
      by (metis L lappend_inf ltl_finite_def ltl_conjE ltl_not_def)
  }
  moreover {
    fix ps L' R' L'' R''
    assume ps: "ps \<in> set (pow_list gs)"
      and LR': "(L',R') \<in> set fs"
      and L_def: "L = (\<Or>\<^sub>l map fst ps) \<U> ((\<Or>\<^sub>l map fst ps) \<and>\<^sub>l L')"
      and R_def: "R = (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'"
    obtain i :: nat where i: "i < llength xs"
      and L': "(ldrop i xs, 0) \<Turnstile> L'"
      and D: "(ldrop i xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst ps)"
      and j: "\<forall>j<i. (xs, j) \<Turnstile> \<Or>\<^sub>l map fst ps"
      using L L_def R R_def ltl_untilE by (auto elim: ltl_untilE simp: ldrop_simps)
    obtain L'' R'' where
        LR'': "(L'',R'') \<in> set gs" and L'': "(ldrop i xs,0) \<Turnstile> L''" and R'': "(ys,0) \<Turnstile> R''"
      apply (insert i D R)
      apply (clarsimp simp: ltl_sup_def ltl_inf_def ldrop_simps R_def)
      apply (drule (1) bspec)
      apply (frule in_set_pow_list[OF ps])
      apply clarsimp
      done
    have "(xs @@ ys, i) \<Turnstile> F"
      using bcoversE[OF Fbcovers LR' L'] i R R_def by (auto simp: ldrop_simps)
    moreover have "(xs @@ ys, i) \<Turnstile> G"
      using bcoversE[OF Gbcovers LR'' L'' R''] i R R_def by (auto simp: ldrop_simps)
    moreover have "\<forall>k < i. (xs @@ ys, k) \<Turnstile> G"
      using i j R Gbcovers
      apply (clarsimp simp: R_def ltl_sup_def)
      apply (erule_tac x=k in allE, clarsimp)
      apply (erule (1) bcoversE[OF _ in_set_pow_list[OF ps]])
      using ltl_drop_alt apply fastforce
       apply (fastforce simp: ltl_inf_def)
      apply (fastforce simp: ldrop_simps order_less_subst2)
      done
    ultimately have "(xs @@ ys, 0) \<Turnstile> F \<R> G"
      by (simp add: LTL_Release_def i ltl_untilI ltl_conj_def ltl_disj_def)
  }
  moreover {
    fix ps
    assume ps: "ps \<in> set (pow_list gs)"
      and L_def: "L = \<box>(\<Or>\<^sub>l map fst ps)"
      and R_def: "R = F \<R> G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)"
    then have "\<forall>k < llength xs. (xs @@ ys, k) \<Turnstile> G"
      using L R Gbcovers apply (clarsimp simp: L_def R_def)
      apply (erule_tac i=k in ltl_globallyE(1); clarsimp?)
      apply (clarsimp simp: ltl_inf_def ltl_sup_def)
      apply (frule in_set_pow_list[OF ps])
      using ltl_drop_alt by (fastforce elim!: bcoversE)
    then have "(xs @@ ys, 0) \<Turnstile> F \<R> G"
      using L L_def R R_def ltl_finite_def release_cases by blast
  }
  ultimately show "(xs @@ ys, 0) \<Turnstile> F \<R> G"
    using LR by (fastforce simp: release_iff_def split_def image_iff)
qed

lemma covers_release:
  assumes pcoversG: "gs covers G"
  assumes pcoversF: "fs covers F"
  shows "(release_iff fs gs F G) covers (F \<R> G)"
  using assms pcovers_release bcovers_release covers_iff by blast

lemma pcovers_inf:
  "gs pcovers G
  \<Longrightarrow> (G \<and>\<^sub>l infinite\<^sub>l, True\<^sub>l)#gs pcovers G"
  by (fastforce simp: ltl_pcover_def split_def ltl_semantics lappend_inf)

lemma bcovers_inf:
  "gs bcovers G
  \<Longrightarrow> (G \<and>\<^sub>l infinite\<^sub>l, True\<^sub>l)#gs bcovers G"
  by (fastforce simp: ltl_bcover_def split_def ltl_semantics lappend_inf)

lemma covers_inf:
  "gs covers G
  \<Longrightarrow> (G \<and>\<^sub>l infinite\<^sub>l, True\<^sub>l)#gs covers G"
  by (fastforce simp: ltl_cover_def split_def ltl_semantics lappend_inf)

end
