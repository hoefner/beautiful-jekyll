theory LTL_Cover_Weak
  imports LTL_Cover_Pre
begin

text \<open>Combine two covers @{term gs} and @{term fs} via conjunction.\<close>
definition conj_iff where
  "conj_iff xs ys \<equiv> [(L \<and>\<^sub>l L', R \<and>\<^sub>l R'). (L,R) \<leftarrow> xs, (L',R') \<leftarrow> ys]"

text \<open>Given a cover @{term gs} for @{term G}, compute a cover for @{term "\<box>G"}.\<close>
definition globally_iff where
  "globally_iff gs G \<equiv>
     [(\<box>(\<Or>\<^sub>l map fst ps), \<box>G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]"

text \<open>Given a cover @{term fs} for @{term F}, compute a cover for @{term "\<diamond>F"}.\<close>
definition finally_iff where
  "finally_iff fs F \<equiv> (True\<^sub>l,\<diamond>F) # [(\<diamond>L, R). (L,R) \<leftarrow> fs]"

text \<open>Given a cover @{term gs} for @{term G} and @{term fs} for @{term F},
      compute a cover for @{term "G \<U> F"}.\<close>
definition until_iff where
  "until_iff gs fs G F \<equiv>
     \<comment> \<open>Immediate satisfaction\<close>
     fs @
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L',R') \<leftarrow> fs] @
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps), G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]"

text \<open>Given a cover @{term fs} for @{term F} and @{term gs} for @{term G},
      compute a cover for @{term "F \<R> G"}.\<close>
definition release_iff where
  "release_iff fs gs F G \<equiv>
     \<comment> \<open>Satisfaction on LHS\<close>
     [((\<Or>\<^sub>l map fst ps) \<U> (L \<and>\<^sub>l L'), (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L,R) \<leftarrow> gs, (L',R') \<leftarrow> fs] @
     \<comment> \<open>Satisfaction on RHS\<close>
     [(\<box>(\<Or>\<^sub>l map fst ps), F \<R> G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]"

definition ltl_cover (infixl "covers\<^sup>+" 60) where
  "fs covers\<^sup>+ F \<equiv> \<forall>xs ys. lfinite xs \<and> \<not>lnull xs \<longrightarrow> (xs@@ys,0) \<Turnstile> F \<longleftrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R)"

definition ltl_pcover (infixl "pcovers\<^sup>+" 60) where
  "fs pcovers\<^sup>+ F \<equiv> \<forall>xs ys. lfinite xs \<and> \<not>lnull xs \<longrightarrow> (xs@@ys,0) \<Turnstile> F \<longrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R)"

definition ltl_bcover (infixl "bcovers\<^sup>+" 60) where
  "fs bcovers\<^sup>+ F \<equiv> \<forall>xs ys. lfinite xs \<and> \<not>lnull xs \<longrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R) \<longrightarrow> (xs@@ys,0) \<Turnstile> F"

lemma covers_iff:
  "fs covers\<^sup>+ F \<longleftrightarrow> fs pcovers\<^sup>+ F \<and> fs bcovers\<^sup>+ F"
  by (fastforce simp: ltl_cover_def ltl_pcover_def ltl_bcover_def split_def)

lemma coversI:
  "\<lbrakk> fs pcovers\<^sup>+ F; fs bcovers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> fs covers\<^sup>+ F"
  by (simp add: covers_iff)

lemma coversD:
  "\<lbrakk> fs covers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> fs pcovers\<^sup>+ F \<and> fs bcovers\<^sup>+ F"
  by (simp add: covers_iff)

lemma coversD1:
  "\<lbrakk> fs covers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> fs pcovers\<^sup>+ F"
  by (simp add: covers_iff)

lemma coversD2:
  "\<lbrakk> fs covers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> fs bcovers\<^sup>+ F"
  by (simp add: covers_iff)

lemma pcoversI:
  "\<lbrakk> \<And>xs ys. \<lbrakk> (xs@@ys,0) \<Turnstile> F; lfinite xs; \<not>lnull xs \<rbrakk> \<Longrightarrow> \<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R \<rbrakk>
     \<Longrightarrow> fs pcovers\<^sup>+ F"
  by (auto simp: ltl_pcover_def)

lemma pcoversE:
  "\<lbrakk> fs pcovers\<^sup>+ F; (xs@@ys,0) \<Turnstile> F; lfinite xs; \<not>lnull xs;
     \<And>L R. \<lbrakk> (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk> \<Longrightarrow> P \<rbrakk>
     \<Longrightarrow> P"
  by (auto simp: ltl_pcover_def)

lemma bcoversI:
  "\<lbrakk> \<And>xs ys L R. \<lbrakk> (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R; lfinite xs; \<not>lnull xs \<rbrakk> \<Longrightarrow> (xs@@ys,0) \<Turnstile> F \<rbrakk>
     \<Longrightarrow> fs bcovers\<^sup>+ F"
  by (auto simp: ltl_bcover_def)

lemma bcoversE:
  "\<lbrakk> fs bcovers\<^sup>+ F; (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R; lfinite xs; \<not>lnull xs; (xs@@ys,0) \<Turnstile> F \<Longrightarrow> P \<rbrakk>
     \<Longrightarrow> P"
  by (auto simp: ltl_bcover_def)

lemma pcovers_weaken:
  "\<lbrakk> fs pcovers\<^sup>+ F; \<And>xs ys L R. \<lbrakk> lfinite xs; \<not>lnull xs; (L,R) \<in> set fs; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk>
                                 \<Longrightarrow> \<exists>(L',R') \<in> set fs'. (xs,0) \<Turnstile> L' \<and> (ys,0) \<Turnstile> R' \<rbrakk>
     \<Longrightarrow> fs' pcovers\<^sup>+ F"
  by (fastforce simp: ltl_pcover_def split_def)

lemma pcovers_subst:
  "\<lbrakk> fs' pcovers\<^sup>+ F; fs' = fs \<rbrakk>
     \<Longrightarrow> fs pcovers\<^sup>+ F"
  by simp

lemma pcovers_triv:
  "fs pcovers\<^sup>+ F \<Longrightarrow> fs pcovers\<^sup>+ F"
  by simp

lemma pcovers_False:
  "fs pcovers\<^sup>+ False\<^sub>l"
  by (simp add: ltl_pcover_def)

lemma bcovers_weaken:
  "\<lbrakk> fs bcovers\<^sup>+ F; \<And>xs ys L R. \<lbrakk> lfinite xs; \<not>lnull xs; (L,R) \<in> set fs'; (xs,0) \<Turnstile> L; (ys,0) \<Turnstile> R \<rbrakk>
                                 \<Longrightarrow> \<exists>(L',R') \<in> set fs. (xs,0) \<Turnstile> L' \<and> (ys,0) \<Turnstile> R' \<rbrakk>
     \<Longrightarrow> fs' bcovers\<^sup>+ F"
  by (fastforce simp: ltl_bcover_def split_def)

lemma bcovers_weaken':
  "\<lbrakk> fs bcovers\<^sup>+ F'; F' \<Longrightarrow>\<^sub>l F \<rbrakk>
     \<Longrightarrow> fs bcovers\<^sup>+ F"
  by (simp add: ltl_bcover_def)

lemma bcovers_append:
  "\<lbrakk> xs bcovers\<^sup>+ F; ys bcovers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> xs @ ys bcovers\<^sup>+ F"
  by (fastforce simp: ltl_bcover_def)

lemma bcovers_appendD1:
  "\<lbrakk> xs @ ys bcovers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> xs bcovers\<^sup>+ F"
  by (fastforce simp: ltl_bcover_def)

lemma bcovers_appendD2:
  "\<lbrakk> xs @ ys bcovers\<^sup>+ F \<rbrakk>
     \<Longrightarrow> ys bcovers\<^sup>+ F"
  by (fastforce simp: ltl_bcover_def)

lemma bcovers_subst:
  "\<lbrakk> fs' bcovers\<^sup>+ F; fs' = fs \<rbrakk>
     \<Longrightarrow> fs bcovers\<^sup>+ F"
  by simp

lemma bcovers_triv:
  "fs bcovers\<^sup>+ F \<Longrightarrow> fs bcovers\<^sup>+ F"
  by simp

lemma bcovers_False:
  "[(False\<^sub>l,False\<^sub>l)] bcovers\<^sup>+ F"
  by (simp add: ltl_bcover_def)

lemma covers_weaken:
  "\<lbrakk> fs covers\<^sup>+ F; \<And>xs ys. (\<exists>(L,R) \<in> set fs'. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R)
                     \<longleftrightarrow> (\<exists>(L,R) \<in> set fs. (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R) \<rbrakk>
     \<Longrightarrow> fs' covers\<^sup>+ F"
  by (fastforce simp: ltl_cover_def split_def)

lemma covers_subst:
  "\<lbrakk> fs' covers\<^sup>+ F; fs' = fs \<rbrakk>
     \<Longrightarrow> fs covers\<^sup>+ F"
  by simp

lemma covers_triv:
  "fs covers\<^sup>+ F \<Longrightarrow> fs covers\<^sup>+ F"
  by simp

text \<open>Atom\<close>

lemma pcovers_atom:
  "[(\<A>(P), True\<^sub>l)] pcovers\<^sup>+ \<A>(P)"
  apply (rule pcoversI)
  apply (case_tac xs; case_tac ys; clarsimp simp: ltl_semantics enat_0)
  done

lemma bcovers_atom:
  "[(\<A>(P), True\<^sub>l)] bcovers\<^sup>+ \<A>(P)"
  apply (rule bcoversI)
  apply (case_tac xs; case_tac ys; auto simp: ltl_semantics enat_0)
  done

lemma covers_atom:
  "[(\<A>(P), True\<^sub>l)] covers\<^sup>+ \<A>(P)"
  using pcovers_atom bcovers_atom covers_iff by blast


text \<open>Conjunction\<close>

lemma pcovers_conj:
  "\<lbrakk> fs pcovers\<^sup>+ F; gs pcovers\<^sup>+ G \<rbrakk>
     \<Longrightarrow> (conj_iff fs gs) pcovers\<^sup>+ (F \<and>\<^sub>l G)"
  apply (rule pcoversI)
  apply (clarsimp simp: ltl_semantics)
  apply (erule (3) pcoversE)+
  by (fastforce simp: conj_iff_def ltl_semantics)

lemma bcovers_conj:
  "\<lbrakk> fs bcovers\<^sup>+ F; gs bcovers\<^sup>+ G \<rbrakk>
     \<Longrightarrow> (conj_iff fs gs) bcovers\<^sup>+ (F \<and>\<^sub>l G)"
  by (fastforce intro: bcoversI elim: bcoversE simp: conj_iff_def ltl_semantics)

lemma covers_conj:
  "\<lbrakk> fs covers\<^sup>+ F; gs covers\<^sup>+ G \<rbrakk>
     \<Longrightarrow> conj_iff fs gs covers\<^sup>+ (F \<and>\<^sub>l G)"
  using pcovers_conj bcovers_conj covers_iff by blast


text \<open>Disjunction\<close>

lemma pcovers_disj:
  "\<lbrakk> fs pcovers\<^sup>+ F; gs pcovers\<^sup>+ G \<rbrakk>
     \<Longrightarrow> fs@gs pcovers\<^sup>+ (F \<or>\<^sub>l G)"
  apply (rule pcoversI)
  apply (erule ltl_disjE)
  by (erule (3) pcoversE, fastforce)+

lemma bcovers_disj:
  "\<lbrakk> fs bcovers\<^sup>+ F; gs bcovers\<^sup>+ G \<rbrakk>
     \<Longrightarrow> fs@gs bcovers\<^sup>+ (F \<or>\<^sub>l G)"
  by (fastforce elim: bcoversE intro: bcoversI ltl_disjI1 ltl_disjI2)

lemma bcovers_disjI1:
  "\<lbrakk> fs bcovers\<^sup>+ F \<rbrakk> \<Longrightarrow> fs bcovers\<^sup>+ (F \<or>\<^sub>l G)"
  by (fastforce elim: bcoversE intro: bcoversI ltl_disjI1 ltl_disjI2)

lemma bcovers_disjI2:
  "\<lbrakk> gs bcovers\<^sup>+ G \<rbrakk> \<Longrightarrow> gs bcovers\<^sup>+ (F \<or>\<^sub>l G)"
  by (fastforce elim: bcoversE intro: bcoversI ltl_disjI1 ltl_disjI2)

lemma covers_disj:
  "\<lbrakk> fs covers\<^sup>+ F; gs covers\<^sup>+ G \<rbrakk>
     \<Longrightarrow> fs@gs covers\<^sup>+ (F \<or>\<^sub>l G)"
  using pcovers_disj bcovers_disj covers_iff by blast


text \<open>Next\<close>

lemma pcovers_next:
  assumes "fs pcovers\<^sup>+ F"
  shows
  "(one\<^sub>l,F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l) # [(\<circle>L,R). (L,R) \<leftarrow> fs] pcovers\<^sup>+ \<circle>F"
  apply (rule pcoversI)
  apply (case_tac xs, clarsimp simp: ltl_semantics enat_0)
  apply (case_tac "ltl xs")
   apply (clarsimp simp: ltl_semantics enat_0 split_def)
  apply (metis One_nat_def Suc_ile_eq llength_LNil llist.collapse(1) ltl_weak_next_LCons ltl_weak_next_def not_one_le_zero one_eSuc one_enat_def)
  apply simp
  apply (rule disjI2)+
  apply (clarsimp simp: ltl_next_LCons enat_0 split_def)
  by (metis assms lappend_code(2) lfinite_code(2) not_lnull_conv split_pairs pcoversE)

lemma bcovers_next:
  assumes "fs bcovers\<^sup>+ F"
  shows
  "(one\<^sub>l,F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l) # [(\<circle>L,R). (L,R) \<leftarrow> fs] bcovers\<^sup>+ \<circle>F"
  apply (rule bcoversI)
  apply clarsimp
  apply (case_tac xs)
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff)
  apply (case_tac "ltl xs")
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff enat_0)
   apply (metis Suc_ile_eq enat_0 gr_zeroI ldrop_eSuc_LCons llength_eq_0 ltl_drop_alt)
  apply (elim disjE)
    apply (clarsimp simp: ltl_semantics enat_0_iff)
    apply (metis One_nat_def eSuc_inject one_eSuc one_enat_def zero_ne_eSuc)
  apply (clarsimp simp: ltl_next_LCons enat_0)
  using assms by (fastforce elim: bcoversE)

lemma covers_next:
  assumes "fs covers\<^sup>+ F"
  shows
  "(one\<^sub>l,F \<and>\<^sub>l \<not>\<^sub>lnull\<^sub>l) # [(\<circle>L,R). (L,R) \<leftarrow> fs] covers\<^sup>+ \<circle>F"
  using pcovers_next bcovers_next covers_iff assms by blast

lemma pcovers_weak_next:
  assumes "fs pcovers\<^sup>+ F"
  shows
  "[(one\<^sub>l,null\<^sub>l),(one\<^sub>l,F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] pcovers\<^sup>+ \<ominus>F"
  apply (rule pcoversI)
  apply (case_tac xs, clarsimp simp: ltl_semantics enat_0)
  apply (case_tac "ltl xs")
   apply (clarsimp simp: ltl_semantics enat_0 split_def)
   apply (metis One_nat_def Suc_ile_eq enat_0 ldrop_eSuc_LCons llength_eq_0 ltl_drop_alt one_eSuc one_enat_def zero_less_iff_neq_zero)
  apply simp
  apply (rule disjI2)+
  apply (clarsimp simp: ltl_weak_next_LCons ltl_next_LCons enat_0 split_def)
  by (metis assms fst_conv lappend_code(2) lfinite_code(2) llist.disc(2) pcoversE snd_conv)

lemma bcovers_weak_next:
  assumes "fs bcovers\<^sup>+ F"
  shows
   "[(one\<^sub>l,null\<^sub>l),(one\<^sub>l,F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] bcovers\<^sup>+ \<ominus>F"
  apply (rule bcoversI)
  apply clarsimp
  apply (case_tac xs)
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff)
  apply (case_tac "ltl xs")
   apply (elim disjE; clarsimp simp: ltl_semantics enat_0_iff enat_0)
   apply (metis Suc_ile_eq enat_0 gr_zeroI ldrop_eSuc_LCons llength_eq_0 ltl_drop_alt)
  apply (elim disjE)
    apply (clarsimp simp: ltl_semantics enat_0_iff)
    apply (metis One_nat_def eSuc_inject one_eSuc one_enat_def zero_ne_eSuc)
   apply (clarsimp simp: ltl_semantics enat_0)
   apply (metis One_nat_def eSuc_inject one_eSuc one_enat_def zero_ne_eSuc)
  apply (clarsimp simp: ltl_weak_next_LCons enat_0 ltl_next_LCons)
  using assms by (fastforce elim: bcoversE)

lemma covers_weak_next:
  assumes "fs covers\<^sup>+ F"
  shows
   "[(one\<^sub>l,null\<^sub>l),(one\<^sub>l,F)] @ [(\<circle>L,R). (L,R) \<leftarrow> fs] covers\<^sup>+ \<ominus>F"
  using pcovers_weak_next bcovers_weak_next covers_iff assms by blast


text \<open>Finally\<close>

lemma pcovers_finally:
  "fs pcovers\<^sup>+ F \<Longrightarrow> finally_iff fs F pcovers\<^sup>+ \<diamond>F"
  apply (rule pcoversI)
  apply (clarsimp simp: finally_cases)
  apply (erule disjE)
   apply clarsimp
   apply (clarsimp simp: finally_iff_def split_def)
   apply (erule (1) pcoversE, simp, simp)
   apply (drule (1) bspec, clarsimp)
   apply (metis finally_cases lappend_LNil2)
  apply (clarsimp simp: finally_iff_def ltl_finite_def)
  done

lemma bcovers_finally:
  "fs bcovers\<^sup>+ F \<Longrightarrow> finally_iff fs F bcovers\<^sup>+ \<diamond>F"
  apply (rule bcoversI)
  apply (clarsimp simp: finally_cases)
  apply (clarsimp simp: finally_iff_def)
  apply (erule disjE; clarsimp simp: ltl_finite_def)
  by (meson bcoversE leD lfinite_ldrop lnull_ldrop ltl_drop_alt ltl_finally_def)

lemma covers_finally:
  "fs covers\<^sup>+ F \<Longrightarrow> (finally_iff fs F) covers\<^sup>+ (\<diamond>F)"
  using pcovers_finally bcovers_finally covers_iff by blast


text \<open>Globally\<close>

lemma helper_globally:
  "\<lbrakk> lfinite xs; gs pcovers\<^sup>+ G; \<forall>i < llength xs. (xs @@ ys, i) \<Turnstile> G; \<not>lnull xs \<rbrakk>
     \<Longrightarrow> \<exists>LR \<in> set (pow_list gs). LR \<noteq> [] \<and> (xs,0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst LR)
                                \<and> (ys,0) \<Turnstile> (\<And>\<^sub>l map snd LR)"
  proof (induct xs rule: lfinite_induct)
  case (LNil xs)
  then show ?case
    by (fastforce intro: rev_bexI[OF nil_in_pow_list] simp: ltl_semantics)
next
  case (LCons xs)
  have "\<forall>i. enat i < llength (ltl xs) \<longrightarrow> (ltl xs @@ ys, i) \<Turnstile> G"
    apply clarsimp
    apply (prop_tac "enat (Suc i) < llength xs")
     apply (metis ldropn_eq_LNil ldropn_ltl linorder_not_less)
    using LCons(2) LCons(5)
    by (metis lappend.disc_iff(2) lappend_code(2) ldrop_less_length lhd_LCons_ltl linorder_not_less lnull_ldrop ltl_weak_next_LCons ltl_weak_next_def)
  then obtain lr
    where lr: "lr \<in> set (pow_list gs)"
      and xs: "(ltl xs, 0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst lr)"
      and ys: "(ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lr)"
    using LCons
    by (metis list.map(1) llength_eq_0 ltl_inf_empty ltl_globallyI ltl_true_def nil_in_pow_list not_iless0)
  obtain L and R where LR: "(L, R) \<in> set gs" and L: "(xs, 0) \<Turnstile> L" and R: "(ys, 0) \<Turnstile> R"
    apply (insert LCons(2) LCons(4) LCons(5))
    apply (erule_tac x=0 in allE, clarsimp simp: enat_0)
    apply (erule (1) pcoversE)
    using LCons by (fastforce elim: pcoversE)+
  obtain zs where "zs \<noteq> []" and "zs \<in> set (pow_list gs)" and zs_set: "set zs = insert (L, R) (set lr)"
    using one_in_pow_list[OF LR] pow_list_un[OF lr]
    by (metis Un_insert_right empty_iff list.set(1) list.set_intros(1) list.simps(15) sup_bot.right_neutral)
  moreover have "(xs, 0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst zs)"
    apply (rule ltl_globallyI)
    apply (case_tac i; clarsimp simp: enat_0)
     apply (metis L ltl_supD zs_set insertI1 set_zip_leftD zip_map_fst_snd)
    apply (insert xs)
    apply (erule_tac i=nat in ltl_globallyE(1); clarsimp?)
     apply (metis ldropn_eq_LNil ldropn_ltl linorder_not_less)
    apply (simp only: ltl_sup_def)
    apply (insert zs_set)
    apply clarsimp
    by (metis LCons.hyps(2) fst_conv lhd_LCons_ltl ltl_weak_next_LCons ltl_weak_next_def)
  moreover have "(ys, 0) \<Turnstile> (\<And>\<^sub>l map snd zs)"
    apply (clarsimp simp: ltl_inf_def)
    by (metis R insertE ltl_inf_def set_zip_rightD snd_eqD ys zip_map_fst_snd zs_set)
  ultimately show ?case
    by meson
qed

lemma pcovers_globally:
  assumes A: "gs pcovers\<^sup>+ G"
  shows "(globally_iff gs G) pcovers\<^sup>+ (\<box>G)"
proof (rule pcoversI)
  fix xs ys
  assume xsys: "(xs @@ ys, 0) \<Turnstile> \<box>G"
  and assms: "lfinite xs" "\<not> lnull xs"
  then show "\<exists>(L, R)\<in>set (globally_iff gs G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  proof (cases "lfinite xs")
    case True then have finite: "lfinite xs" .
    have xs: "\<forall>i < llength xs. (xs @@ ys, i) \<Turnstile> G"
      and ys: "(ys, 0) \<Turnstile> \<box>G"
      using globally_cases finite xsys by auto
    have "\<exists>LR\<in>set (pow_list gs). LR \<noteq> [] \<and>
            (xs,0) \<Turnstile> \<box>(\<Or>\<^sub>l map fst LR) \<and>
            (ys,0) \<Turnstile> (\<And>\<^sub>l map snd LR) \<and>\<^sub>l \<box>G"
      using finite helper_globally xs ys A ltl_conj_def assms by metis
    then show ?thesis
      by (auto simp: globally_iff_def ltl_conj_def)
  next
    case False
    then show ?thesis
      using xsys A assms by (auto simp: globally_iff_def lappend_inf ltl_semantics)
  qed
qed

lemma bcovers_globally:
  assumes A: "gs bcovers\<^sup>+ G"
  shows "(globally_iff gs G) bcovers\<^sup>+ (\<box>G)"
proof (rule bcoversI)
  fix xs ys L R
  assume LR: "(L,R) \<in> set (globally_iff gs G)"
    and L: "(xs, 0) \<Turnstile> L"
    and R: "(ys, 0) \<Turnstile> R"
  and assms: "lfinite xs" "\<not> lnull xs"
  then show "(xs @@ ys, 0) \<Turnstile> \<box>G"
    apply (clarsimp simp: globally_iff_def)
    apply (rule ltl_globallyI)
    apply (case_tac "i < llength xs")
     apply (erule (2) ltl_globallyE)
     apply (clarsimp simp: ltl_inf_def ltl_sup_def)
     apply (drule (1) bspec, clarsimp)
     apply (drule (1) in_set_pow_list)
     apply (subst (asm) ltl_drop_alt)
     apply (drule_tac n=0 and i=i in ltl_ldrop'[OF _ _ refl], clarsimp)
     apply (erule (2) bcoversE[OF A])
     apply (clarsimp simp: enat_0)
    using ltl_drop_alt apply fastforce
    using ldrop_simps(1) apply auto[1]
    by (metis enat_ile enat_ord_simps(1) ldrop_llength lfinite_conv_llength_enat ltl_drop_alt ltl_globallyD not_le_imp_less)
qed

lemma covers_globally:
  "gs covers\<^sup>+ G \<Longrightarrow> (globally_iff gs G) covers\<^sup>+ (\<box>G)"
  using pcovers_globally bcovers_globally covers_iff by blast


text \<open>Until\<close>

lemma helper_until:
  "\<lbrakk> lfinite xs; \<not>lnull xs; gs pcovers\<^sup>+ G; fs pcovers\<^sup>+ F;
     enat i < llength xs; (ldrop i xs @@ ys, 0) \<Turnstile> F; \<forall>j < i. (xs @@ ys, j) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>lrs\<in>set (pow_list gs). \<exists>LR\<in>set fs.
          (xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> (fst LR) \<and>
          (ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l snd LR"
proof (induct xs arbitrary: i rule: lfinite_induct)
  case (LNil xs)
  then show ?case
    by (fastforce intro: rev_bexI[OF nil_in_pow_list] simp: ltl_semantics)
next
  case(LCons xs)
  then show ?case
  proof (cases i)
    case 0
    then show ?thesis
      apply (rule_tac x="[]" in bexI)
       apply (clarsimp simp: False_Until_F)
       apply (metis LCons.hyps LCons.prems fst_conv ldrop_0 lnull_ldrop ltl_null_def ltl_conj_def ltl_not_def snd_conv pcoversE zero_enat_def)
      using nil_in_pow_list by auto
  next
    case (Suc n)
    then have "enat n < llength (ltl xs)"
      by (metis LCons.prems ldropn_eq_LNil ldropn_ltl leD not_le_imp_less)
    moreover have "(ldrop n (ltl xs) @@ ys, 0) \<Turnstile> F"
      by (metis LCons.prems Suc ldrop_enat ldropn_ltl)
    moreover have "\<forall>j<n. (ltl xs @@ ys, j) \<Turnstile> G"
      using Suc LCons(9) apply -
      apply clarsimp
      apply (erule_tac x="Suc j" in allE)
      apply clarsimp
      by (metis LCons.hyps(2) eSuc_enat lappend.ctr(2) lappend.simps(4) ldrop_eSuc_LCons ltl_drop_alt ltl_lappend)
    ultimately obtain lrs L R where lrs: "lrs\<in>set (pow_list gs)" and "(L,R)\<in>set fs"
      and xs_until: "(ltl xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> L" and "(ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l R"
      using LCons.hyps(3) LCons.prems(4)
      by (metis LCons.prems(2) LCons.prems(3) llength_LNil llist.collapse(1) not_less_zero prod.collapse)
    obtain L0 R0 where LR0: "(L0,R0) \<in> set gs" and L0: "(xs, 0) \<Turnstile> L0" and R0: "(ys, 0) \<Turnstile> R0"
      using LCons.prems(1) LCons.prems(5) Suc pcoversE
      using LCons.hyps(1) LCons.prems(2) LCons.prems(3) LCons.prems(6) by blast
    obtain zs where "zs \<in> set (pow_list gs)" and zs_set: "set zs = insert (L0, R0) (set lrs)"
      using one_in_pow_list[OF LR0] pow_list_un[OF lrs] by force
    moreover have "(xs, 0) \<Turnstile>(\<Or>\<^sub>l map fst zs) \<U> L"
      apply (insert xs_until)
      apply (erule ltl_untilE, clarsimp)
      apply (rule_tac j="Suc i" in ltl_untilI; clarsimp?)
        apply (metis LCons.hyps(2) lhd_LCons_ltl ltl_next_LCons ltl_next_def)
       apply (metis ldrop_eSuc_ltl ldropn_eq_LNil leD not_le_imp_less)
      apply (case_tac k; clarsimp)
       apply (metis L0 insertI1 zs_set in_set_zipE ltl_sup_def zip_map_fst_snd)
      apply (subgoal_tac "(ltl xs, nat) \<Turnstile> \<Or>\<^sub>l map fst zs")
       apply (metis LCons.hyps(2) eSuc_enat ldrop_eSuc_LCons lhd_LCons_ltl ltl_drop_alt)
      apply (erule_tac x=nat in allE)
      apply clarsimp
      apply (insert zs_set)
      apply (erule ltl_sup_subsetE)
      apply auto
      done
    moreover have "(ys, 0) \<Turnstile> (\<And>\<^sub>l map snd zs) \<and>\<^sub>l R"
      apply (rule ltl_conjI)
       apply (clarsimp simp: ltl_inf_def zs_set R0)
       apply (metis \<open>(ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l R\<close> in_set_zipE ltl_inf_def ltl_conjE zip_map_fst_snd)+
      done
    ultimately show "\<exists>lrs\<in>set (pow_list gs).
                    \<exists>LR\<in>set fs. (xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> fst LR \<and> (ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l snd LR"
      apply -
      apply (erule rev_bexI)
      by (metis \<open>(L, R) \<in> set fs\<close> fst_conv snd_conv)
  qed
qed

lemma helper_until':
  "\<lbrakk> lfinite xs; \<not>lnull xs; gs pcovers\<^sup>+ G; fs pcovers\<^sup>+ F;
     enat i < llength xs; (ldrop i xs @@ ys, 0) \<Turnstile> F; \<forall>j < i. (xs @@ ys, j) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>(L,R)\<in>set (fs @ [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L',R') \<leftarrow> fs]).
          (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R"
  apply (frule (6) helper_until)
  apply clarsimp
  apply (case_tac "lrs = []")
   apply (clarsimp simp: False_Until_F)
   apply blast
  apply (rule_tac x="((\<Or>\<^sub>l map fst lrs) \<U> a, (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l b)" in bexI)
   apply (clarsimp simp: ltl_semantics)
  apply auto
  done

lemma pcovers_until:
  assumes pcoversG: "gs pcovers\<^sup>+ G"
  assumes pcoversF: "fs pcovers\<^sup>+ F"
  shows "(until_iff gs fs G F) pcovers\<^sup>+ (G \<U> F)"
proof (rule pcoversI)
  fix xs ys
  assume GUF: "(xs @@ ys, 0) \<Turnstile> G \<U> F"
  and assms: "lfinite xs" "\<not> lnull xs"
  moreover show "\<exists>(L, R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  proof (cases "lfinite xs")
    case True
    {
      fix i :: nat
      assume "i < llength xs"
        and "(ldrop i xs @@ ys, 0) \<Turnstile> F"
        and "(\<forall>j < i. (xs @@ ys, j) \<Turnstile> G)"
      then have " \<exists>(L,R)\<in>set (fs @ [((\<Or>\<^sub>l map fst ps) \<U> L', (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L',R') \<leftarrow> fs]).
          (xs,0) \<Turnstile> L \<and> (ys,0) \<Turnstile> R"
        using assms pcoversG pcoversF by (fastforce intro!: helper_until')
      then have "\<exists>(L,R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        apply (clarsimp simp: until_iff_def split_def)
        by (metis (no_types, lifting) UN_I Un_iff fst_conv snd_eqD)
    }
    moreover {
      assume "(\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G)"
         and "(ys,0) \<Turnstile> G \<U> F"
      then have "\<exists>(L, R)\<in>set [(\<box>(\<Or>\<^sub>l map fst ps), G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using True helper_globally[OF True pcoversG] assms
        by (auto simp: split_def ltl_conj_def)
      then have "\<exists>(L, R)\<in>set (until_iff gs fs G F). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        unfolding until_iff_def
        by (metis (no_types, lifting) Un_iff set_append)
    }
    ultimately show ?thesis
      using GUF[unfolded until_cases] by fastforce
   next
    case False
    then show ?thesis
      using GUF assms by (auto simp: until_iff_def lappend_inf ltl_semantics)
  qed
qed

lemma bcovers_until:
  assumes Gbcovers: "gs bcovers\<^sup>+ G"
  assumes Fbcovers: "fs bcovers\<^sup>+ F"
  shows "(until_iff gs fs G F) bcovers\<^sup>+ (G \<U> F)"
proof (rule bcoversI)
  fix xs ys L R
  assume LR: "(L,R) \<in> set (until_iff gs fs G F)"
    and L: "(xs, 0) \<Turnstile> L"
    and R: "(ys, 0) \<Turnstile> R"
  and assms: "lfinite xs" "\<not> lnull xs"
  {
    assume "(L,R) \<in> set fs"
    then have "(xs @@ ys, 0) \<Turnstile> G \<U> F"
      by (metis Fbcovers L R assms(1) assms(2) bcoversE enat_0 gr_zeroI lappend.disc(2) llength_eq_0 until_now)
  }
  moreover {
    fix ps L' R'
    assume ps: "ps \<in> set (pow_list gs) - {[]}"
      and LR': "(L',R') \<in> set fs"
      and L_def: "L = (\<Or>\<^sub>l map fst ps) \<U> L'"
      and R_def: "R = (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'"
    obtain ps: "ps \<in> set (pow_list gs)"
      using ps by auto
    obtain i :: nat where i: "i < llength xs"
      and L': "(ldrop i xs, 0) \<Turnstile> L'"
      and j: "\<forall>j<i. (xs, j) \<Turnstile> \<Or>\<^sub>l map fst ps"
      using L L_def ltl_untilE by (auto elim: ltl_untilE simp: ldrop_simps)
    have "(xs @@ ys, i) \<Turnstile> F"
      using bcoversE[OF Fbcovers LR' L'] i R R_def ldrop_simps
      by (metis assms(1) leD lfinite_ldrop lnull_ldrop ltl_conjE)
    moreover have "\<forall>k < i. (xs @@ ys, k) \<Turnstile> G"
      using i j R Gbcovers
      apply (clarsimp simp: R_def ltl_sup_def)
      apply (erule_tac x=k in allE, clarsimp)
      apply (erule (1) bcoversE[OF _ in_set_pow_list[OF ps]])
      using ltl_drop_alt apply fastforce
          apply (fastforce simp: ltl_inf_def)
      using assms apply simp
        apply (meson enat_ord_simps(2) leD lnull_ldrop order_less_subst2)
      apply (fastforce simp: ldrop_simps order_less_subst2)
      done
    ultimately have "(xs @@ ys, 0) \<Turnstile> G \<U> F"
      by (simp add: i ltl_untilI)
  }
  moreover {
    fix ps
    assume ps: "ps \<in> set (pow_list gs)"
      and L_def: "L = \<box>(\<Or>\<^sub>l map fst ps)"
      and R_def: "R = G \<U> F \<and>\<^sub>l (\<And>\<^sub>l map snd ps)"
    then have "\<forall>k < llength xs. (xs @@ ys, k) \<Turnstile> G"
      using L R Gbcovers apply (clarsimp simp: L_def R_def)
      apply (erule_tac i=k in ltl_globallyE(1); clarsimp?)
      apply (clarsimp simp: ltl_inf_def ltl_sup_def)
      apply (frule in_set_pow_list[OF ps])
      using ltl_drop_alt assms by (fastforce elim!: bcoversE)
    then have "(xs @@ ys, 0) \<Turnstile> G \<U> F"
      using L L_def R R_def ltl_finite_def until_cases assms by blast
  }
  ultimately show "(xs @@ ys, 0) \<Turnstile> G \<U> F"
    using LR by (fastforce simp: until_iff_def split_def image_iff)
qed

lemma covers_until:
  assumes pcoversG: "gs covers\<^sup>+ G"
  assumes pcoversF: "fs covers\<^sup>+ F"
  shows "(until_iff gs fs G F) covers\<^sup>+ (G \<U> F)"
  using assms pcovers_until bcovers_until covers_iff by blast


text \<open>Release\<close>

lemma helper_release:
  "\<lbrakk> lfinite xs; \<not>lnull xs; fs pcovers\<^sup>+ F; gs pcovers\<^sup>+ G;
     enat i < llength xs; (ldrop i xs @@ ys, 0) \<Turnstile> F; \<forall>j \<le> i. (xs @@ ys, j) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>lrs\<in>set (pow_list gs). \<exists>LR\<in>set gs. \<exists>LR'\<in>set fs.
          (xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst lrs) \<U> (fst LR \<and>\<^sub>l fst LR') \<and>
          (ys, 0) \<Turnstile> (\<And>\<^sub>l map snd lrs) \<and>\<^sub>l snd LR \<and>\<^sub>l snd LR'"
  apply (frule (5) helper_until[where F="G \<and>\<^sub>l F" and G=G and ys=ys, OF _ _ _ pcovers_conj];
         clarsimp simp: ltl_semantics ldrop_simps conj_iff_def)
  apply (metis fst_conv snd_conv)
  done

lemma helper_release':
  "\<lbrakk> lfinite xs; \<not>lnull xs; fs pcovers\<^sup>+ F; gs pcovers\<^sup>+ G;
     enat i < llength xs; (ldrop i xs @@ ys, 0) \<Turnstile> F; \<forall>j \<le> i. (xs @@ ys, j) \<Turnstile> G \<rbrakk>
     \<Longrightarrow> \<exists>(L,R) \<in> set ([((\<Or>\<^sub>l map fst ps) \<U> (L \<and>\<^sub>l L'), (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L,R) \<leftarrow> gs, (L',R') \<leftarrow> fs]).
          (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  apply (frule (6) helper_release)
  apply clarsimp
  apply (rename_tac GL GR FL FR)
  apply (drule (1) pow_list_un[OF _ one_in_pow_list])
  apply clarsimp
  apply (prop_tac "(xs, 0) \<Turnstile> (\<Or>\<^sub>l map fst zs) \<U> (GL \<and>\<^sub>l FL)")
   apply (auto simp: ltl_semantics ltl_sup_def)[1]
  apply (prop_tac "(ys, 0) \<Turnstile> \<And>\<^sub>l map snd zs")
   apply (auto simp: ltl_inf_def)[1]
  apply (rule_tac x=zs in rev_bexI, clarsimp)
  apply (rule_tac x="(GL,GR)" in rev_bexI, clarsimp)
  apply (rule_tac x="(\<Or>\<^sub>l map fst zs) \<U> (GL \<and>\<^sub>l FL)" in exI)
  apply (rule_tac x="(\<And>\<^sub>l map snd zs) \<and>\<^sub>l GR \<and>\<^sub>l FR" in exI)
  apply (auto simp: ltl_conj_def)
  done

lemma pcovers_release:
  assumes pcoversG: "gs pcovers\<^sup>+ G"
  assumes pcoversF: "fs pcovers\<^sup>+ F"
  shows "(release_iff fs gs F G) pcovers\<^sup>+ (F \<R> G)"
proof (rule pcoversI)
  fix xs ys
  assume FRG: "(xs @@ ys, 0) \<Turnstile> F \<R> G"
    and "lfinite xs"
    and not_null: "\<not>lnull xs"
  moreover show "\<exists>(L, R)\<in>set (release_iff fs gs F G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
  proof (cases "lfinite xs")
    case True
    {
      fix i :: nat
      assume "i < llength xs"
        and "(ldrop i xs @@ ys, 0) \<Turnstile> F"
        and "(\<forall>j \<le> i. (xs @@ ys, j) \<Turnstile> G)"
      then have "\<exists>(L,R) \<in> set ([((\<Or>\<^sub>l map fst ps) \<U> (L \<and>\<^sub>l L'), (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R \<and>\<^sub>l R'). ps \<leftarrow> pow_list gs, ps \<noteq> [], (L,R) \<leftarrow> gs, (L',R') \<leftarrow> fs]).
                          (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using True finite pcoversG pcoversF not_null
        by (fastforce simp: split_def intro!: helper_release')
      then have "\<exists>(L,R)\<in>set (release_iff fs gs F G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        by (fastforce simp: release_iff_def split_def)
    }
    moreover {
      assume "(\<forall>i < llength xs. (xs@@ys,i) \<Turnstile> G)"
         and "(ys,0) \<Turnstile> F \<R> G"
      then have "\<exists>(L, R)\<in>set [(\<box>(\<Or>\<^sub>l map fst ps), F \<R> G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)). ps \<leftarrow> pow_list gs, ps \<noteq> []]. (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        using True helper_globally[OF True pcoversG] not_null
        by (fastforce simp: split_def ltl_semantics)
      then have "\<exists>(L, R)\<in>set (release_iff fs gs F G). (xs, 0) \<Turnstile> L \<and> (ys, 0) \<Turnstile> R"
        unfolding release_iff_def
        by (metis (no_types, lifting) Un_iff set_append)
    }
    ultimately show ?thesis
      using FRG[unfolded release_cases] True by blast
   next
    case False
    then show ?thesis
      using calculation(2) by blast
  qed
qed

lemma bcovers_release:
  assumes Gbcovers: "gs bcovers\<^sup>+ G"
  assumes Fbcovers: "fs bcovers\<^sup>+ F"
  shows "(release_iff fs gs F G) bcovers\<^sup>+ (F \<R> G)"
proof (rule bcoversI)
  fix xs ys L R
  assume LR: "(L,R) \<in> set (release_iff fs gs F G)"
    and L: "(xs, 0) \<Turnstile> L"
    and R: "(ys, 0) \<Turnstile> R"
    and finite: "lfinite xs"
    and not_null: "\<not>lnull xs"
  {
    fix ps L' R' L'' R''
    assume ps: "ps \<in> set (pow_list gs) - {[]}"
      and LR'': "(L'',R'') \<in> set gs"
      and LR': "(L',R') \<in> set fs"
      and L_def: "L = (\<Or>\<^sub>l map fst ps) \<U> (L'' \<and>\<^sub>l L')"
      and R_def: "R = (\<And>\<^sub>l map snd ps) \<and>\<^sub>l R'' \<and>\<^sub>l R'"
    have ps: "ps \<in> set (pow_list gs)"
      using ps by auto
    obtain i :: nat where i: "i < llength xs"
      and L': "(ldrop i xs, 0) \<Turnstile> L'"
      and L'': "(ldrop i xs, 0) \<Turnstile> L''"
      and R'': "(ys, 0) \<Turnstile> R''"
      and j: "\<forall>j<i. (xs, j) \<Turnstile> \<Or>\<^sub>l map fst ps"
      using L L_def R R_def ltl_untilE by (auto elim: ltl_untilE simp: ldrop_simps)
    have "(xs @@ ys, i) \<Turnstile> F"
      using bcoversE[OF Fbcovers LR' L'] i R R_def
      by (metis ldrop_simps(1) leD lfinite_ldrop lnull_ldrop local.finite ltl_conjE)
    moreover have "(xs @@ ys, i) \<Turnstile> G"
      using bcoversE[OF Gbcovers LR'' L'' R''] i R R_def
      by (metis ldrop_simps(1) leD lfinite_ldrop lnull_ldrop local.finite)
    moreover have "\<forall>k < i. (xs @@ ys, k) \<Turnstile> G"
      using i j R Gbcovers not_null finite
      apply (clarsimp simp: R_def ltl_sup_def)
      apply (erule_tac x=k in allE, clarsimp)
      apply (erule (1) bcoversE[OF _ in_set_pow_list[OF ps]])
      using ltl_drop_alt apply fastforce
         apply (fastforce simp: ltl_inf_def)
        apply fastforce
       apply (meson enat_ord_simps(2) leD lnull_ldrop order_less_subst2)
      apply (fastforce simp: ldrop_simps order_less_subst2)
      done
    ultimately have "(xs @@ ys, 0) \<Turnstile> F \<R> G"
      by (simp add: LTL_Release_def i ltl_untilI ltl_conj_def ltl_disj_def)
  }
  moreover {
    fix ps
    assume ps: "ps \<in> set (pow_list gs)"
      and L_def: "L = \<box>(\<Or>\<^sub>l map fst ps)"
      and R_def: "R = F \<R> G \<and>\<^sub>l (\<And>\<^sub>l map snd ps)"
    then have "\<forall>k < llength xs. (xs @@ ys, k) \<Turnstile> G"
      using L R Gbcovers apply (clarsimp simp: L_def R_def)
      apply (erule_tac i=k in ltl_globallyE(1); clarsimp?)
      apply (clarsimp simp: ltl_inf_def ltl_sup_def)
      apply (frule in_set_pow_list[OF ps])
      using ltl_drop_alt not_null finite by (fastforce elim!: bcoversE)
    then have "(xs @@ ys, 0) \<Turnstile> F \<R> G"
      using L L_def R R_def ltl_finite_def release_cases by blast
  }
  ultimately show "(xs @@ ys, 0) \<Turnstile> F \<R> G"
    using LR by (fastforce simp: release_iff_def split_def image_iff)
qed

lemma covers_release:
  assumes pcoversG: "gs covers\<^sup>+ G"
  assumes pcoversF: "fs covers\<^sup>+ F"
  shows "(release_iff fs gs F G) covers\<^sup>+ (F \<R> G)"
  using assms pcovers_release bcovers_release covers_iff by blast

lemma
  "(globally_iff [(\<A>(P),True\<^sub>l)] \<A>(P)) = [(\<box>\<A>(P), \<box>\<A>(P))]"
  by (simp add: globally_iff_def)

lemma
  "(globally_iff [(\<A>(P),True\<^sub>l)] \<A>(P)) = [(\<box>\<A>(P), \<box>\<A>(P))]"
  by (simp add: globally_iff_def)

lemma pcovers_inf:
  "gs pcovers\<^sup>+ G
  \<Longrightarrow> (G \<and>\<^sub>l infinite\<^sub>l, True\<^sub>l)#gs pcovers\<^sup>+ G"
  by (fastforce simp: ltl_pcover_def split_def ltl_semantics lappend_inf)

lemma bcovers_inf:
  "gs bcovers\<^sup>+ G
  \<Longrightarrow> (G \<and>\<^sub>l infinite\<^sub>l, True\<^sub>l)#gs bcovers\<^sup>+ G"
  by (fastforce simp: ltl_bcover_def split_def ltl_semantics lappend_inf)

lemma covers_inf:
  "gs covers\<^sup>+ G
  \<Longrightarrow> (G \<and>\<^sub>l infinite\<^sub>l, True\<^sub>l)#gs covers\<^sup>+ G"
  by (fastforce simp: ltl_cover_def split_def ltl_semantics lappend_inf)

end
