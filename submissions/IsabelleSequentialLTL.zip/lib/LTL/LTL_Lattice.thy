theory LTL_Lattice
  imports LTL_Extras
begin

instantiation ltl :: (type) order
begin

definition less_eq_ltl :: "'a ltl \<Rightarrow> 'a ltl \<Rightarrow> bool" where
  "less_eq_ltl P Q \<equiv> (\<forall>ts i. (ts,i) \<Turnstile> P \<longrightarrow> (ts,i) \<Turnstile> Q)"

definition less_ltl :: "'a ltl \<Rightarrow> 'a ltl \<Rightarrow> bool" where
  "less_ltl P Q \<equiv> P \<le> Q \<and> \<not> Q \<le> P"

instance proof
  fix x :: "'a ltl" and y :: "'a ltl" and z :: "'a ltl"
  show "(x < y) = (x \<le> y \<and> \<not> y \<le> x)"
    by (simp add: less_ltl_def)
  show "x \<le> x"
    by (simp add: less_eq_ltl_def)
  show "\<lbrakk>x \<le> y; y \<le> z\<rbrakk> \<Longrightarrow> x \<le> z"
    by (simp add: less_eq_ltl_def)
  show "\<lbrakk>x \<le> y; y \<le> x\<rbrakk> \<Longrightarrow> x = y"
    by (auto simp: less_eq_ltl_def intro: ltl_eqI)
qed

end



instantiation ltl :: (type) lattice
begin

definition "inf_ltl \<equiv> LTL_Conj"
definition "sup_ltl \<equiv> LTL_Disj"

instance proof
  fix x :: "'a ltl" and y :: "'a ltl" and z :: "'a ltl"
  show "inf x y \<le> x"
    by (simp add: inf_ltl_def less_eq_ltl_def ltl_conj_def)
  show "inf x y \<le> y"
    by (simp add: inf_ltl_def less_eq_ltl_def ltl_conj_def)
  show "\<lbrakk>x \<le> y; x \<le> z\<rbrakk> \<Longrightarrow> x \<le> inf y z"
    by (simp add: inf_ltl_def less_eq_ltl_def ltl_conj_def)
  show "x \<le> x \<squnion> y"
    by (simp add: less_eq_ltl_def ltl_disj_def sup_ltl_def)
  show "y \<le> x \<squnion> y"
    by (simp add: less_eq_ltl_def ltl_disj_def sup_ltl_def)
  show "\<lbrakk>y \<le> x; z \<le> x\<rbrakk> \<Longrightarrow> y \<squnion> z \<le> x"
    by (simp add: less_eq_ltl_def ltl_disj_def sup_ltl_def)
qed

end

instantiation ltl :: (type) bounded_lattice
begin

definition "top_ltl \<equiv> True\<^sub>l"
definition "bot_ltl \<equiv> False\<^sub>l"

instance proof
  fix a :: "'a ltl"
  show "bot \<le> a"
    by (simp add: bot_ltl_def less_eq_ltl_def)
  show "a \<le> top"
    by (simp add: less_eq_ltl_def top_ltl_def)
qed

end


definition LTL_Inf :: "'a ltl list \<Rightarrow> 'a ltl" ("\<And>\<^sub>l _" [80] 80) where
  "\<And>\<^sub>l xs \<equiv> foldr LTL_Conj xs True\<^sub>l"

definition LTL_Sup :: "'a ltl list \<Rightarrow> 'a ltl" ("\<Or>\<^sub>l _" [80] 80) where
  "\<Or>\<^sub>l xs \<equiv> foldr LTL_Disj xs False\<^sub>l"

lemma ltl_inf_def:
  "(ts,n) \<Turnstile> \<And>\<^sub>l ps = (\<forall>P \<in> set ps. (ts,n) \<Turnstile> P)"
  by (induct ps; auto simp: LTL_Inf_def ltl_semantics)

lemma ltl_sup_def:
  "(ts,n) \<Turnstile> \<Or>\<^sub>l ps = (\<exists>P \<in> set ps. (ts,n) \<Turnstile> P)"
  by (induct ps; auto simp: LTL_Sup_def ltl_semantics)

lemma ltl_inf_empty[simp]:
  "\<And>\<^sub>l[] = True\<^sub>l"
  by (simp add: LTL_Inf_def)

lemma ltl_sup_empty[simp]:
  "\<Or>\<^sub>l[] = False\<^sub>l"
  by (simp add: LTL_Sup_def)

lemma ltl_Sup_Cons[simp]:
  "\<Or>\<^sub>l (x#xs) = x \<or>\<^sub>l (\<Or>\<^sub>l xs)"
  by (simp add: LTL_Sup_def)

lemma ltl_Inf_Cons[simp]:
  "\<And>\<^sub>l (x#xs) = x \<and>\<^sub>l (\<And>\<^sub>l xs)"
  by (simp add: LTL_Inf_def)

lemma ltl_supD:
  "\<lbrakk> P \<in> set ps; (xs, n) \<Turnstile> P \<rbrakk>
   \<Longrightarrow> (xs, n) \<Turnstile> \<Or>\<^sub>l ps"
  by (induct ps; auto simp: ltl_semantics)

lemma ltl_infI:
  "\<lbrakk> \<And>P. P \<in> set ps \<Longrightarrow> (xs, n) \<Turnstile> P \<rbrakk>
   \<Longrightarrow> (xs, n) \<Turnstile> \<And>\<^sub>l ps"
  by (induct ps; auto simp: ltl_semantics)

lemma ltl_sup_subsetE:
  "\<lbrakk> (ts, n) \<Turnstile> \<Or>\<^sub>l xs; set xs \<subseteq> set ys \<rbrakk>
       \<Longrightarrow> (ts, n) \<Turnstile> \<Or>\<^sub>l ys"
  by (meson ltl_sup_def subset_code(1))


definition from_set where
  "from_set X = (SOME xs. set xs = X)"

instantiation ltl :: (type) Inf
begin
definition "Inf_ltl X \<equiv> foldr LTL_Conj (from_set X) True\<^sub>l"
instance ..
end

instantiation ltl :: (type) Sup
begin
definition "Sup_ltl X \<equiv> foldr LTL_Disj (from_set X) False\<^sub>l"
instance ..
end

lemma Inf_ltl_def2:
  "\<Sqinter>X = \<And>\<^sub>l(from_set X)"
  by (simp add: Inf_ltl_def LTL_Inf_def)

lemma Sup_ltl_def2:
  "\<Squnion>X = \<Or>\<^sub>l(from_set X)"
  by (simp add: Sup_ltl_def LTL_Sup_def)

lemma set_from_set:
  "finite ps \<Longrightarrow> set (from_set ps) = ps"
  by (smt (verit, del_insts) finite_list from_set_def someI_ex)

lemma ltl_inf'_def:
  "finite ps \<Longrightarrow> (ts,n) \<Turnstile> \<Sqinter> ps = (\<forall>P \<in> ps. (ts,n) \<Turnstile> P)"
  by (simp add: Inf_ltl_def2 ltl_inf_def set_from_set)

lemma ltl_sup'_def:
  "finite ps \<Longrightarrow> (ts,n) \<Turnstile> \<Squnion> ps = (\<exists>P \<in> ps. (ts,n) \<Turnstile> P)"
  apply (simp add: Sup_ltl_def ltl_sup_def set_from_set)
  by (metis LTL_Sup_def ltl_sup_def set_from_set)

lemma ltl_inf'_empty[simp]:
  "\<Sqinter>{} = True\<^sub>l"
  by (simp add: Inf_ltl_def from_set_def)

lemma ltl_sup'_empty[simp]:
  "\<Squnion>{} = False\<^sub>l"
  by (simp add: Sup_ltl_def from_set_def)

lemma ltl_Sup'_Cons[simp]:
  "finite xs \<Longrightarrow> \<Squnion> (insert x xs) = x \<or>\<^sub>l (\<Squnion> xs)"
  by (auto intro!: ltl_eqI simp: ltl_sup'_def ltl_semantics)

lemma ltl_Inf'_Cons[simp]:
  "finite xs \<Longrightarrow> \<Sqinter> (insert x xs) = x \<and>\<^sub>l (\<Sqinter> xs)"
  by (auto intro!: ltl_eqI simp: ltl_inf'_def ltl_semantics)

lemma ltl_sup'D:
  "\<lbrakk> finite ps; P \<in> ps; (xs, n) \<Turnstile> P \<rbrakk>
   \<Longrightarrow> (xs, n) \<Turnstile> \<Squnion> ps"
  by (auto simp: ltl_sup'_def)

lemma ltl_inf'I:
  "\<lbrakk> finite ps; \<And>P. P \<in> ps \<Longrightarrow> (xs, n) \<Turnstile> P \<rbrakk>
   \<Longrightarrow> (xs, n) \<Turnstile> \<Sqinter> ps"
  by (auto simp: ltl_inf'_def)

lemma ltl_sup'_subsetE:
  "\<lbrakk> finite ys; (ts, n) \<Turnstile> \<Squnion> xs; xs \<subseteq> ys \<rbrakk>
       \<Longrightarrow> (ts, n) \<Turnstile> \<Squnion> ys"
  apply (prop_tac "finite xs")
  using finite_subset apply blast
  apply (auto simp: ltl_sup'_def)
  done

end
