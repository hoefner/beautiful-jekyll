(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory LTL_Lifting
imports
  LTL
begin

fun ltlf_semantics :: "'a list \<times> nat \<Rightarrow> 'a ltl \<Rightarrow> bool"
  ("_ \<turnstile> _" [80,80] 80) where
  "(ts,i) \<turnstile> P = (llist_of ts, i) \<Turnstile> P"

fun ltli_semantics :: "'a stream \<times> nat \<Rightarrow> 'a ltl \<Rightarrow> bool"
  ("_ \<tturnstile> _" [80,80] 80) where
  "(ts,i) \<tturnstile> P = (llist_of_stream ts, i) \<Turnstile> P"

lemmas ltlf_semantics_def = ltlf_semantics.simps
lemmas ltli_semantics_def = ltli_semantics.simps
declare ltlf_semantics.simps[simp del]
declare ltli_semantics.simps[simp del]

lemma
  shows ltlf_atom_def[ltl_semantics]:
    "(ts,i) \<turnstile> \<A>(f) = (f (hd (drop i ts)))"
  and ltlf_and_def[ltl_semantics]:
    "(ts,i) \<turnstile> P \<and>\<^sub>l Q = ((ts,i) \<turnstile> P \<and> (ts,i) \<turnstile> Q)"
  and ltlf_not_def[ltl_semantics]:
    "(ts,i) \<turnstile> \<not>\<^sub>l P = (\<not> (ts,i) \<turnstile> P)"
  and ltlf_next_def[ltl_semantics]:
    "(ts,i) \<turnstile> \<circle> P = (Suc i < length ts \<and> (ts, Suc i) \<turnstile> P)"
  and ltlf_until_def[ltl_semantics]:
    "(ts,i) \<turnstile> P \<U> Q = (\<exists>j. i \<le> j \<and> j < length ts \<and> (ts,j) \<turnstile> Q \<and> (\<forall>k. i \<le> k \<and> k < j \<longrightarrow> (ts,k) \<turnstile> P))"
  and ltlf_disj_def[ltl_semantics]:
    "(ts,i) \<turnstile> P \<or>\<^sub>l Q = ((ts,i) \<turnstile> P \<or> (ts,i) \<turnstile> Q)"
  and ltlf_imp_def[ltl_semantics]:
    "(ts,i) \<turnstile> P \<longrightarrow>\<^sub>l Q = ((ts,i) \<turnstile> P \<longrightarrow> (ts,i) \<turnstile> Q)"
  and ltlf_finally_def[ltl_semantics]:
    "(ts,i) \<turnstile> \<diamond>P = (\<exists>j. i \<le> j \<and> j < length ts \<and> (ts,j) \<turnstile> P)"
  and ltlf_globally_def[ltl_semantics]:
    "(ts,i) \<turnstile> \<box>P = (\<forall>j. i \<le> j \<and> j < length ts \<longrightarrow> (ts,j) \<turnstile> P)"
  and ltlf_weak_next_def[ltl_semantics]:
    "(ts,i) \<turnstile> \<ominus>P = (Suc i < length ts \<longrightarrow> (ts, Suc i) \<turnstile> P)"
  by (auto simp: ltlf_semantics_def ltl_semantics ldrop_enat)

lemma
  shows ltli_atom_def[ltl_semantics]:
    "(ts,i) \<tturnstile> \<A>(f) = (f (shd (sdrop i ts)))"
  and ltli_and_def[ltl_semantics]:
    "(ts,i) \<tturnstile> P \<and>\<^sub>l Q = ((ts,i) \<tturnstile> P \<and> (ts,i) \<tturnstile> Q)"
  and ltli_not_def[ltl_semantics]:
    "(ts,i) \<tturnstile> \<not>\<^sub>l P = (\<not>(ts,i) \<tturnstile> P)"
  and ltli_next_def[ltl_semantics]:
    "(ts,i) \<tturnstile> \<circle>P = ((ts, Suc i) \<tturnstile> P)"
  and ltli_until_def[ltl_semantics]:
    "(ts,i) \<tturnstile> P \<U> Q = (\<exists>j. i \<le> j \<and> (ts,j) \<tturnstile> Q \<and> (\<forall>k. i \<le> k \<and> k < j \<longrightarrow> (ts,k) \<tturnstile> P))"
  and ltli_disj_def[ltl_semantics]:
    "(ts,i) \<tturnstile> P \<or>\<^sub>l Q = ((ts,i) \<tturnstile> P \<or> (ts,i) \<tturnstile> Q)"
  and ltli_imp_def[ltl_semantics]:
    "(ts,i) \<tturnstile> P \<longrightarrow>\<^sub>l Q = ((ts,i) \<tturnstile> P \<longrightarrow> (ts,i) \<tturnstile> Q)"
  and ltli_finally_def[ltl_semantics]:
    "(ts,i) \<tturnstile> \<diamond>P = (\<exists>j. i \<le> j \<and> (ts,j) \<tturnstile> P)"
  and ltli_globally_def[ltl_semantics]:
    "(ts,i) \<tturnstile> \<box>P = (\<forall>j. i \<le> j \<longrightarrow> (ts,j) \<tturnstile> P)"
  and ltli_weak_next_def[ltl_semantics]:
    "(ts,i) \<tturnstile> \<ominus>P = ((ts, Suc i) \<tturnstile> P)"
  by (auto simp: ltli_semantics_def ltl_semantics lhd_ldrop)

(* Utility lemmas *)

lemma ltl\<^sub>0_semantics_induct:
  "\<lbrakk>\<And>ts i P. R ts i (LTL_Atom\<^sub>0 P);
    \<And>ts i P Q. \<lbrakk>R ts i P; R ts i Q\<rbrakk> \<Longrightarrow> R ts i (LTL_Conj\<^sub>0 P Q);
    \<And>ts i P. R ts i P \<Longrightarrow> R ts i (LTL_Not\<^sub>0 P);
    \<And>ts i P. R ts (Suc i) P \<Longrightarrow> R ts i (LTL_Next\<^sub>0 P);
    \<And>ts i P Q. \<lbrakk>\<And>x. R ts x Q; \<And>x xa. i \<le> xa \<and> xa < x \<Longrightarrow> R ts xa P\<rbrakk> \<Longrightarrow> R ts i (LTL_Until\<^sub>0 P Q)\<rbrakk>
    \<Longrightarrow> (R :: 'a llist \<Rightarrow> nat \<Rightarrow> ('a \<Rightarrow> bool) ltl\<^sub>0 \<Rightarrow> bool) ts i F"
  by (drule ltl\<^sub>0_semantics.induct[where P="\<lambda>(ts,i). R ts i", simplified]; fastforce)

lemma ltl_semantics_induct:
  "\<lbrakk>\<And>ts i P. R ts i (LTL_Atom P);
    \<And>ts i P Q. \<lbrakk>R ts i P; R ts i Q\<rbrakk> \<Longrightarrow> R ts i (LTL_Conj P Q);
    \<And>ts i P. R ts i P \<Longrightarrow> R ts i (LTL_Not P);
    \<And>ts i P. R ts (Suc i) P \<Longrightarrow> R ts i (LTL_Next P);
    \<And>ts i P Q. \<lbrakk>\<And>x. R ts x Q; \<And>x xa. i \<le> xa \<and> xa < x \<Longrightarrow> R ts xa P\<rbrakk> \<Longrightarrow> R ts i (LTL_Until P Q)\<rbrakk>
   \<Longrightarrow> (R :: 'a llist \<Rightarrow> nat \<Rightarrow> 'a ltl \<Rightarrow> bool) ts i F"
  by (transfer, rule ltl\<^sub>0_semantics_induct; fastforce)


(* Lifting coinductive ltl lemmas to lists and streams *)

named_theorems from_ltl

declare True_implies_equals[from_ltl]

lemma ltlf_from[from_ltl]:
  "(llist_of ts, n) \<Turnstile> P = (ts,n) \<turnstile> P"
  by (simp add: ltlf_semantics_def)

lemma ltli_from[from_ltl]:
  "(llist_of_stream ts, n) \<Turnstile> P = (ts,n) \<tturnstile> P"
  by (simp add: ltli_semantics_def)

lemma length_from[from_ltl]:
  "enat i < llength (llist_of ts) = (i < length ts)"
  by simp

lemma slength_from[from_ltl]:
  "enat i < llength (llist_of_stream ts)"
  by (simp add: not_lfinite_llength)

end
