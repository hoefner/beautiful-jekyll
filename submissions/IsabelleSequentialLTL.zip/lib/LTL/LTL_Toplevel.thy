(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory LTL_Toplevel
imports
  LTL_Covers
begin

(* Nothing to do *)

end
