(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Trace_Syntax
  imports
    "Coinductive.Coinductive_Stream"
begin

\<comment> \<open>Syntax\<close>

syntax
  \<comment> \<open>llist Enumeration\<close>
  "_llist" :: "args => 'a llist"    ("<(_)>")

notation LNil  ("<>")

translations
  "<x, xs>" == "CONST LCons x <xs>"
  "<x>" == "CONST LCons x <>"

no_notation bit (infixl \<open>!!\<close> 100)

no_notation snth  (infixl \<open>!!\<close> 100)
notation    snth  (infixl \<open>!-\<close> 100)
no_notation SCons (infixr \<open>##\<close> 65)
notation    SCons (infixr \<open>#-\<close> 65)

notation
  LCons   (infixr "##" 65)  and
  lappend (infixr "@@" 65)  and
  lnth    (infixl "!!" 100) and
  snth    (infixl \<open>!-\<close> 100)

hide_const connected

hide_const ev

no_notation OR (infix "or" 60)

(* FIXME ryanb: move *)

no_notation Orderings.top_class.top ("\<top>")
        and Orderings.bot_class.bot ("\<bottom>")

hide_const Sublist.parallel

\<comment> \<open>Lemmas\<close>

lemma llength_llist_of_stream[simp]:
  "llength (llist_of_stream ts) = \<infinity>"
  by (simp add: llength_eq_infty_conv_lfinite)

end
