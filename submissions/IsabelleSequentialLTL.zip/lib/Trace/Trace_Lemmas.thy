(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Trace_Lemmas
  imports Trace_Monad
begin

\<comment> \<open>FIXME: where should this go\<close>
lemma in_mres:
  "\<lbrakk> (Result ts rv) \<in> f s; st = last_st ts s \<rbrakk> \<Longrightarrow> (rv, st) \<in> mres f s"
  by (fastforce simp: mres_def intro: image_eqI[rotated])

lemma bind_apply_cong':
  "\<lbrakk>f s = f' s; (\<forall>rv st. (rv, st) \<in> mres f s \<longrightarrow> g rv st = g' rv st)\<rbrakk>
   \<Longrightarrow> bind f g s = bind f' g' s"
  apply (simp add: bind_def)
  apply (rule SUP_cong; simp?)
  apply (clarsimp split: tmres.split)
  apply (fastforce simp: in_mres)
  done

lemmas bind_apply_cong = bind_apply_cong'[rule_format, fundef_cong]

lemma bind_cong[fundef_cong]:
  "\<lbrakk> f = f'; \<And>v s s'. (v, s') \<in> mres f' s \<Longrightarrow> g v s' = g' v s' \<rbrakk> \<Longrightarrow> f >>= g = f' >>= g'"
  by (auto intro!: bind_apply_cong)

lemma K_bind_apply_cong[fundef_cong]:
  "\<lbrakk> f st = f' st' \<rbrakk> \<Longrightarrow> K_bind f arg st = K_bind f' arg' st'"
  by simp

lemma when_apply_cong[fundef_cong]:
  "\<lbrakk> C = C'; s = s'; C' \<Longrightarrow> m s' = m' s' \<rbrakk> \<Longrightarrow> when C m s = when C' m' s'"
  by (simp add: when_def)

lemma unless_apply_cong[fundef_cong]:
  "\<lbrakk> C = C'; s = s'; \<not> C' \<Longrightarrow> m s' = m' s' \<rbrakk> \<Longrightarrow> unless C m s = unless C' m' s'"
  by (simp add: when_def unless_def)


lemma nested_bind[simp]:
  "do x <- do y <- f; return (g y) od; h x od = do y <- f; h (g y) od"
  by (fastforce simp: bind_def2 return_def split: tmres.splits)

lemma bind_dummy_ret_val:
  "do y \<leftarrow> a; b od = do a; b od"
  by simp

lemma fail_update[iff]:
  "fail (f s) = fail s"
  by (simp add: fail_def)

lemma fail_bind[simp]:
  "fail >>= f = fail"
  by (simp add: bind_def fail_def)

lemma assert_A_False[simp]:
  "assert False = fail"
  by (simp add: assert_def)

lemma assert_A_True[simp]:
  "assert True = return ()"
  by (simp add: assert_def)

lemma assert_False[simp]:
  "assert False >>= f = fail"
  by simp

lemma assert_True[simp]:
  "assert True >>= f = f ()"
  by simp

lemma when_False_bind[simp]:
  "when False g >>= f = f ()"
  by (rule ext) (simp add: when_def bind_def2 return_def)

lemma when_True_bind[simp]:
  "when True g >>= f = g >>= f"
  by (simp add: when_def bind_def return_def)

lemma when_True[simp]:
  "when True X = X"
  by (clarsimp simp: when_def)

lemma when_False[simp]:
  "when False X = return ()"
  by (clarsimp simp: when_def)

lemma unless_False[simp]:
  "unless False X = X"
  by (clarsimp simp: unless_def)

lemma unless_True[simp]:
  "unless True X = return ()"
  by (clarsimp simp: unless_def)

lemma unless_when:
  "unless P = when (\<not>P)"
  by (rule ext) (simp add: unless_def when_def)

lemma assert_opt_Some:
  "assert_opt (Some x) = return x"
  by (simp add: assert_opt_def)

lemma choice_bind:
  "((a \<^bold>+ b) >>= c) = ((a >>= c) \<^bold>+ (b >>= c))"
  by (fastforce simp add: choice_def bind_def split_def)

lemma choice_refl:
  "(a \<^bold>+ a) = a"
  by (simp add: choice_def)

lemma choice_com:
  "(f \<^bold>+ g) = (g \<^bold>+ f)"
  by (auto simp: choice_def)


lemma liftM_id[simp]:
  "liftM id = id"
  by (auto simp: liftM_def)

lemma liftM_bind:
  "liftM t f >>= g = f >>= (\<lambda>x. g (t x))"
  by (simp add: liftM_def bind_assoc)

lemma gets_bind_ign:
  "gets f >>= (\<lambda>x. m) = (\<lambda>s. tappend [(Proc, s)] ` m s)"
  by (simp add: bind_def2 simpler_gets_def)

lemma exec_get:
  "(get >>= f) x = tappend [(Proc, x)] ` f x x"
  by (simp add: get_def bind_def2)

lemmas get_bind_apply = exec_get (* FIXME lib: eliminate *)

lemma exec_gets:
  "(gets f >>= m) s = tappend [(Proc, s)] ` m (f s) s"
  by (simp add: simpler_gets_def bind_def2)

lemma bind_eqI:
  "\<lbrakk> f = f'; \<And>x. g x = g' x \<rbrakk> \<Longrightarrow> f >>= g = f' >>= g'"
  by (fastforce simp: bind_def2 split_def split: tmres.splits)

lemma condition_split:
  "P (condition C a b s) \<longleftrightarrow> (C s \<longrightarrow> P (a s)) \<and> (\<not>C s \<longrightarrow> P (b s))"
  by (clarsimp simp: condition_def)

lemma condition_split_asm:
  "P (condition C a b s) \<longleftrightarrow> (\<not>(C s \<and> \<not> P (a s) \<or> \<not>C s \<and> \<not>P (b s)))"
  by (clarsimp simp: condition_def)

lemmas condition_splits = condition_split condition_split_asm

lemma condition_true_triv[simp]:
  "condition (\<lambda>_. True) A B = A"
  by (fastforce split: condition_splits)

lemma condition_false_triv[simp]:
  "condition (\<lambda>_. False) A B = B"
  by (fastforce split: condition_splits)

lemma condition_true:
  "P s \<Longrightarrow> condition P A B s = A s"
  by (clarsimp simp: condition_def)

lemma condition_false:
  "\<not> P s \<Longrightarrow> condition P A B s = B s"
  by (clarsimp simp: condition_def)

lemmas arg_cong_bind = arg_cong2[where f=bind]
lemmas arg_cong_bind1 = arg_cong_bind[OF refl ext]

end
