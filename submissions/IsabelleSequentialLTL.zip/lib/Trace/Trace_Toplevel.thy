(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Trace_Toplevel
imports
  Trace_Aczel
begin

(* Nothing to do *)

end
