(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Trace_Aczel
imports
  Trace_In_Monad
begin

type_synonym 's zstep = "('s \<times> tmid \<times> 's)"

primcorec ztrace :: "(tmid \<times> 's) llist \<Rightarrow> 's \<Rightarrow> 's zstep llist"
  where
  "ztrace tr s = (case tr of <> \<Rightarrow> <>
                 | (a,s') ## ts \<Rightarrow> (s, a, s') ## ztrace ts s')"

definition runTrace :: "('s, 'a) tmonad \<Rightarrow> 's \<Rightarrow> 's zstep llist set"
  where
  "runTrace f \<equiv> \<lambda>s. \<Union>tmres \<in> f s. case tmres of
     Failed \<Rightarrow> {}
   | Diverged ts \<Rightarrow> {ztrace ts s}
   | Result ts rv \<Rightarrow> {ztrace (llist_of ts) s}"

abbreviation zfst :: "'s zstep \<Rightarrow> 's" where
  "zfst \<equiv> \<lambda>t. fst t"

abbreviation zsnd :: "'s zstep \<Rightarrow> 's" where
  "zsnd \<equiv> \<lambda>t. snd (snd t)"

fun zlist :: "(tmid \<times> 's) list \<Rightarrow> 's \<Rightarrow> 's zstep list" where
  "zlist tr s = (case tr of [] \<Rightarrow> [] | ((a,s')#ts) \<Rightarrow> (s, a, s') # zlist ts s')"

primcorec zstream :: "(tmid \<times> 's) stream \<Rightarrow> 's \<Rightarrow> 's zstep stream" where
  "zstream tr s = (case tr of ((a,s')#-ts) \<Rightarrow> (s, a, s') #- zstream ts s')"

lemma zlist_simps[simp]:
  "zlist [] s = []"
  "zlist (t#ts) s = (s, t) # zlist ts (snd t)"
  by (auto simp: split_def)

declare zlist.simps[simp del]

lemma zstream_simps[simp]:
  "zstream (t#-ts) s = (s, t) #- zstream ts (snd t)"
  by (auto simp: zstream.ctr)

lemma ztrace_simps[simp]:
  "ztrace <> s = <>"
  "ztrace (t##ts) s = (s, t) ## ztrace ts (snd t)"
  by (auto simp: ztrace.ctr)

definition runList :: "('s, 'a) tmonad \<Rightarrow> 's \<Rightarrow> 's zstep list set" where
  "runList f \<equiv> \<lambda>s. \<Union>tmres \<in> f s. case tmres of
     Failed \<Rightarrow> {}
   | Diverged ts \<Rightarrow> {}
   | Result ts rv \<Rightarrow> {zlist ts s}"

definition runStream :: "('s, 'a) tmonad \<Rightarrow> 's \<Rightarrow> 's zstep stream set" where
  "runStream f \<equiv> \<lambda>s. \<Union>tmres \<in> f s. case tmres of
     Failed \<Rightarrow> {}
   | Diverged ts \<Rightarrow> {zs | zs. zs = zstream (stream_of_llist ts) s \<and> \<not>lfinite ts}
   | Result ts rv \<Rightarrow> {}"

lemma zlist_length:
  "length (zlist ts s) = length ts"
  by (induct ts arbitrary: s; clarsimp)

lemma ztrace_length:
  "llength (ztrace ts s) = llength ts"
  apply (subst llist_all2_True[symmetric])
  apply (coinduct rule: llist_all2_coinduct)
    apply (subgoal_tac "(\<lambda>xs ys. \<exists>ts s. xs = (ztrace ts s) \<and> ys = ts) (ztrace ts s) ts")
     prefer 2
     apply fastforce
    apply assumption
   apply (auto simp: llist.case_eq_if)
  done

lemma ztrace_zlist:
  assumes finite_ts: "lfinite ts"
  shows "ztrace ts s = llist_of (zlist (list_of ts) s)"
  apply (coinduct rule: llist.coinduct)
   apply (subgoal_tac "(\<lambda>xs ys. \<exists>ts s. lfinite ts \<and> xs = ztrace ts s \<and>
                                    ys = llist_of (zlist (list_of ts) s))
                    (ztrace ts s) (llist_of (zlist (list_of ts) s))")
    prefer 2
    using finite_ts apply fastforce
   apply assumption
  apply clarsimp
  apply (case_tac ts; clarsimp)
  apply (fastforce split: llist.splits)
  done

lemma ztrace_zstream:
  assumes infinite_ts: "\<not>lfinite ts"
  shows "ztrace ts s = llist_of_stream (zstream (stream_of_llist ts) s)"
  apply (coinduct rule: llist.coinduct)
   apply (subgoal_tac "(\<lambda>xs ys. \<exists>ts s. \<not>lfinite ts \<and> xs = ztrace ts s \<and>
                                    ys = llist_of_stream (zstream (stream_of_llist ts) s))
                    (ztrace ts s) (llist_of_stream (zstream (stream_of_llist ts) s))")
    prefer 2
    using infinite_ts apply fastforce
   apply assumption
  apply (fastforce split: llist.splits simp: stream.case_eq_if)
  done

lemma runList_runTrace:
  "(ts \<in> runList f s) \<Longrightarrow> (llist_of ts \<in> runTrace f s)"
  apply (auto simp: runList_def runTrace_def)
   apply (case_tac x; clarsimp)
   apply (erule rev_bexI; clarsimp)
  apply (metis (no_types, lifting) lfinite_llist_of list_of_llist_of ztrace_zlist)
  done

lemma runStream_runTrace:
  "(ts \<in> runStream f s) \<Longrightarrow> (llist_of_stream ts \<in> runTrace f s)"
  apply (auto simp: runStream_def runTrace_def)
   apply (case_tac x; clarsimp)
  apply (erule rev_bexI; clarsimp)
  using ztrace_zstream by fastforce

(* FIXME ryanb: move *)
fun zlast_st :: "'s zstep list \<Rightarrow> 's \<Rightarrow> 's" where
  "zlast_st [] s = s"
| "zlast_st [x] _ = zsnd x"
| "zlast_st (x#y#zs) _ = zlast_st (y#zs) (zsnd x)"

(* FIXME ryanb: move *)
lemma zlast_st_append[simp]:
  "zlast_st (tr @ tr') s = zlast_st tr' (zlast_st tr s)"
  apply (induct tr arbitrary: tr' s; clarsimp)
  apply (case_tac tr; case_tac tr'; clarsimp)
  done

lemma drop_zlist:
  "n < length ts \<Longrightarrow> drop n (zlist ts s) = zlist (drop n ts) (last_st (take n ts) s)"
  apply (induct n arbitrary: ts s; clarsimp?)
  apply (case_tac ts; clarsimp)
  by (metis append_Cons append_Nil last_st.simps(2) last_st_append snd_conv)

lemma sdrop_zstream:
  "sdrop n (zstream ts s) = zstream (sdrop n ts) (last_st (stake n ts) s)"
  apply (induct n arbitrary: ts s; clarsimp)
  apply (case_tac ts; clarsimp)
  by (metis append_Cons append_Nil last_st.simps(2) last_st_append snd_conv)

lemma zlist_append:
  "zlist (xs @ ys) s = zlist xs s @ zlist ys (last_st xs s)"
  apply (induct xs arbitrary: ys s; clarsimp)
  by (metis append_Cons append_Nil last_st.simps(2) last_st_append snd_conv)

lemma ztrace_append:
  "ztrace ((llist_of xs) @@ ys) s = llist_of (zlist xs s) @@ ztrace ys (last_st xs s)"
  apply (induct xs arbitrary: ys s; clarsimp)
  by (metis append_Cons append_Nil last_st.simps(2) last_st_append snd_conv)

lemma zstream_shift:
  "zstream (xs @- ys) s = zlist xs s @- zstream ys (last_st xs s)"
  apply (induct xs arbitrary: ys s; clarsimp)
  by (metis append_Cons append_Nil last_st.simps(2) last_st_append snd_conv)

lemma zlast_st_zlist[simp]:
  "zlast_st (zlist xs s) s = last_st xs s"
  apply (induct xs arbitrary: s; clarsimp)
  by (metis Cons_eq_append_conv last_st.simps(2) last_st_append self_append_conv2 sndI zlast_st.simps(2) zlast_st_append)

lemma zlist_tmres:
  "Result ts rv \<in> f s \<Longrightarrow> zlist ts s \<in> runList f s"
  by (force simp: runList_def)

(* FIXME ryanb: rename, standardise *)
lemma zstream_tmres:
  "\<lbrakk> Diverged ts \<in> f s; \<not>lfinite ts \<rbrakk>
     \<Longrightarrow> zstream (stream_of_llist ts) s \<in> runStream f s"
  by (force simp: runStream_def)

(* FIXME ryanb: rename, standardise *)
lemma zstream_tmres':
  "Diverged (llist_of_stream ts) \<in> f s \<Longrightarrow> zstream ts s \<in> runStream f s"
  by (force simp: runStream_def)

(* FIXME ryanb: rename, standardise *)
lemma runList_cases:
  "\<lbrakk> zs \<in> runList f s; \<And>ts rv. \<lbrakk> zs = zlist ts s; Result ts rv \<in> f s \<rbrakk> \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  apply (clarsimp simp: runList_def)
  apply (case_tac x; clarsimp)
  done

(* FIXME ryanb: generalise preconditions *)
lemma runList_bindE:
  "\<lbrakk> zs \<in> runList (f >>= g) s;
     \<And>xs ys rv rv'. \<lbrakk> Result xs rv \<in> f s; Result ys rv' \<in> g rv (last_st xs s);
                  zs = zlist xs s @ zlist ys (last_st xs s) \<rbrakk>
                  \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  apply (clarsimp simp: runList_def)
  apply (case_tac x; clarsimp)
  apply (clarsimp simp: bind_def)
  apply (case_tac x; clarsimp)
  apply (case_tac xa; clarsimp)
  apply (simp add: zlist_append)
  done

(* FIXME ryanb: rename, standardise *)
lemma runStream_cases:
  "\<lbrakk> zs \<in> runStream f s; \<And>ts. \<lbrakk> zs = zstream ts s; Diverged (llist_of_stream ts) \<in> f s \<rbrakk> \<Longrightarrow> R \<rbrakk>
     \<Longrightarrow> R"
  apply (clarsimp simp: runStream_def)
  apply (case_tac x; clarsimp)
  done

coinductive_set dloop_div ::
  "('s, unit) tmonad \<Rightarrow> ('s \<times> (tmid \<times> 's) llist llist) set"
  for f where
    "\<lbrakk> Result xs () \<in> f s; xs \<noteq> []; (last_st xs s, ys) \<in> dloop_div f \<rbrakk>
       \<Longrightarrow> (s, llist_of xs ## ys) \<in> dloop_div f"

definition dloop :: "('s,unit) tmonad \<Rightarrow> ('s,unit) tmonad" where
  "dloop f \<equiv> \<lambda>s. {res | res. res = Failed \<and> ((),s) \<in> loop_fail f} \<union>
                 {Diverged (lconcat tr) | tr. (s,tr) \<in> dloop_div f}"

lemma dloop_cases:
  "\<lbrakk> tr \<in> dloop f s;
     \<lbrakk> tr = Failed; ((), s) \<in> loop_fail f \<rbrakk> \<Longrightarrow> P;
     \<And>xs ys.
        \<lbrakk> tr = Diverged (llist_of xs @@ ys);
          Result xs () \<in> f s; xs \<noteq> [];
          Diverged ys \<in> dloop f (last_st xs s)\<rbrakk>
          \<Longrightarrow> P \<rbrakk>
    \<Longrightarrow> P"
  apply (clarsimp simp: dloop_def)
  apply (elim disjE; clarsimp)
  apply (subst (asm) dloop_div.simps) back
  apply fastforce
  done

lemma llist_of_streamD:
  "llist_of_stream zs = llist_of xs @@ ys
   \<Longrightarrow> zs = xs @- (stream_of_llist ys)"
  by (metis lappend_llist_of_stream_conv_shift lfinite_lappend lfinite_llist_of lfinite_llist_of_stream llist_of_stream_stream_of_llist stream.Rep_inverse)

lemma dloop_div_infinite:
  "(s, xss) \<in> dloop_div f \<Longrightarrow> \<not>lfinite xss"
  apply (erule contrapos_pn)
  apply (induct xss arbitrary: s rule: lfinite.induct)
   apply (subst dloop_div.simps, clarsimp)+
  done

lemma dloop_div_non_null:
  "(s, xss) \<in> dloop_div f \<Longrightarrow> \<forall>n. \<not>lnull (xss !! n)"
  apply (rule allI)
  subgoal for n apply (induct n arbitrary: s xss)
     apply (subst (asm) dloop_div.simps, solves clarsimp)+
    done
  done

lemma dloop_infinite:
  "Diverged ys \<in> dloop f s \<Longrightarrow> \<not>lfinite ys"
  apply (clarsimp simp: dloop_def)
  apply (frule dloop_div_infinite)
  apply (drule dloop_div_non_null)
  by (metis in_lset_conv_lnth lfilter_id_conv)

lemma dloop_zcases:
  "\<lbrakk> ts \<in> runStream (dloop f) s;
     \<And>xs ys. \<lbrakk> ts = xs @- ys; xs \<in> runList f s;
               ys \<in> runStream (dloop f) (zlast_st xs s) \<rbrakk>
               \<Longrightarrow> P\<rbrakk>
     \<Longrightarrow> P"
  apply (erule runStream_cases)
  apply (erule dloop_cases; clarsimp)
  apply (drule llist_of_streamD, clarsimp simp: zstream_shift)
  apply (fastforce simp: zlist_tmres zstream_tmres dloop_infinite)
  done

lemma stream_of_llist_lappend[simp]:
  "stream_of_llist (llist_of xs @@ ys) = xs @- stream_of_llist ys"
  apply (induct xs; clarsimp)
  by (simp add: stream_of_llist_def)

lemma zloopE:
  "\<lbrakk> ts \<in> runStream (dloop f) s; I s;
     \<And>xs s.
        \<lbrakk> xs \<in> runList f s; I s \<rbrakk> \<Longrightarrow> I (zlast_st xs s);
     \<And>xs ys s n.
        \<lbrakk> xs \<in> runList f s; I s; I (zlast_st xs s);
          ys \<in> runStream (dloop f) (zlast_st xs s); n < length xs \<rbrakk>
        \<Longrightarrow> P (drop n xs @- ys) \<rbrakk>
    \<Longrightarrow> P (sdrop n ts)"
  apply (induct n arbitrary: ts s rule: nat_less_induct)
  apply clarsimp
  apply (case_tac "n = 0")
   apply clarsimp
   apply (subst (asm) runStream_def)
   apply clarsimp
   apply (case_tac x; clarsimp)
   apply (erule dloop_cases; clarsimp)
   apply (drule zlist_tmres)
   apply (drule (1) zstream_tmres)
   apply (erule_tac x="zlist xs s" in meta_allE)
   apply (erule_tac x="zlist xs s" in meta_allE)
   apply (erule_tac x="zstream (stream_of_llist ys) (last_st xs s)" in meta_allE)
   apply (erule_tac x=s in meta_allE)
   apply (erule_tac x=s in meta_allE)
   apply (clarsimp simp: zstream_shift)
   apply (erule_tac x=0 in meta_allE)
   apply clarsimp
  apply (metis length_0_conv zlist_length)
  apply clarsimp
  apply (subst (asm) runStream_def) back
  apply clarsimp
  apply (case_tac x; clarsimp)
  apply (erule dloop_cases; clarsimp)
  apply (drule zlist_tmres)
  apply (drule (1) zstream_tmres)
  apply (case_tac "n < length xs")
   apply (simp add: sdrop_shift zlist_length zstream_shift)
  by (smt (verit, ccfv_SIG) diff_less drop_eq_Nil2 last_st_append length_drop length_greater_0_conv sdrop_shift sdrop_zstream shift.simps(1) stake_shift take_all_iff zero_less_diff zlast_st_zlist)

definition connected :: "'s zstep list \<Rightarrow> bool" where
  "connected ts \<equiv> \<forall>i. Suc i < length ts \<longrightarrow> zsnd (ts ! i) = zfst (ts ! Suc i)"

lemma zlist_connected:
  "connected (zlist ts s)"
  apply (induct ts arbitrary: s)
   apply (clarsimp simp: connected_def)
  apply (case_tac ts; fastforce simp: connected_def less_Suc_eq_0_disj)
  done

lemma runList_connected:
  "ts \<in> runList f s \<Longrightarrow> connected ts"
  unfolding runList_def by (fastforce simp: zlist_connected split: tmres.splits)

lemma connectedD:
  "\<lbrakk> connected ts; Suc i < length ts \<rbrakk>
     \<Longrightarrow> zsnd (ts ! i) = zfst (ts ! Suc i)"
  by (simp add: connected_def)


definition lconnected :: "'s zstep llist \<Rightarrow> bool" where
  "lconnected ts \<equiv> \<forall>i. Suc i < llength ts \<longrightarrow> zsnd (ts !! i) = zfst (ts !! Suc i)"

lemma ztrace_lconnected:
  "lconnected (ztrace ts s)"
  apply (unfold lconnected_def)
  apply (rule allI)
  subgoal for i
    apply (induct i arbitrary: ts s)
     apply (case_tac ts; case_tac "ltl ts"; clarsimp simp: enat_0_iff)
    apply (case_tac ts; case_tac "ltl ts"; clarsimp simp: enat_0_iff)
    apply (metis eSuc_enat eSuc_le_iff fst_conv iless_Suc_eq llength_LCons lnth_Suc_LCons snd_conv ztrace_length ztrace_simps(2))
    done
  done

lemma runTrace_lconnected:
  "ts \<in> runTrace f s \<Longrightarrow> lconnected ts"
  unfolding runTrace_def by (fastforce simp: ztrace_lconnected split: tmres.splits)

lemma lconnectedD:
  "\<lbrakk> lconnected ts; Suc i < llength ts \<rbrakk>
     \<Longrightarrow> zsnd (ts !! i) = zfst (ts !! Suc i)"
  by (simp add: lconnected_def)

lemma lconnected_appendD1:
  "lconnected (xs @@ ys) \<Longrightarrow> lconnected xs"
  unfolding lconnected_def
  apply (erule all_forward)
  apply clarsimp
  by (metis (no_types, lifting) Suc_ile_eq dual_order.strict_trans1 enat_le_plus_same(1) lnth_lappend1 order_less_imp_le)

lemma lconnected_appendD2:
  "lconnected (xs @@ ys) \<Longrightarrow> lfinite xs \<Longrightarrow> lconnected ys"
  apply (clarsimp simp: lconnected_def)
  apply (erule_tac x="the_enat (llength xs) + i" in allE)
  apply (drule mp)
   apply (metis add_Suc_right enat_less_enat_plusI2 lfinite_conv_llength_enat the_enat.simps)
  using llength_eq_infty_conv_lfinite lnth_lappend2 by fastforce

lemma lconnected_ltake:
  "lconnected xs \<Longrightarrow> lconnected (ltake (enat n) xs)"
  apply (subst (asm) lappend_ltake_ldrop[where n=n, symmetric])
  apply (erule lconnected_appendD1)
  done

lemma lconnected_ldrop:
  "lconnected xs \<Longrightarrow> lconnected (ldrop (enat n) xs)"
  apply (subst (asm) lappend_ltake_ldrop[where n=n, symmetric])
  apply (erule lconnected_appendD2)
  apply clarsimp
  done


definition sconnected :: "'s zstep stream \<Rightarrow> bool" where
  "sconnected ts \<equiv> \<forall>i. zsnd (ts !- i) = zfst (ts !- Suc i)"

lemma zstream_sconnected:
  "sconnected (zstream ts s)"
  apply (unfold sconnected_def)
  apply (rule allI)
  subgoal for i
    apply (induct i arbitrary: ts s)
     apply (auto simp: stream.case_eq_if)
    done
  done

lemma runStream_sconnected:
  "ts \<in> runStream f s \<Longrightarrow> sconnected ts"
  unfolding runStream_def by (fastforce simp: zstream_sconnected split: tmres.splits)

lemma sconnectedD:
  "sconnected ts \<Longrightarrow> zsnd (ts !- i) = zfst (stl ts !- i)"
  by (simp add: sconnected_def)


lemma lconnected_list[simp]:
  "lconnected (llist_of ts) = connected ts"
  by (simp add: lconnected_def connected_def)

lemma lconnected_stream[simp]:
  "lconnected (llist_of_stream ts) = sconnected ts"
  by (simp add: lconnected_def sconnected_def)


lemma runList_tmres:
  "zs \<in> runList f s \<Longrightarrow> \<exists>ts rv. zs = zlist ts s \<and> Result ts rv \<in> f s"
  apply (clarsimp simp: runList_def)
  apply (case_tac x; fastforce)
  done

lemma zlist_nil[simp]:
  "(zlist xs s = []) = (xs = [])"
  by (induct xs; clarsimp)

lemma connected_nil[simp]:
  "connected []"
  by (simp add: connected_def)

lemma lconnected_nil[simp]:
  "lconnected <>"
  by (simp add: lconnected_def)

lemma connected_appendD1:
  "connected (xs @ ys) \<Longrightarrow> connected xs"
  unfolding connected_def
  apply (erule all_forward)
  apply (clarsimp simp: nth_append)
  done

lemma connected_appendD2:
  "connected (xs @ ys) \<Longrightarrow> connected ys"
  apply (clarsimp simp: connected_def)
  apply (erule_tac x="length xs + i" in allE)
  apply (drule mp; clarsimp)
  apply (metis add_Suc_right nth_append_length_plus)
  done

lemma connected_append:
  "connected (xs @ ys) =
   (connected xs \<and> connected ys \<and> (xs = [] \<or> ys = [] \<or> zsnd (last xs) = zfst (hd ys)))"
  apply (rule iffI)
   apply (intro conjI)
     apply (erule connected_appendD1)
    apply (erule connected_appendD2)
   apply (clarsimp simp: disj_imp)
   apply (drule_tac i="length xs - 1" in connectedD; clarsimp)
   apply (simp add: hd_conv_nth last_conv_nth nth_append)
  apply clarsimp
  apply (elim disjE; clarsimp?)
  apply (subst connected_def, clarsimp)
  apply (case_tac "Suc i < length xs")
   apply (simp add: connectedD nth_append)
  apply (case_tac "Suc i = length xs")
   apply (metis Zero_neq_Suc add.right_neutral add_diff_cancel_left' hd_conv_nth last_conv_nth length_0_conv lessI nth_append plus_1_eq_Suc)
  apply (metis (no_types, lifting) Suc_diff_Suc Suc_lessI Trace_Aczel.connectedD add_diff_inverse_nat add_less_imp_less_left diff_Suc_Suc linorder_neqE_nat nth_append)
  done

lemma connected_zlist_append:
  "connected (zlist xs s @ zlist ys (last_st xs s))"
  apply (auto simp: connected_append zlist_connected)
  by (metis connected_append zlist_append zlist_connected zlist_nil)

lemma sconnected_shiftD1:
  "sconnected (xs @- ys) \<Longrightarrow> connected xs"
  unfolding sconnected_def connected_def
  apply (erule all_forward)
  using shift_snth_less by fastforce

lemma sconnected_shiftD2:
  "sconnected (xs @- ys) \<Longrightarrow> sconnected ys"
  unfolding sconnected_def
  apply (rule allI)
  apply (erule_tac x="length xs + i" in allE)
  apply (metis add_Suc_right add_diff_cancel_left' le_add1 shift_snth_ge)
  done

lemma sconnected_shift:
  "sconnected (xs @- ys) =
   (connected xs \<and> sconnected ys \<and> (xs = [] \<or> zsnd (last xs) = zfst (shd ys)))"
  apply (rule iffI)
   apply (intro conjI)
     apply (erule sconnected_shiftD1)
    apply (erule sconnected_shiftD2)
   apply (clarsimp simp: disj_imp)
   apply (drule_tac i="length xs - 1" in sconnectedD; clarsimp)
   apply (simp add: hd_conv_nth last_conv_nth nth_append)
  apply clarsimp
  apply (elim disjE; clarsimp?)
  apply (subst sconnected_def, rule allI)
  apply (case_tac "Suc i < length xs")
   apply (metis Suc_lessD Trace_Aczel.connectedD shift_snth_less)
  apply (case_tac "Suc i = length xs")
   apply (metis One_nat_def add.commute add_implies_diff diff_diff_left last_conv_nth length_0_conv lessI less_Suc_eq_0_disj plus_1_eq_Suc snth.simps(1) snth_shift)
  apply (metis (no_types, lifting) Suc_diff_Suc Suc_lessI diff_Suc_Suc linorder_neqE_nat sconnected_def shift_snth)
  done


abbreviation "zhd xs \<equiv> zfst (hd xs)"
abbreviation "zlhd xs \<equiv> zfst (lhd xs)"
abbreviation "zshd xs \<equiv> zfst (shd xs)"
abbreviation "zlast xs \<equiv> zsnd (last xs)"
abbreviation "zllast xs \<equiv> zsnd (llast xs)"

lemma zlast_zlast_st:
  "xs \<noteq> [] \<Longrightarrow> zlast xs = zlast_st xs s"
  apply (induct xs arbitrary: s; clarsimp)
  by (metis append_Cons append_Nil zlast_st_append)

lemma zshd_runStream:
  "xs \<in> runStream (loop f) s \<Longrightarrow> zshd xs = s"
  apply (auto simp: runStream_def)
  apply (case_tac x; clarsimp)
  apply (case_tac x2; clarsimp)
  by (simp add: stream.case_eq_if)

lemma zhd_runList:
  "\<lbrakk> xs \<in> runList f s; xs \<noteq> [] \<rbrakk> \<Longrightarrow> zhd xs = s"
  apply (drule runList_tmres, clarsimp)
  apply (case_tac ts; clarsimp)
  done

lemma sconnectedD':
  "sconnected ts \<Longrightarrow> zsnd (shd (sdrop i ts)) = zfst (shd (sdrop (Suc i) ts))"
  by (simp add: sconnected_def)

(* Simplify in wp contexts *)
lemma case_drop[simp]:
  "(case c of (x,y) \<Rightarrow> P) = P"
  by simp

end
