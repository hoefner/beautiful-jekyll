(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Trace_Monad
  imports
    Trace_Syntax
    Monads.Fun_Pred_Syntax
    Monads.Monad_Lib
    Monads.Strengthen
    Eisbach_Tools.Eisbach_Methods
    Eisbach_Tools.Apply_Trace_Cmd
begin

datatype tmid = Proc | Env

datatype ('s, 'a) tmres = Failed
                        | Diverged "(tmid \<times> 's) llist"
                        | Result "(tmid \<times> 's) list" "'a"

type_synonym ('s, 'a) tmonad = "'s \<Rightarrow> ('s, 'a) tmres set"

print_ast_translation \<open>
  let
    fun tmonad_tr _ [t1, Ast.Appl [Ast.Constant @{type_syntax set},
                         Ast.Appl [Ast.Constant @{type_syntax tmres}, t2, t3]]] =
      if t1 = t2
      then Ast.Appl [Ast.Constant @{type_syntax "tmonad"}, t1, t3]
      else raise Match
  in [(@{type_syntax "fun"}, tmonad_tr)] end\<close>

fun last_st :: "(tmid \<times> 's) list \<Rightarrow> 's \<Rightarrow> 's" where
  "last_st [] s = s"
| "last_st [x] _ = snd x"
| "last_st (x#y#zs) _ = last_st (y#zs) (snd x)"

lemma last_st_append[simp]:
  "last_st (xs @ ys) s = last_st ys (last_st xs s)"
  apply (induct xs arbitrary: s rule: induct_list012; clarsimp)
  apply (cases ys; clarsimp)
  done

definition mres :: "('s,'a) tmonad \<Rightarrow> 's \<Rightarrow> ('a \<times> 's) set" where
  "mres f s = {(rv, last_st ts s) | rv ts. Result ts rv \<in> f s}"

definition return :: "'a \<Rightarrow> ('s,'a) tmonad" where
  "return a \<equiv> \<lambda>s. {Result [] a}"

definition bind ::
  "('s,'a) tmonad \<Rightarrow> ('a \<Rightarrow> ('s,'b) tmonad) \<Rightarrow> ('s,'b) tmonad" where
  "bind f g \<equiv> \<lambda>s. \<Union>r \<in> f s. case r of
    Failed       \<Rightarrow> {Failed}
  | Diverged xs  \<Rightarrow> {Diverged xs}
  | Result xs rv \<Rightarrow> (\<Union>r' \<in> g rv (last_st xs s). case r' of
      Failed        \<Rightarrow> {Failed}
    | Diverged ys   \<Rightarrow> {Diverged (llist_of xs @@ ys)}
    | Result ys rv' \<Rightarrow> {Result (xs @ ys) rv'})"

notation bind (infixl ">>=" 60)

lemma bind_failed:
  "Failed \<in> (f >>= g) s \<longleftrightarrow> Failed \<in> f s \<or> (\<exists>rx xs. Result xs rx \<in> f s \<and> Failed \<in> g rx (last_st xs s))"
  apply (auto simp: bind_def mres_def split: tmres.splits)
  by (metis tmres.exhaust)

lemma bind_diverged:
  "Diverged ts \<in> (f >>= g) s \<longleftrightarrow> Diverged ts \<in> f s \<or> (\<exists>rx xs ys. ts = llist_of xs @@ ys \<and> Result xs rx \<in> f s \<and> Diverged ys \<in> g rx (last_st xs s))"
  apply (auto simp: bind_def mres_def split: tmres.splits)
  by (metis tmres.exhaust)

lemma bind_result:
  "Result ts rv \<in> (f >>= g) s \<longleftrightarrow> (\<exists>rx xs ys. ts = xs @ ys \<and> Result xs rx \<in> f s \<and> Result ys rv \<in> g rx (last_st xs s))"
  apply (auto simp: bind_def mres_def split: tmres.splits)
  by (metis tmres.exhaust)

lemma return_bind[simp]:
  "(return x >>= f) = f x"
  by (auto intro!: ext simp: return_def bind_def split: tmres.splits)

lemma bind_return[simp]:
  "(m >>= return) = m"
  by (auto simp: fun_eq_iff bind_def return_def split: tmres.splits)

lemma bind_assoc:
  "(m >>= f) >>= g  =  m >>= (\<lambda>x. f x >>= g)"
  apply (rule ext)
  apply (rule set_eqI)
  apply (rename_tac res, case_tac res; clarsimp)
    apply (fastforce simp: bind_failed bind_result)
   apply (auto simp: bind_diverged bind_result)[1]
    apply (metis lappend_assoc lappend_llist_of_llist_of)
   apply (metis lappend_assoc lappend_llist_of_llist_of last_st_append)
   apply (auto simp: bind_result)
  apply blast
  apply (metis append.assoc last_st_append)
  done

fun tappend :: "(tmid \<times> 's) list \<Rightarrow> ('s, 'a) tmres \<Rightarrow> ('s, 'a) tmres" where
  "tappend xs Failed = Failed"
| "tappend xs (Diverged ys) = Diverged (llist_of xs @@ ys)"
| "tappend xs (Result ys rv) = Result (xs @ ys) rv"

lemma tappend_def2:
  "tappend xs res = (case res of
     Failed \<Rightarrow> Failed
   | Diverged ys \<Rightarrow> Diverged (llist_of xs @@ ys)
   | Result ys rv \<Rightarrow> Result (xs @ ys) rv)"
  by (cases res; clarsimp)

lemma bind_def2:
  "bind f g = (\<lambda>s. \<Union>r \<in> f s. case r of Failed \<Rightarrow> {Failed}
    | Diverged xs \<Rightarrow> {Diverged xs}
    | Result xs rv \<Rightarrow> tappend xs ` g rv (last_st xs s))"
  unfolding bind_def
  by (auto intro!: ext simp: image_iff tappend_def2 split: tmres.splits)

lemma tappend_nil[simp]:
  "tappend [] res = res"
  by (cases res; clarsimp)

lemma tappend_assoc[simp]:
  "tappend (xs @ ys) res = tappend xs (tappend ys res)"
  apply (cases res; clarsimp)
  by (metis lappend_assoc lappend_llist_of_llist_of)


definition get :: "('s,'s) tmonad" where
  "get \<equiv> \<lambda>s. {(Result [(Proc,s)] s)}"

definition put :: "'s \<Rightarrow> ('s, unit) tmonad" where
  "put s \<equiv> \<lambda>_. {(Result [(Proc,s)] ())}"

definition modify :: "('s \<Rightarrow> 's) \<Rightarrow> ('s, unit) tmonad" where
  "modify f \<equiv> (\<lambda>s. {Result [(Proc, f s)] ()})"

definition put_list :: "(tmid \<times> 's) list \<Rightarrow> ('s, unit) tmonad"
  where "put_list xs \<equiv> \<lambda>s. {Result xs ()}"

definition put_llist :: "(tmid \<times> 's) llist \<Rightarrow> ('s, unit) tmonad"
  where "put_llist xs \<equiv> \<lambda>s. {Diverged xs}"

definition put_elem :: "(tmid \<times> 's) \<Rightarrow> ('s, unit) tmonad" where
  "put_elem x \<equiv> \<lambda>s. {Result [x] ()}"

lemma put_list_simps[simp]:
  "put_list [] = return ()"
  "put_list (x#xs) = put_elem x >>= (\<lambda>_. put_list xs)"
  by (auto simp: put_list_def put_elem_def bind_def return_def)

definition select :: "'a set \<Rightarrow> ('s, 'a) tmonad" where
  "select A \<equiv> \<lambda>s. Result [] ` A"

definition choice ::
  "('s,'a) tmonad \<Rightarrow> ('s,'a) tmonad \<Rightarrow> ('s,'a) tmonad" where
  "choice f g \<equiv> \<lambda>s. (f s \<union> g s)"

notation choice (infixl "\<^bold>+" 20)

definition fail :: "('s, 'a) tmonad" where
  "fail \<equiv> \<lambda>s. {Failed}"

definition assert :: "bool \<Rightarrow> ('a, unit) tmonad" where
  "assert P \<equiv> if P then return () else fail"

definition assert_opt :: "'a option \<Rightarrow> ('b, 'a) tmonad" where
  "assert_opt v \<equiv> case v of None \<Rightarrow> fail | Some v \<Rightarrow> return v"

definition state_assert :: "('s \<Rightarrow> bool) \<Rightarrow> ('s, unit) tmonad" where
  "state_assert P \<equiv> get >>= (\<lambda>s. assert (P s))"

definition gets :: "('s \<Rightarrow> 'a) \<Rightarrow> ('s, 'a) tmonad" where
  "gets f \<equiv> get >>= (\<lambda>s. return (f s))"

definition "when" ::
  "bool \<Rightarrow> ('s, unit) tmonad \<Rightarrow> ('s, unit) tmonad" where
  "when P m \<equiv> if P then m else return ()"

lemma simpler_gets_def:
  "gets f = (\<lambda>s. {Result [(Proc,s)] (f s)})"
  by (simp add: gets_def return_def bind_def get_def)

definition unless :: "bool \<Rightarrow> ('s, unit) tmonad \<Rightarrow> ('s, unit) tmonad" where
  "unless P m \<equiv> when (\<not>P) m"

definition condition ::
  "('s \<Rightarrow> bool) \<Rightarrow> ('s, 'r) tmonad \<Rightarrow> ('s, 'r) tmonad \<Rightarrow> ('s, 'r) tmonad"
  where
  "condition P L R \<equiv> \<lambda>s. if (P s) then (L s) else (R s)"

notation (output)
  condition  ("(condition (_)//  (_)//  (_))" [1000,1000,1000] 1000)

definition gets_the :: "('s \<Rightarrow> 'a option) \<Rightarrow> ('s, 'a) tmonad" where
  "gets_the f \<equiv> gets f >>= assert_opt"

definition gets_map :: "('s \<Rightarrow> 'a \<Rightarrow> 'b option) \<Rightarrow> 'a \<Rightarrow> ('s, 'b) tmonad" where
  "gets_map f p \<equiv> gets f >>= (\<lambda>m. assert_opt (m p))"


definition K_bind :: "'a \<Rightarrow> 'b \<Rightarrow> 'a" where
  K_bind_def[iff]: "K_bind \<equiv> \<lambda>x y. x"

nonterminal
  dobinds and dobind and nobind

syntax
  "_dobind"    :: "[pttrn, 'a] => dobind"             ("(_ <-/ _)" 10)
  ""           :: "dobind => dobinds"                 ("_")
  "_nobind"    :: "'a => dobind"                      ("_")
  "_dobinds"   :: "[dobind, dobinds] => dobinds"      ("(_);//(_)")

  "_do"        :: "[dobinds, 'a] => 'a"               ("(do ((_);//(_))//od)" 100)
syntax (xsymbols)
  "_dobind"    :: "[pttrn, 'a] => dobind"             ("(_ \<leftarrow>/ _)" 10)

translations
  "_do (_dobinds b bs) e"  == "_do b (_do bs e)"
  "_do (_nobind b) e"      == "b >>= (CONST K_bind e)"
  "do x <- a; e od"        == "a >>= (\<lambda>x. e)"

lemma "do x \<leftarrow> return 1;
          return (2::nat);
          return x
       od =
       return 1 >>=
       (\<lambda>x. return (2::nat) >>=
            K_bind (return x))"
  by (rule refl)

lemma "do x \<leftarrow> return 1;
          return 2;
          return x
       od = return 1"
  by simp

definition liftM :: "('a \<Rightarrow> 'b) \<Rightarrow> ('s,'a) tmonad \<Rightarrow> ('s, 'b) tmonad" where
  "liftM f m \<equiv> do x \<leftarrow> m; return (f x) od"

definition maybeM :: "('a \<Rightarrow> ('s, unit) tmonad) \<Rightarrow> 'a option \<Rightarrow> ('s, unit) tmonad" where
  "maybeM f y \<equiv> case y of Some x \<Rightarrow> f x | None \<Rightarrow> return ()"

definition sequence_x :: "('s, 'a) tmonad list \<Rightarrow> ('s, unit) tmonad" where
  "sequence_x xs \<equiv> foldr (\<lambda>x y. x >>= (\<lambda>_. y)) xs (return ())"

definition mapM_x :: "('a \<Rightarrow> ('s,'b) tmonad) \<Rightarrow> 'a list \<Rightarrow> ('s, unit) tmonad" where
  "mapM_x f xs \<equiv> sequence_x (map f xs)"

definition zipWithM_x ::
  "('a \<Rightarrow> 'b \<Rightarrow> ('s,'c) tmonad) \<Rightarrow> 'a list \<Rightarrow> 'b list \<Rightarrow> ('s, unit) tmonad"
  where
  "zipWithM_x f xs ys \<equiv> sequence_x (zipWith f xs ys)"

definition sequence :: "('s, 'a) tmonad list \<Rightarrow> ('s, 'a list) tmonad" where
  "sequence xs \<equiv> let mcons = (\<lambda>p q. p >>= (\<lambda>x. q >>= (\<lambda>y. return (x#y))))
                 in foldr mcons xs (return [])"

definition mapM :: "('a \<Rightarrow> ('s,'b) tmonad) \<Rightarrow> 'a list \<Rightarrow> ('s, 'b list) tmonad" where
  "mapM f xs \<equiv> sequence (map f xs)"

definition zipWithM ::
  "('a \<Rightarrow> 'b \<Rightarrow> ('s,'c) tmonad) \<Rightarrow> 'a list \<Rightarrow> 'b list \<Rightarrow> ('s, 'c list) tmonad"
  where
  "zipWithM f xs ys \<equiv> sequence (zipWith f xs ys)"

definition foldM :: "('b \<Rightarrow> 'a \<Rightarrow> ('s, 'a) tmonad) \<Rightarrow> 'b list \<Rightarrow> 'a \<Rightarrow> ('s, 'a) tmonad" where
  "foldM m xs a \<equiv> foldr (\<lambda>p q. q >>= m p) xs (return a) "

primrec filterM :: "('a \<Rightarrow> ('s, bool) tmonad) \<Rightarrow> 'a list \<Rightarrow> ('s, 'a list) tmonad" where
  "filterM P []       = return []"
| "filterM P (x # xs) = do
     b  <- P x;
     ys <- filterM P xs;
     return (if b then (x # ys) else ys)
   od"


inductive_set whileLoopF for C B where
  \<comment> \<open>Failure within a loop iteration\<close>
  "\<lbrakk> C r s; Failed \<in> B r s \<rbrakk> \<Longrightarrow> (r, s) \<in> whileLoopF C B"
  \<comment> \<open>Failure in some future iteration\<close>
| "\<lbrakk> C r s; Result ts rv \<in> B r s;
     (rv, last_st ts s) \<in> whileLoopF C B \<rbrakk>
     \<Longrightarrow> (r, s) \<in> whileLoopF C B"

coinductive_set whileLoopD for C B where
  \<comment> \<open>Divergence within a loop iteration\<close>
  "\<lbrakk> C r s; Diverged ts \<in> B r s \<rbrakk> \<Longrightarrow> (r, s, <ts>) \<in> whileLoopD C B"
  \<comment> \<open>Divergence via a future loop iteration or infinite loop\<close>
| "\<lbrakk> C r s; Result xs rv \<in> B r s;
     (rv, last_st xs s, xss) \<in> whileLoopD C B \<rbrakk>
     \<Longrightarrow> (r, s, llist_of xs ## xss) \<in> whileLoopD C B"

inductive_set whileLoopR for C B where
  \<comment> \<open>Termination when the guard is false\<close>
    "\<lbrakk> \<not> C r s \<rbrakk> \<Longrightarrow> (r, s, [], r) \<in> whileLoopR C B"
  \<comment> \<open>Termination after at least one iteration\<close>
  | "\<lbrakk> C r s; Result xs rv \<in> B r s;
       (rv, last_st xs s, ys, rv') \<in> whileLoopR C B \<rbrakk>
       \<Longrightarrow> (r, s, xs@ys, rv') \<in> whileLoopR C B"

definition whileLoop where
  "whileLoop C B \<equiv> \<lambda>r s.
     {res | res. res = Failed \<and> (r,s) \<in> whileLoopF C B}
   \<union> {Result ts rv | ts rv. (r, s, ts, rv) \<in> whileLoopR C B}
   \<union> {Diverged (lconcat ts) | ts. (r, s, ts) \<in> whileLoopD C B}"

definition loop :: "('s, unit) tmonad \<Rightarrow> ('s, unit) tmonad" where
  "loop f \<equiv> whileLoop (\<lambda>_ _. True) (\<lambda>_. f) ()"

notation (output)
  whileLoop  ("(whileLoop (_)//  (_))" [1000, 1000] 1000)

abbreviation loop_fail :: "('s, unit) tmonad \<Rightarrow> (unit \<times> 's) set" where
  "loop_fail f \<equiv> whileLoopF (\<lambda>_ _. True) (\<lambda>_. f)"

abbreviation loop_div :: "('s, unit) tmonad \<Rightarrow> (unit \<times> 's \<times> (tmid \<times> 's) llist llist) set" where
  "loop_div f \<equiv> whileLoopD (\<lambda>_ _. True) (\<lambda>_. f)"

lemma loop_res_empty[simp]:
  "(rv, s, xs, rv) \<notin> whileLoopR (\<lambda>_ _. True) (\<lambda>_. f)"
  by (rule notI, erule whileLoopR.induct, auto)

lemma loop_def2:
  "loop f \<equiv> \<lambda>s. {res | res. res = Failed \<and> ((),s) \<in> loop_fail f} \<union>
                 {Diverged (lconcat ts) | ts. ((), s, ts) \<in> loop_div f}"
  by (auto simp: loop_def whileLoop_def)


definition notM :: "('s, bool) tmonad \<Rightarrow> ('s, bool) tmonad" where
  "notM m = do c \<leftarrow> m; return (\<not> c) od"

definition whileM :: "('s, bool) tmonad \<Rightarrow> ('s, 'a) tmonad \<Rightarrow> ('s, unit) tmonad" where
  "whileM C B \<equiv> do
    c \<leftarrow> C;
    whileLoop (\<lambda>c s. c) (\<lambda>_. do B; C od) c;
    return ()
  od"

definition ifM :: "('s, bool) tmonad \<Rightarrow> ('s, 'a) tmonad \<Rightarrow> ('s, 'a) tmonad \<Rightarrow> ('s, 'a) tmonad" where
  "ifM test t f = do
    c \<leftarrow> test;
    if c then t else f
   od"

definition whenM :: "('s, bool) tmonad \<Rightarrow> ('s, unit) tmonad \<Rightarrow> ('s, unit) tmonad" where
  "whenM t m = ifM t m (return ())"

definition orM :: "('s, bool) tmonad \<Rightarrow> ('s, bool) tmonad \<Rightarrow> ('s, bool) tmonad" where
  "orM a b = ifM a (return True) b"

definition andM :: "('s, bool) tmonad \<Rightarrow> ('s, bool) tmonad \<Rightarrow> ('s, bool) tmonad" where
  "andM a b = ifM a b (return False)"


definition env_steps :: "('s,unit) tmonad" where
  "env_steps \<equiv>
   do \<comment> \<open>Select a terminal environment trace\<close>
      xs \<leftarrow> select UNIV;
      tr \<leftarrow> return (map (Pair Env) xs);
      \<comment> \<open>Select a divergent environment trace\<close>
      ys \<leftarrow> select UNIV;
      tr' \<leftarrow> return (lmap (Pair Env) ys);
      \<comment> \<open>Choose one of the two traces\<close>
      choice (put_list tr) (put_llist ys)
   od"

definition interference :: "'a \<Rightarrow> ('s,'a) tmonad" where
  "interference \<equiv> \<lambda>rv.
   do env_steps;
      return rv
   od"

definition Await :: "('s \<Rightarrow> bool) \<Rightarrow> ('s,unit) tmonad" where
  "Await c \<equiv>
  do
    s \<leftarrow> get;
    \<comment> \<open>Add unfiltered environment events, with the last one
       satisfying the `c' state predicate\<close>
    xs \<leftarrow> select {map (Pair Env) xs | xs. c (last (s#xs))};
    ys \<leftarrow> select {lmap (Pair Env) ys | ys. llist_all (\<lambda>y. \<not>c y) ys};
    (put_list xs \<^bold>+ put_llist ys)
  od"

definition parallel ::
  "('s,'a) tmonad \<Rightarrow> ('s,'a) tmonad \<Rightarrow> ('s,'a) tmonad" where
  "parallel f g \<equiv> \<lambda>s. {res. case res of
     Failed \<Rightarrow> Failed \<in> f s \<and> Failed \<in> g s
   | Diverged xs \<Rightarrow> \<exists>fs. llength fs = llength xs
     \<and> Diverged (lmap (\<lambda>(b,a,s). (if b then a else Env, s))
                                              (lzip fs xs)) \<in> f s
     \<and> Diverged (lmap (\<lambda>(b,a,s). (if b then Env else a, s))
                                              (lzip fs xs)) \<in> g s
   | Result xs rv \<Rightarrow> \<exists>fs. length fs = length xs
     \<and> Result (map (\<lambda>(b,a,s). (if b then a else Env, s))
                                             (zip fs xs)) rv \<in> f s
     \<and> Result (map (\<lambda>(b,a,s). (if b then Env else a, s))
                                             (zip fs xs)) rv \<in> g s}"

end
