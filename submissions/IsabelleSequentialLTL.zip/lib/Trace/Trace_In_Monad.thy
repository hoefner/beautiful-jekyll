(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2023, Proofcraft Pty Ltd
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Trace_In_Monad
  imports Trace_Lemmas
begin

lemma in_bind:
  "((r,s') \<in> mres (do x \<leftarrow> f; g x od) s) =
   (\<exists>s'' x. (x, s'') \<in> mres f s \<and> (r, s') \<in> mres (g x) s'')"
  supply last_st_append[simp del] last_st_append[symmetric, simp]
  apply (auto simp: bind_def2 split_def mres_def split: tmres.splits)
   apply (case_tac x; clarsimp)
   apply (fastforce simp: tappend_def2 split: tmres.splits)
  apply (rule exI, rule conjI, rule refl)
  apply (erule rev_bexI)
  apply (auto simp: tappend_def2 split: tmres.splits)
  done

lemma in_return:
  "(r, s') \<in> mres (return v) s = (r = v \<and> s' = s)"
  by (simp add: return_def mres_def)

lemma in_fail:
  "r \<in> mres fail s = False"
  by (simp add: fail_def mres_def)

lemma in_assert:
  "(r, s') \<in> mres (assert P) s = (P \<and> s' = s)"
  by (simp add: assert_def return_def fail_def mres_def)

lemma in_assert_opt:
  "(r, s') \<in> mres (assert_opt v) s = (v = Some r \<and> s' = s)"
  by (auto simp: assert_opt_def in_fail in_return split: option.splits)

lemma in_get:
  "(r, s') \<in> mres get s = (r = s \<and> s' = s)"
  by (simp add: get_def mres_def)

lemma in_gets:
  "(r, s') \<in> mres (gets f) s = (r = f s \<and> s' = s)"
  by (simp add: simpler_gets_def mres_def)

lemma in_put:
  "(r, s') \<in> mres (put x) s = (s' = x \<and> r = ())"
  by (simp add: put_def mres_def)

lemma in_when:
  "(v, s') \<in> mres (when P f) s = ((P \<longrightarrow> (v, s') \<in> mres f s) \<and> (\<not>P \<longrightarrow> v = () \<and> s' = s))"
  by (simp add: when_def in_return)

lemma in_unless:
  "(v, s') \<in> mres (unless P f) s = ((\<not> P \<longrightarrow> (v, s') \<in> mres f s) \<and> (P \<longrightarrow> v = () \<and> s' = s))"
  by (simp add: unless_def in_when)

lemma in_modify:
  "(v, s') \<in> mres (modify f) s = (s'=f s \<and> v = ())"
  by (auto simp add: modify_def bind_def get_def put_def mres_def)

lemma gets_the_in_monad:
  "((v, s') \<in> mres (gets_the f) s) = (s' = s \<and> f s = Some v)"
  by (auto simp: gets_the_def in_bind in_gets in_assert_opt split: option.split)

lemma in_choice:
  "(r,s') \<in> mres (f \<^bold>+ g) s = ((r,s') \<in> mres f s \<or> (r,s') \<in> mres g s)"
  by (auto simp add: choice_def mres_def)

lemma in_liftM:
  "((r, s') \<in> mres (liftM t f) s) = (\<exists>r'. (r', s') \<in> mres f s \<and> r = t r')"
  by (simp add: liftM_def in_return in_bind)

lemmas in_monad = in_bind in_fail in_assert in_return
                  in_assert_opt in_get in_gets in_put in_when
                  in_unless in_modify gets_the_in_monad
                  in_choice in_liftM

lemma bind_det_exec:
  "mres a s = {(r,s')} \<Longrightarrow> mres (a >>= b) s = mres (b r) s'"
  by (simp add: in_bind set_eq_iff)

lemma in_bind_det_exec:
  "mres a s = {(r,s')} \<Longrightarrow> (s'' \<in> mres (a >>= b) s) = (s'' \<in> mres (b r) s')"
  by (cases s'', simp add: in_bind)

lemma bind_execI:
  "\<lbrakk> (r'',s'') \<in> mres f s; \<exists>x \<in> mres (g r'') s''. P x \<rbrakk> \<Longrightarrow> \<exists>x \<in> mres (f >>= g) s. P x"
  by (force simp: Bex_def in_bind)

end
