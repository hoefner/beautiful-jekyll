(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2014, General Dynamics C4 Systems
 *
 * SPDX-License-Identifier: GPL-2.0-only
 *)

theory Structures_A
imports
  Trace.Trace_Toplevel
begin

datatype thread_state =
    Active
  | Inactive
  | Idle

record tcb = tcb_state :: thread_state

primrec runnable :: "thread_state \<Rightarrow> bool" where
  "runnable Active   = True"
| "runnable Inactive = False"
| "runnable Idle     = False"

datatype kernel_object = TCB tcb | ArchObject

type_synonym obj_ref = nat

type_synonym kheap = "obj_ref \<Rightarrow> kernel_object option"

record state =
  kheap            :: "kheap"
  cur_thread       :: "obj_ref"
  idle_thread      :: "obj_ref"
  ready_queues     :: "obj_ref list"

type_synonym 'a s_monad = "(state, 'a) tmonad"

translations (type) "'a s_monad" <= (type) "state \<Rightarrow> (('a \<times> state) \<Rightarrow> bool) \<times> bool"

end
