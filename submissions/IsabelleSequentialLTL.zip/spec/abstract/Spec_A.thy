(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2014, General Dynamics C4 Systems
 *
 * SPDX-License-Identifier: GPL-2.0-only
 *)

theory Spec_A
imports
  Schedule_A
begin

(* Nothing to do here *)

end
