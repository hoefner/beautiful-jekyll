(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2014, General Dynamics C4 Systems
 *
 * SPDX-License-Identifier: GPL-2.0-only
 *)

theory Schedule_A
imports KHeap_A
begin

definition switch_to_thread :: "obj_ref \<Rightarrow> unit s_monad" where
  "switch_to_thread thread \<equiv> do
     set_cur_thread thread;
     tcb_sched_action (tcb_sched_dequeue) thread
   od"

definition switch_to_idle_thread :: "unit s_monad" where
  "switch_to_idle_thread \<equiv> do
     thread \<leftarrow> get_idle_thread;
     set_cur_thread thread
   od"

definition choose_thread :: "unit s_monad" where
  "choose_thread \<equiv> do
     queues \<leftarrow> get_tcb_queue;
     if queues = []
     then switch_to_idle_thread
     else switch_to_thread (hd queues)
   od"

definition schedule :: "unit s_monad" where
  "schedule \<equiv> do
     ct \<leftarrow> get_cur_thread;
     ct_state \<leftarrow> get_thread_state ct;
     when (runnable ct_state)
          (tcb_sched_action tcb_sched_enqueue ct);
     choose_thread
   od"

definition scheduler :: "unit s_monad" where
  "scheduler \<equiv> loop schedule"

end
