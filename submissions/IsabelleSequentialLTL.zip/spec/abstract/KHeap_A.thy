(*
 * Copyright 2025, Ryan Barry, Australian National University
 * Copyright 2014, General Dynamics C4 Systems
 *
 * SPDX-License-Identifier: GPL-2.0-only
 *)

theory KHeap_A
imports Structures_A
begin

definition get_object :: "obj_ref \<Rightarrow> kernel_object s_monad" where
  "get_object ptr \<equiv> do
     kh \<leftarrow> gets kheap;
     assert_opt (kh ptr)
   od"

definition set_object ::
  "obj_ref \<Rightarrow> kernel_object \<Rightarrow> unit s_monad" where
  "set_object ptr obj \<equiv>
     modify (\<lambda>s. s\<lparr>kheap := (kheap s)(ptr \<mapsto> obj)\<rparr>)"

definition tcb_of :: "kernel_object \<Rightarrow> tcb option" where
  "tcb_of ko \<equiv> case ko of TCB tcb \<Rightarrow> Some tcb | _ \<Rightarrow> None"

definition thread_get :: "(tcb \<Rightarrow> 'a) \<Rightarrow> obj_ref \<Rightarrow> 'a s_monad" where
  "thread_get f tptr \<equiv> do
     ko <- get_object tptr;
     tcb <- assert_opt (tcb_of ko);
     return (f tcb)
   od"

definition thread_set ::
  "(('a \<Rightarrow> 'a) \<Rightarrow> tcb \<Rightarrow> tcb) \<Rightarrow> 'a \<Rightarrow> obj_ref \<Rightarrow> unit s_monad" where
  "thread_set f x tptr \<equiv> do
     ko <- get_object tptr;
     tcb <- assert_opt (tcb_of ko);
     set_object tptr (TCB (f (\<lambda>_. x) tcb))
   od"

definition get_thread_state ::
  "obj_ref \<Rightarrow> thread_state s_monad" where
  "get_thread_state ref \<equiv> thread_get tcb_state ref"

definition set_thread_state ::
  "obj_ref \<Rightarrow> thread_state \<Rightarrow> unit s_monad" where
  "set_thread_state ref ts \<equiv> thread_set tcb_state_update ts ref"

definition get_tcb_queue :: "obj_ref list s_monad" where
  "get_tcb_queue \<equiv> gets ready_queues"

definition set_tcb_queue :: "obj_ref list \<Rightarrow> unit s_monad" where
  "set_tcb_queue queue \<equiv> modify (ready_queues_update (\<lambda>_. queue))"

definition tcb_sched_enqueue ::
  "obj_ref \<Rightarrow> obj_ref list \<Rightarrow> obj_ref list" where
  "tcb_sched_enqueue thread queue \<equiv>
     if thread \<notin> set queue then queue @ [thread] else queue"

definition tcb_sched_dequeue ::
   "obj_ref \<Rightarrow> obj_ref list \<Rightarrow> obj_ref list" where
  "tcb_sched_dequeue thread queue \<equiv> filter ((\<noteq>) thread) queue"

definition tcb_sched_action where
  "tcb_sched_action action thread \<equiv> do
     queue \<leftarrow> get_tcb_queue;
     set_tcb_queue (action thread queue)
   od"

definition get_cur_thread :: "obj_ref s_monad" where
  "get_cur_thread \<equiv> gets cur_thread"

definition set_cur_thread :: "obj_ref \<Rightarrow> unit s_monad" where
  "set_cur_thread t \<equiv> modify (cur_thread_update (\<lambda>_. t))"

definition get_idle_thread :: "obj_ref s_monad" where
  "get_idle_thread \<equiv> gets idle_thread"

definition set_idle_thread :: "obj_ref \<Rightarrow> unit s_monad" where
  "set_idle_thread t \<equiv> modify (idle_thread_update (\<lambda>_. t))"

end
