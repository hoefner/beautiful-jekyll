(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Schedule_TL
imports KHeap_TL
begin

(* FIXME ryanb: move *)
lemma valid_validl2[wp]:
  "\<lbrace>P\<rbrace> f \<lbrace>Q\<rbrace> \<Longrightarrow> \<lbrace>P\<rbrace>, \<lbrace>True\<^sub>l\<rbrace> f \<lbrace>Q\<rbrace>, \<lbrace>True\<^sub>l\<rbrace>"
  apply (clarsimp simp: valid_def validl2_def)
  using in_mres by fastforce

lemma tcb_sched_enqueue_mono:
  "\<lbrace>\<top>\<rbrace>
   tcb_sched_action tcb_sched_enqueue thread
   \<lbrace>\<box>\<A>(qpos_mono t)\<rbrace>\<^sup>*"
  unfolding tcb_sched_action_def
  apply (rule hoare_pre)
   apply ltl_wp
    apply (wp single_step_wps kh_wps)
   apply (wp kh_wps single_step_wps validl2_split)
  apply (auto simp: qpos_mono_def qpos_def tcb_sched_enqueue_def eSuc_eq_infinity_iff)
  apply (metis eSuc_ile_mono eindex_append_le)
  done

lemma tcb_sched_dequeue_mono:
  "\<lbrace>\<lambda>s. thread = cur_thread s\<rbrace>
   tcb_sched_action tcb_sched_dequeue thread
   \<lbrace>\<box>\<A>(qpos_mono t)\<rbrace>\<^sup>*"
  unfolding tcb_sched_action_def
  apply (rule hoare_pre)
   apply ltl_wp+
    apply (wp kh_wps single_step_wps validl2_split)
   apply (wp kh_wps single_step_wps validl2_split)
  apply (auto simp: qpos_mono_def qpos_def tcb_sched_dequeue_def)
   apply (metis eSuc_le_iff eindex_filter_le)
  by (metis eindex_filter_le enat_ord_simps(5) infinity_eq_eSuc_iff)

lemma switch_to_thread_mono:
  "\<lbrace>ct_runnable_ready\<rbrace> switch_to_thread thread \<lbrace>\<box>\<A>(qpos_mono t)\<rbrace>\<^sup>*"
  unfolding switch_to_thread_def
  apply (rule validl_weaken_pre)
   apply ltl_wp+
    apply (wp tcb_sched_dequeue_mono)
   apply (wp kh_wps single_step_wps validl2_split)
  apply (clarsimp simp: qpos_mono_def)
  apply (auto simp: qpos_def eSuc_enat ct_runnable_ready_def)
  done

lemma switch_to_idle_thread_mono:
  "\<lbrace>ct_runnable_ready\<rbrace> switch_to_idle_thread \<lbrace>\<box>\<A>(qpos_mono t)\<rbrace>\<^sup>*"
  unfolding switch_to_idle_thread_def
  apply (rule validl_weaken_pre)
   apply ltl_wp+
    apply (wp kh_wps single_step_wps validl2_split)
   apply (wp kh_wps single_step_wps validl2_split)
  apply (clarsimp simp: qpos_mono_def)
  apply (auto simp: qpos_def eSuc_enat ct_runnable_ready_def)
  done

lemma choose_thread_mono:
  "\<lbrace>ct_runnable_ready\<rbrace> choose_thread \<lbrace>\<box>\<A>(qpos_mono t)\<rbrace>\<^sup>*"
  unfolding choose_thread_def
  apply (rule hoare_pre)
   apply ltl_wp
    apply (wp validl2_vcg_if_split switch_to_idle_thread_mono switch_to_thread_mono)
   apply (wp kh_wps single_step_wps validl2_split)
  apply clarsimp
  done

lemma schedule_mono:
  "\<lbrace>\<top>\<rbrace> schedule \<lbrace>\<box>\<A>(qpos_mono t)\<rbrace>\<^sup>*"
  unfolding schedule_def
  apply (rule hoare_pre)
   apply ltl_wp+
      apply (wp choose_thread_mono)
     apply (rule validl2_split)
      apply (wp when_wp kh_wps)
     apply (wp when_G tcb_sched_enqueue_mono)
    apply clarsimp
    apply (wp single_step_wps kh_wps validl2_split)
   apply (wp single_step_wps kh_wps validl2_split)
  apply (auto simp: ct_runnable_ready_def tcb_sched_enqueue_def pred_tcb_at_def tcb_of_def)
  done

lemma tcb_sched_dequeue_progress:
  "\<lbrace>\<lambda>s. cur_thread s = thread \<and> (\<exists>qs. ready_queues s = thread # qs)\<rbrace>
   tcb_sched_action tcb_sched_dequeue thread
   \<lbrace>\<diamond>\<A>(qpos_progress t)\<rbrace>\<^sup>*"
  unfolding tcb_sched_action_def
  apply (rule hoare_pre)
   apply ltl_wpr
    apply (wp kh_wps single_step_wps validl2_split)
   apply (rule validl2_split, wp kh_wps, wp single_step_wps)
  apply (clarsimp simp: qpos_progress_def qpos_def tcb_sched_dequeue_def)
  apply (case_tac "eindex qs t"; clarsimp simp: eSuc_enat)
  by (metis eSuc_def eSuc_le_iff eindex_filter_le enat.simps(4))

lemma switch_to_thread_progress:
  "\<lbrace>\<lambda>s. \<exists>qs. ready_queues s = thread # qs\<rbrace>
   switch_to_thread thread
   \<lbrace>\<diamond>\<A>(qpos_progress t)\<rbrace>\<^sup>*"
  unfolding switch_to_thread_def
  apply (rule hoare_pre)
   apply ltl_wpr
    apply (wp tcb_sched_dequeue_progress)
   apply (rule validl2_split, wp kh_wps, wp single_step_wps)
  apply simp
  done

lemma switch_to_idle_thread_progress:
  "\<lbrace>\<lambda>s. ready_queues s = []\<rbrace>
   switch_to_idle_thread
   \<lbrace>\<diamond>\<A>(qpos_progress t)\<rbrace>\<^sup>*"
  unfolding switch_to_idle_thread_def
  apply (rule hoare_pre)
   apply ltl_wpr
    apply (wp single_step_wps kh_wps)
   apply (wp kh_wps)
  apply (clarsimp simp: qpos_progress_def qpos_def enat_0_iff)
  done

lemma choose_thread_progress:
  "\<lbrace>\<top>\<rbrace> choose_thread \<lbrace>\<diamond>\<A>(qpos_progress t)\<rbrace>\<^sup>*"
  unfolding choose_thread_def
  apply (rule validl_weaken_pre)
   apply ltl_wpr
    apply (wp validl2_vcg_if_split switch_to_idle_thread_progress switch_to_thread_progress)
   apply (wp single_step_wps kh_wps)
  apply (case_tac "ready_queues s"; clarsimp)
  done

lemma schedule_progress:
  "\<lbrace>\<top>\<rbrace> schedule \<lbrace>\<diamond>\<A>(qpos_progress t)\<rbrace>\<^sup>*"
  unfolding schedule_def
  apply (rule validl_weaken_pre)
  apply ltl_wpr+
  by (wpsimp wp: choose_thread_progress)+

lemma switch_to_thread_valid_ready_queues[wp]:
  "\<lbrace>valid_ready_queues\<rbrace>
   switch_to_thread thread
   \<lbrace>\<lambda>_. valid_ready_queues\<rbrace>"
  unfolding switch_to_thread_def
  apply (wpsimp wp: kh_wps)
  apply (clarsimp simp: valid_ready_queues_def tcb_sched_dequeue_def)
  done

crunch choose_thread
  for valid_idle_thread[wp]: valid_idle_thread
  and valid_ready_queues[wp]: valid_ready_queues

lemma switch_to_thread_valid_cur_thread[wp]:
  "\<lbrace>tcb_at thread\<rbrace> switch_to_thread thread \<lbrace>\<lambda>_. valid_cur_thread\<rbrace>"
  unfolding switch_to_thread_def
  apply (wpsimp wp: kh_wps)
  apply (clarsimp simp: valid_cur_thread_def tcb_sched_dequeue_def)
  done

lemma switch_to_idle_thread_valid_cur_thread[wp]:
  "\<lbrace>valid_idle_thread\<rbrace> switch_to_idle_thread \<lbrace>\<lambda>_. valid_cur_thread\<rbrace>"
  unfolding switch_to_idle_thread_def
  apply (wpsimp wp: kh_wps)
  apply (clarsimp simp: valid_idle_thread_def valid_cur_thread_def)
  done

lemma choose_thread_valid_cur_thread[wp]:
  "\<lbrace>invs\<rbrace> choose_thread \<lbrace>\<lambda>_. valid_cur_thread\<rbrace>"
  unfolding choose_thread_def invs_def
  apply (wpsimp wp: hoare_vcg_imp_lift | wp kh_wps)+
  apply (case_tac "ready_queues s"; clarsimp)
  by (auto simp: invs_def valid_cur_thread_def valid_idle_thread_def
                  valid_ready_queues_def pred_tcb_at_def)

crunch choose_thread
  for invs[wp]: invs
  (simp: invs_def)

lemma get_thread_state_rv_wp:
  "\<lbrace>\<lambda>s. pred_tcb_at (\<lambda>tcb. P (tcb_state tcb)) t s\<rbrace>
   get_thread_state t
   \<lbrace>\<lambda>ct s. P ct\<rbrace>"
  by (wpsimp wp: kh_wps simp: pred_tcb_at_def tcb_of_def)

lemma tcb_sched_enqueue_valid_cur_thread[wp]:
  "\<lbrace>invs and runnable_tcb_at t\<rbrace>
   tcb_sched_action tcb_sched_enqueue t
   \<lbrace>\<lambda>_. invs\<rbrace>"
  unfolding invs_def
  apply (wpsimp wp: kh_wps)
  apply (auto simp: valid_ready_queues_def tcb_sched_enqueue_def)
  done

lemma schedule_invs[wp]:
  "\<lbrace>invs\<rbrace> schedule \<lbrace>\<lambda>_. invs\<rbrace>"
  unfolding schedule_def
  apply (wpsimp wp: hoare_vcg_if_lift2 hoare_vcg_imp_lift'
                    get_thread_state_rv_wp get_cur_thread_wp)
  apply (clarsimp simp: invs_def valid_cur_thread_def pred_tcb_at_def)
  done


crunch choose_thread
  for (no_fail) no_fail[wp, simp]

lemma no_fail_schedule[wp, simp]:
  "no_fail valid_cur_thread schedule"
  unfolding schedule_def
  by (wpsimp wp: kh_wps simp: valid_cur_thread_def)

end
