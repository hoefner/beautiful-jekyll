(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory KHeap_TL
imports Setup_TL
begin

named_theorems kh_wps

lemma get_object_wp[kh_wps]:
  "\<lbrace>\<lambda>s. \<forall>obj. kheap s ptr = Some obj \<longrightarrow> Q obj s\<rbrace>
   get_object ptr \<lbrace>Q\<rbrace>"
  unfolding get_object_def by wpsimp

lemma set_object_wp[kh_wps]:
  "\<lbrace>\<lambda>s.  Q (s\<lparr>kheap := (kheap s)(ptr \<mapsto> obj)\<rparr>)\<rbrace>
   set_object ptr obj \<lbrace>\<lambda>_. Q\<rbrace>"
  unfolding set_object_def by wpsimp

lemma get_thread_state_wp[kh_wps]:
  "\<lbrace>\<lambda>s. \<forall>tcb. pred_tcb_at ((=) tcb) t s \<longrightarrow> Q (tcb_state tcb) s\<rbrace>
   get_thread_state t \<lbrace>Q\<rbrace>"
  unfolding get_thread_state_def thread_get_def
  by (wpsimp wp: kh_wps
           simp: pred_tcb_at_def tcb_of_def
          split: kernel_object.splits)

lemma set_thread_state_wp[kh_wps]:
  "\<lbrace>\<lambda>s. \<forall>tcb. pred_tcb_at ((=) tcb) t s
              \<longrightarrow> Q (s\<lparr>kheap := (kheap s)
                                (t \<mapsto> TCB (tcb\<lparr>tcb_state := ts\<rparr>))\<rparr>)\<rbrace>
   set_thread_state t ts \<lbrace>\<lambda>_. Q\<rbrace>"
  unfolding set_thread_state_def thread_set_def
  by (wpsimp wp: kh_wps
           simp: pred_tcb_at_def tcb_of_def
          split: kernel_object.splits)

lemma get_tcb_queue_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (ready_queues s) s\<rbrace> get_tcb_queue \<lbrace>Q\<rbrace>"
  unfolding get_tcb_queue_def by (wp kh_wps)

lemma set_tcb_queue_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (s\<lparr>ready_queues := qs\<rparr>)\<rbrace> set_tcb_queue qs \<lbrace>\<lambda>_. Q\<rbrace>"
  unfolding set_tcb_queue_def by (wp kh_wps)

lemma tcb_sched_action_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (s\<lparr>ready_queues := act t (ready_queues s)\<rparr>)\<rbrace>
   tcb_sched_action act t \<lbrace>\<lambda>_. Q\<rbrace>"
  unfolding tcb_sched_action_def set_tcb_queue_def
  by (wp kh_wps)

lemma get_cur_thread_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (cur_thread s) s\<rbrace> get_cur_thread \<lbrace>Q\<rbrace>"
  unfolding get_cur_thread_def by (wp kh_wps)

lemma set_cur_thread_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (s\<lparr>cur_thread := ct\<rparr>)\<rbrace> set_cur_thread ct \<lbrace>\<lambda>_. Q\<rbrace>"
  unfolding set_cur_thread_def by (wp kh_wps)

lemma get_idle_thread_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (idle_thread s) s\<rbrace> get_idle_thread \<lbrace>Q\<rbrace>"
  unfolding get_idle_thread_def by (wp kh_wps)

lemma set_idle_thread_wp[kh_wps]:
  "\<lbrace>\<lambda>s. Q (s\<lparr>idle_thread := it\<rparr>)\<rbrace> set_idle_thread it \<lbrace>\<lambda>_. Q\<rbrace>"
  unfolding set_idle_thread_def by (wp kh_wps)

crunch get_object, get_cur_thread, get_tcb_queue,
       get_idle_thread, get_thread_state
  for inv[wp]: P

crunch get_object
  for inv: P

lemma single_step_get_object[simp, wp]:
  "single_step (get_object ptr)"
  unfolding get_object_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_set_object[simp, wp]:
  "single_step (set_object ptr obj)"
  unfolding set_object_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_get_cur_thread[simp, wp]:
  "single_step (get_cur_thread)"
  unfolding get_cur_thread_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_set_cur_thread[simp, wp]:
  "single_step (set_cur_thread action)"
  unfolding set_cur_thread_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_get_idle_thread[simp, wp]:
  "single_step (get_idle_thread)"
  unfolding get_idle_thread_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_set_idle_thread[simp, wp]:
  "single_step (set_idle_thread action)"
  unfolding set_idle_thread_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_get_tcb_queue[simp, wp]:
  "single_step (get_tcb_queue)"
  unfolding get_tcb_queue_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_set_tcb_queue[simp, wp]:
  "single_step (set_tcb_queue queue)"
  unfolding set_tcb_queue_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_thread_get[simp, wp]:
  "single_step (thread_get f ptr)"
  unfolding thread_get_def
  by (wpsimp | rule single_step_bind)+

lemma single_step_get_thread_state[simp, wp]:
  "single_step (get_thread_state ptr)"
  unfolding get_thread_state_def
  by (wpsimp | rule single_step_bind)+

crunch get_cur_thread
  for (no_fail) no_fail[wp, simp]

lemma no_fail_thread_get[wp, simp]:
  "no_fail (tcb_at t) (thread_get f t)"
  unfolding thread_get_def get_object_def
  by (wpsimp simp: pred_tcb_at_def tcb_of_def)

crunch get_thread_state, get_cur_thread
  for (no_fail) no_fail[wp, simp]

end
