(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Example_TL
imports Spec_TL
begin

abbreviation "idle_ptr  \<equiv> 0x00"
abbreviation "tcb_A_ptr \<equiv> 0x10"
abbreviation "tcb_B_ptr \<equiv> 0x20"

definition init_kheap :: kheap where
  "init_kheap \<equiv> (\<lambda>x. None)(
     tcb_A_ptr \<mapsto> TCB\<lparr>tcb_state = Active\<rparr>,
     tcb_B_ptr \<mapsto> TCB\<lparr>tcb_state = Active\<rparr>,
     idle_ptr  \<mapsto> TCB\<lparr>tcb_state = Idle\<rparr>)"

definition init_state :: state where
  "init_state \<equiv> \<lparr>kheap = init_kheap,
                 cur_thread = idle_ptr,
                 idle_thread = idle_ptr,
                 ready_queues = [tcb_A_ptr, tcb_B_ptr]\<rparr>"

lemma invs_init_state:
  "invs init_state"
  by (auto simp: init_state_def init_kheap_def invs_def
                 valid_cur_thread_def valid_idle_thread_def
                 valid_ready_queues_def pred_tcb_at_def)

theorem live_example:
  assumes "t \<in> {tcb_A_ptr,tcb_B_ptr}"
  shows
  "\<lbrace>(=) init_state\<rbrace> scheduler \<lbrace>\<box>\<diamond>\<A>(\<lambda>(s,a,s'). cur_thread s = t)\<rbrace>\<^sup>\<omega>"
  using assms invs_init_state
  by (auto intro: validc_weaken_pre[OF live_scheduler]
            simp: invs_def init_state_def)

theorem no_fail_example:
  "no_fail ((=) init_state) scheduler"
  by (wpsimp wp: no_fail_scheduler simp: invs_init_state)

end
