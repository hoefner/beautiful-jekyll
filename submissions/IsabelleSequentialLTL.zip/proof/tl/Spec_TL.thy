(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Spec_TL
imports Schedule_TL
begin

theorem live_scheduler:
  "\<lbrace>\<lambda>s. t \<in> set (ready_queues s) \<and> valid_ready_queues s\<rbrace>
   scheduler
   \<lbrace>\<box>\<diamond>\<A>(\<lambda>(s,a,s'). cur_thread s = t)\<rbrace>\<^sup>\<omega>"
  unfolding scheduler_def
  apply (rule validc_weaken_pre)
   apply (rule validc_strengthen_post)
    apply (rule_tac mf="qpos t" in validc_loop_measure)
        apply (rule schedule_mono[unfolded qpos_mono_def])
       apply (rule schedule_progress[unfolded qpos_progress_def])
      apply wp
     apply wp
    apply wp
   apply (fastforce simp: ltl_semantics)
  apply (clarsimp simp: valid_ready_queues_def)
  done

lemma no_fail_loop:
  "\<lbrakk> no_fail P f; \<lbrace>P\<rbrace> f \<lbrace>\<lambda>_. P\<rbrace> \<rbrakk>
     \<Longrightarrow> no_fail P (loop f)"
  apply (clarsimp simp add: loop_def2 no_fail_def failed_def)
  apply (erule_tac P="P s" in notE[rotated])
  apply (erule whileLoopF.induct; clarsimp simp: no_fail_def failed_def)
  apply (fastforce simp: valid_def mres_def)
  done

theorem no_fail_scheduler:
  "no_fail invs scheduler"
  unfolding scheduler_def
  apply (rule no_fail_loop)
   apply (wpsimp simp: invs_def)
  apply wp
  done

end
