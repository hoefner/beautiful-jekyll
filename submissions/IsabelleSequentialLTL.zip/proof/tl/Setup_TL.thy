(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Setup_TL
imports WF.Spec_WF
begin

definition pred_tcb_at where
  "pred_tcb_at P t s \<equiv> \<exists>tcb. kheap s t = Some (TCB tcb) \<and> P tcb"

abbreviation tcb_at where
  "tcb_at t s \<equiv> pred_tcb_at (\<lambda>_. True) t s"

abbreviation runnable_tcb_at where
  "runnable_tcb_at \<equiv> pred_tcb_at (\<lambda>tcb. runnable (tcb_state tcb))"

definition valid_cur_thread where
  "valid_cur_thread s \<equiv> tcb_at (cur_thread s) s"

definition valid_idle_thread where
  "valid_idle_thread s \<equiv> tcb_at (idle_thread s) s"

definition valid_ready_queues where
  "valid_ready_queues s \<equiv>
     \<forall>t \<in> set (ready_queues s). runnable_tcb_at t s"

definition invs where
  "invs \<equiv> valid_cur_thread
      and valid_idle_thread
      and valid_ready_queues"

definition ct_runnable_ready where
  "ct_runnable_ready s \<equiv> runnable_tcb_at (cur_thread s) s
                          \<longrightarrow> cur_thread s \<in> set (ready_queues s)"

lemma pred_tcb_at_upds[simp]:
  "pred_tcb_at P t (s\<lparr>cur_thread := ct\<rparr>) = pred_tcb_at P t s"
  "pred_tcb_at P t (s\<lparr>idle_thread := it\<rparr>) = pred_tcb_at P t s"
  "pred_tcb_at P t (s\<lparr>ready_queues := rq\<rparr>) = pred_tcb_at P t s"
  by (auto simp: pred_tcb_at_def)

lemma valid_cur_thread_upds[simp]:
  "valid_cur_thread (s\<lparr>idle_thread := it\<rparr>) = valid_cur_thread s"
  "valid_cur_thread (s\<lparr>ready_queues := qs\<rparr>) = valid_cur_thread s"
  by (auto simp: valid_cur_thread_def)

lemma valid_idle_thread_upds[simp]:
  "valid_idle_thread (s\<lparr>cur_thread := ct\<rparr>) = valid_idle_thread s"
  "valid_idle_thread (s\<lparr>ready_queues := qs\<rparr>) = valid_idle_thread s"
  by (auto simp: valid_idle_thread_def)

lemma valid_ready_queues_upds[simp]:
  "valid_ready_queues (s\<lparr>cur_thread := ct\<rparr>) = valid_ready_queues s"
  "valid_ready_queues (s\<lparr>idle_thread := it\<rparr>) = valid_ready_queues s"
  by (auto simp: valid_ready_queues_def)

fun eindex where
  "eindex [] _ = \<infinity>"
| "eindex (x#xs) y = (if x = y then 0 else eSuc (eindex xs y))"

definition qpos :: "obj_ref \<Rightarrow> state measure" where
  "qpos t s \<equiv> if runnable_tcb_at t s
               then eindex (cur_thread s # ready_queues s) t
               else \<infinity>"

definition
  "qpos_mono t \<equiv> \<lambda>(s,_,s'). measure_mono (qpos t) s s'"

definition
  "qpos_progress t \<equiv> \<lambda>(s,_,s'). measure_progress (qpos t) s s'"

lemma qpos_mono_refl[simp]:
  "qpos_mono t (s, a, s)"
  by (simp add: qpos_mono_def)

lemma eindex_filter_le:
  "x \<noteq> y \<Longrightarrow> eindex (filter ((\<noteq>) y) xs) x \<le> eindex xs x"
  apply (induct xs; clarsimp)
  using ile_eSuc order.trans by blast

lemma eindex_append:
  "eindex (xs @ ys) x = (if x \<in> set xs then eindex xs x else length xs + eindex ys x)"
  apply (induct xs; clarsimp simp: enat_0 split: if_splits)
  by (metis eSuc_enat eSuc_plus)

lemma eindex_append_le:
  "eindex (xs @ ys) x \<le> eindex xs x"
  by (induct xs; clarsimp simp: enat_0 split: if_splits)

lemma eindex_eq_infinity_iff[simp]:
  "eindex xs x = \<infinity> \<longleftrightarrow> x \<notin> set xs"
  by (induct xs; clarsimp simp: eSuc_eq_infinity_iff)

lemma runnable_def2:
  "runnable st = (st = Active)"
  by (cases st; clarsimp)

lemma qpos_eq_0_iff[simp]:
  "qpos t s = 0 \<longleftrightarrow> t = cur_thread s \<and> runnable_tcb_at t s"
  by (auto simp: qpos_def)

lemma qpos_eq_Suc_iff[simp]:
  "qpos t s = enat (Suc n) \<longleftrightarrow>
   runnable_tcb_at t s \<and> t \<noteq> cur_thread s \<and> eindex (ready_queues s) t = n"
  apply (auto simp: qpos_def pred_tcb_at_def enat_0_iff eSuc_enat)
  by (metis co.enat.inject eSuc_enat)

lemma qpos_eq_inf_iff[simp]:
  "qpos t s = \<infinity> \<longleftrightarrow> \<not>runnable_tcb_at t s \<or>
                     (t \<noteq> cur_thread s \<and> t \<notin> set (ready_queues s))"
  by (auto simp: qpos_def eSuc_eq_infinity_iff)

end
