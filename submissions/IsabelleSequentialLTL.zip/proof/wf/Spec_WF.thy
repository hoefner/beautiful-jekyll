(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Spec_WF
imports
  Schedule_WF
begin

(* Nothing to do *)

end
