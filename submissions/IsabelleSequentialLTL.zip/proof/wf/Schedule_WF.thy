(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Schedule_WF
imports KHeap_WF
begin

crunch schedule
  for (no_div) no_div
  and (non_null) non_null

declare no_div_schedule[wp, simp]
declare non_null_schedule[wp, simp]

end
