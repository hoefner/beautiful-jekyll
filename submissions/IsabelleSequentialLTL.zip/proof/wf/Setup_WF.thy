(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory Setup_WF
imports
  ASpec.Spec_A
  VCG.VCG_Toplevel
begin

(* Nothing to do *)

end
