(*
 * Copyright 2025, Ryan Barry, Australian National University
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory KHeap_WF
imports Setup_WF
begin

crunch get_thread_state, set_thread_state, thread_get, thread_set,
       get_tcb_queue, set_tcb_queue, tcb_sched_action
  for (no_div) no_div [wp, simp]

crunch get_object, set_object, thread_get, thread_set,
       get_thread_state, set_thread_state, get_cur_thread, set_cur_thread,
       get_idle_thread, set_idle_thread, get_tcb_queue, set_tcb_queue, tcb_sched_action
  for (no_trace) no_trace [wp, simp]

crunch get_object, set_object, thread_get, thread_set,
       get_thread_state, set_thread_state, get_cur_thread, set_cur_thread,
       get_idle_thread, set_idle_thread, get_tcb_queue, set_tcb_queue, tcb_sched_action
  for (non_null) non_null [wp, simp]
  (wp: hoare_pre_cont)

end
