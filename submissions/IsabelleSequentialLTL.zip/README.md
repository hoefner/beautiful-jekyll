Proof Engineering for Linear Temporal Logic:<br>
An Isabelle/HOL Framework
============================================

This repository contains a compositional proof engineering framework for
Linear Temporal Logic (LTL).
It consists of library files that form the core of the framework,
along with definitions and proofs for a verification case study.

Prerequisites
-----

The proofs in this repository are conducted in the interactive proof
assistant Isabelle/HOL. More specifically, we use the [Isabelle 2024][1] distribution.
Proof have not been tested on other variants of Isabelle.

[1]: https://isabelle.in.tum.de/website-Isabelle2024/index.html "Isabelle Website"

Overview
--------

The framework is organised as follows.

 * [`lib`](lib/): our framework's core libraries
    * [`Trace`](lib/Trace/): the trace monad constituting our command language
    * [`LTL`](lib/LTL/): LTL formulas and their properties
    * [`VCG`](lib/VCG/): verification infrastructure built on weakest precondition reasoning
 * [`spec`](spec/abstract/): the specification of the scheduler
 * [`proof`](proof/): our verification case study for the scheduler
    * [`wf`](proof/wf/): various well-formedness invariants 
    * [`tl`](proof/refine/): temporal logic proofs 


Running the Framework
------------------

In order to explore the framework interactively using Isabelle and jEdit, run the following command in this directory.

    /path/to/isabelle jedit -d . -R Trace proof/tl/Example_TL.thy

This will open a buffer for the top-level proof theory.